## Author
* Name: DocilElm
* Contributions: Everything
* Links: [https://github.com/DocilElm](https://github.com/DocilElm)

## Project Repos:
* [https://github.com/DocilElm/Amaterasu](https://github.com/DocilElm/Amaterasu)
* [https://github.com/DocilElm/DocGuiLib](https://github.com/DocilElm/DocGuiLib)

## Contributors
* Name: nwjn
  * Contributions: Helped shape the gui to something better (main reason why _scheme_ and position/size is changeable)
  * Links: [https://github.com/nwjn](https://github.com/nwjn)

* Name: Squagward
  * Contributions: Helped shape the gui to something better
  * Links: [https://github.com/camnwalter](https://github.com/camnwalter)

* Name: UnclaimedBloom6
  * Contributions: Merging objects method (useful for ColorScheme)
  * Links: [https://github.com/UnclaimedBloom6/](https://github.com/UnclaimedBloom6/)

* Name: Ch1ck3nNeedsRNG
  * Contributions: Helped with documentation and readme
  * Links: [https://github.com/PerseusPotter](https://github.com/PerseusPotter)

## Inspirations
* Mod: Vigilance
  * Links: [https://github.com/EssentialGG/Vigilance](https://github.com/EssentialGG/Vigilance)