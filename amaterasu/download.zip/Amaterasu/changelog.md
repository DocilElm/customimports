- §aAdded: This
- §aAdded: Is
- §aAdded: An
- §aAdded: Example!
 
- §eImproved: I wonder what was improved...
 
- §cRemoved: Wow something was removed!