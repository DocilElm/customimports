let index = 0

export default {
    TOGGLE: index++,
    SLIDER: index++,
    BUTTON: index++,
    SELECTION: index++,
    TEXTINPUT: index++,
    COLORPICKER: index++,
    SWITCH: index++,
    DROPDOWN: index++,
    MULTICHECKBOX: index++,
    TEXTPARAGRAPH: index++,
    KEYBIND: index++
}