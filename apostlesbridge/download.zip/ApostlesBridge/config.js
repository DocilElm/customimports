import { @Vigilant, @SwitchProperty, @TextProperty, @CheckboxProperty, @ButtonProperty, @SelectorProperty, @SliderProperty, @ColorProperty, @PercentSliderProperty, Color} from "../Vigilance/index"

@Vigilant("ApostlesBridge", "ApostlesBridge", {
  getCategoryComparator: () => (a, b) => {
    const categories = ["Formatting"]
    return categories.indexOf(a.name) - categories.indexOf(b.name);
  }
})
class Settings {
  @TextProperty({
    name: "Guild Bot Name",
    description: "Enter the IGN of your guild bridge bot",
    category: "Formatting"
  })
  botName = "" 

  @TextProperty({
    name: "Prefix for Discord Messages",
    description: "Lets you change the prefix of messages coming from discord\nIf nothing is set, defaults to Bridge\nput formatting codes in front of input to customize",
    category: "Formatting",
    placeholder: "Bridge"
  })
  discordFormat = ""

  @TextProperty({
    name: "Prefix for Apostles Messages",
    description: "Lets you change the prefix of messages coming from Apostles\nIf nothing is set, defaults to Guild 1\nput formatting codes in front of input to customize",
    category: "Formatting",
    placeholder: "Guild 1"
  })
  g1Format = ""

  @TextProperty({
    name: "Prefix for Apostles Prime Messages",
    description: "Lets you change the prefix of messages coming from Apostles Prime\nIf nothing is set, defaults to Guild 2\nput formatting codes in front of input to customize",
    category: "Formatting",
    placeholder: "Guild 2"
  })
  g2Format = "" 

  @TextProperty({
    name: "Prefix for Apostles Lite Messages",
    description: "Lets you change the prefix of messages coming from Apostles Lite\nIf nothing is set, defaults to Guild 3\nput formatting codes in front of input to customize",
    category: "Formatting",
    placeholder: "Guild 3"
  })
  g3Format = "" 

  @TextProperty({
    name: "Prefix for Commands",
    description: "Lets you change the prefix of messages coming from Commands\nIf nothing is set, defaults to Command\nput formatting codes in front of input to customize",
    category: "Formatting",
    placeholder: "Command"
  })
  commandFormat = "" 

  @TextProperty({
    name: "Color for names",
    description: "Input minecraft formatting code for names",
    category: "Formatting"
  })
  nameFormat = "" 

  constructor() {
    this.initialize(this);
    this.setCategoryDescription("Formatting", "")
  }
}
export default new Settings();