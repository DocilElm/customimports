import settings from './config';
import { STuF } from './stuf';

register('command', () => {
    settings.openGUI();
}).setCommandName(`apostles`, true);

function getBotName(rawBotName) {
    return rawBotName.split(' ').length > 1 ? rawBotName.split(' ')[1] : rawBotName.split(' ')[0];
}

// soopy bot commands
register('chat', (bot, name, message, event) => {
    if (this.getBotName(bot) != settings.botName) return;
    cancel(event);
    ChatLib.chat(`&2${settings.commandFormat} >&r ${settings.nameFormat}${name}&r: ${message}`);
}).setCriteria('Guild > ${bot} [${*}]: ➡ [${name}] [SOOPY V2] ${message} [GBot:${*}]');
// Guild > [MVP+] BlackHarris [C]: ➡ [Ben_MC] [SOOPY V2] Ben_MC's overflow skill average: 85.31 (#23) [GBot:91472029]

// our bot commands
register('chat', (bot, name, message, event) => {
    if (this.getBotName(bot) != settings.botName) return;
    cancel(event);
    ChatLib.chat(`&2${settings.commandFormat} >&r ${settings.nameFormat}${name}&r: ${message}`);
}).setCriteria('Guild > ${bot} [${*}]: ➡ [${name}]: ${message}');
// Guild > NotABridge [BAD]: ➡ [Medua]: Minikloon's (Banana) nw: 46.65B (Museum OFF)

// chats
register('chat', (bot, type, name, message, event) => {
    if (this.getBotName(bot) != settings.botName) return;
    let fullMsg = ChatLib.getChatMessage(event, false);
    if (fullMsg.includes('] ➡ [')) return;
    cancel(event);
    if (type == 'DC') type = settings.discordFormat == '' ? 'Bridge' : settings.discordFormat;
    else if (type == 'G3') type = settings.g3Format == '' ? 'Guild 3' : settings.g3Format;
    else if (type == 'G2') type = settings.g2Format == '' ? 'Guild 2' : settings.g2Format;
    else if (type == 'G1') type = settings.g1Format == '' ? 'Guild 1' : settings.g1Format;

    if (message.includes('l$')) message = message.substring(0, message.indexOf('l$')) + STuF.decode(message.substring(message.indexOf('l$')));
    ChatLib.chat(`&2${type} >&r ${settings.nameFormat}${name}&r: ${message}`);
}).setCriteria('Guild > ${bot} [${*}]: [${type}] [${name}]: ${message}');
// Guild > [MVP+] BlackHarris [C]: [DC] [zZzSNOW]: underscore

// replies
register('chat', (bot, from, to, message, event) => {
    if (this.getBotName(bot) != settings.botName) return;
    cancel(event);
    let type = settings.discordFormat == '' ? 'Bridge' : settings.discordFormat;
    ChatLib.chat(`&2${type} >&r ${settings.nameFormat}${from} &r➡ ${settings.nameFormat}${to}&r: ${message}`);
}).setCriteria('Guild > ${bot} [${*}]: [DC] [${from}] ➡ [${to}]: ${message}');
// Guild > [MVP+] BlackHarris [C]: [DC] [nwjn] ➡ [nwjn]: b
