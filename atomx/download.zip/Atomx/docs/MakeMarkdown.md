# Class MakeMarkdown

*  Makes a markdown file basing it off of the jsdocs of other file
* @class
 

### constructor(moduleName)

* @param {String} moduleName 
     
    
### classMarkdown(fileDirectory, saveAs = null)

*  Makes a markdown based off of the jsdoc of the given file directory
* @param {String} fileDirectory 
* @param {String|null} saveAs The directory to save it as (null by default this will save it as the class's name instead)
* @returns 
     
    
### _save(fileDirectory)

*  Saves the [markdownText] into a file
* @param {String|null} fileDirectory 
     
    
