Im to lazy to write this rn, if someone wants to write it and dm it to me i can add.

basicly just remember u can open chat then hover/left/right click on the map

If the map breaks just run /reloadmap