import constants from "../utils/constants"

// todo: do this

/*

const indigo = new TextComponent("Full Guide (by IndigoPolecat)")
                .setClickAction("open_url")
                .setClickValue("https://hypixel.net/search/15603300/?q=Bingo+Guide\&t=post\&c[title_only]=1\&c[users]=IndigoPolecat\&o=date")
const tanya = new TextComponent("Day-by-Day guide (by Tanya the Evil)")
                .setClickAction("open_url")
                .setClickValue("https://hypixel.net/search/15028449/?q=Day-by-Day&&rt=post&&rc[content]=thread&&rc[title_only]=1&&rc[users]=ZerosTulip&&ro=date")

const message = new Message(
`${constants.PREFIX}&n&6Bingo Guides&r\n`,
' • ', indigo, '\n&r',
' • ', tanya
)

register("command", () => {
    ChatLib.chat(message)
}).setName('bingoguide')

*/