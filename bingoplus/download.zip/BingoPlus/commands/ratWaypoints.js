register("command", () => {
    ChatLib.command("b+ rat", true)
}).setName("rats").setAliases("ratwaypoints")