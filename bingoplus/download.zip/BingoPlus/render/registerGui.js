// thanks coleweight

let guis = []

export function registerGui(gui) {
    guis.push(gui)
}

export default guis