import { data } from "./constants"

data.autosave(5)