# Credits

## §6Authors
§dBlingBling Addons §ris written by [blingbling](https://github.com/blingblingdeveloper) and [Celeite](https://github.com/CeleiteCode)  

## §6Adapted code
[RenderLib](https://chattriggers.com/modules/v/Renderlib) code by [Debuggingss](https://github.com/Debuggingss)  
[ColeWeight](https://chattriggers.com/modules/v/Coleweight) code by [Ninjune](https://github.com/Ninjune)  


## §6Thanks
[Ninjune](https://github.com/Ninjune) for developing [ColeWeight](https://chattriggers.com/modules/v/Coleweight), which inspired §dBlingBling §dAddons  
The incredible developers of [ChatTriggers](https://chattriggers.com/)  
[DocDocilElm](https://github.com/DocilElm) for quick help and fixes for [Amaterasu](https://www.chattriggers.com/modules/v/Amaterasu)  
[L3unamme](https://github.com/ManuCoding) for being the best rubber duck around  