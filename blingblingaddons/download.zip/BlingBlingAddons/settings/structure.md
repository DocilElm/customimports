# §dStructure Check
§4All ChatTriggers modules must comply with Hypixel rules to be §4verified.  
This feature was separated from the mod for people who do not intend to use it, and to ensure §dBlingBling Addons§f could be verified.  
  
If you would like to install structure check, please follow these installation instructions:
1. Go to the [BlingBling Addons Struc Check GitHub](https://github.com/CeleiteCode/BlingBlingAddonsStrucCheck/releases/tag/1.0.0).
2. Download §6StrucCheck-1.0.0.zip
3. Unzip the file, you should have a folder called §6BlingBlingAddonsStrucCheck
4. Run §6/ct files §fthis should open the ChatTriggers folder
5. Open the §6modules §ffolder
6. Drag §6BlingBlingAddonsStrucCheck §finto the §6modules §ffolder
7. §6/ct load §fto reload ChatTriggers  

This code is completely open source, however please note that it has §4not §4been §4verified §fby the ChatTriggers team and is §4against §4Hypixel §4rules.

## §dWhy Structure Check was added
Struc Check was created to encourage people not to cheat/use more malicious mods which have structure check or esp, which may tempt them into malicious forms of mining such as macroing or grotto esp. 
> I also made this because I did not want people to rage and then download some super suspicious mod that will get them ratted or complain about why blingbling sapphire 24 vein was getting griefed.  
> \- BlingBling