import PogObject from "PogData"

let PogData = new PogObject("BlingBlingAddons", {
    "onboarding": {
        "main": false,
        "efficiency": false
    },
}, "config/data.json")

export default constants = PogData