import { Handlers } from "./Handlers"

// Build from: https://jitpack.io/#debuggingss/clickgui/72f98a8be5
const ClickGuiJar = Java.type("dev.debuggings.clickgui.ClickGui")
const Colors = Java.type("dev.debuggings.clickgui.Colors")
const Section = Java.type("dev.debuggings.clickgui.Section")
const SubSection = Java.type("dev.debuggings.clickgui.elements.SubSection")
const Color = Java.type("java.awt.Color")
// Elements
const ToggleElement = Java.type("dev.debuggings.clickgui.elements.ToggleElement")
const ButtonElement = Java.type("dev.debuggings.clickgui.elements.ButtonElement")
const ColorPickerElement = Java.type("dev.debuggings.clickgui.elements.ColorPickerElement")
const DecimalSliderElement = Java.type("dev.debuggings.clickgui.elements.DecimalSliderElement")
const DividerElement = Java.type("dev.debuggings.clickgui.elements.DividerElement")
const SecureToggleElement = Java.type("dev.debuggings.clickgui.elements.SecureToggleElement")
const SelectElement = Java.type("dev.debuggings.clickgui.elements.SelectElement")
const SliderElement = Java.type("dev.debuggings.clickgui.elements.SliderElement")
const TextInputElement = Java.type("dev.debuggings.clickgui.elements.TextInputElement")

const customClickGui = (filePath, color) => new JavaAdapter(ClickGuiJar, {
    init() {
        this.config.load()
        this.sections.forEach(it => it.init())

        new Handlers(this)
        this.descText.setColor(Colors.INSTANCE.TITLE_TEXT)
    }
}, filePath, color)

/**
 * @template {string} T
 * @template K
 * @typedef {object} DefaultObject
 * @prop {T} name The name of this `config` to get its value
 * @prop {string} title The title to be displayed for this `config`
 * @prop {string?} description The description to be displayed for this `config`
 * @prop {K} value Sets the default value for this `config`
 * @prop {string} category The category name for this `config`
 * @prop {string?} subcategory The subcategory name for this `config`
 * @prop {() => void} onClick The function to be ran whenever the `config` is clicked (only if supported)
 * @prop {boolean} allowBinding Whether this `config` should allow for keybind binding (only if supported)
 * @prop {number} min The minimum value for this `config` (only if supported)
 * @prop {number} max The maximum value for this `config` (only if supported)
 * @prop {string[]} options The options for this `config` (only if supported)
*/

/**
 * @typedef {object} Element
 * @prop {number} boundKey Returns the keycode binded to this element (only if `allowBinding` is set to `true`)
*/

export default class ClickGui {
    /**
     * - Creates a new [ClickGui] instance
     * @param {string} moduleName The module name (used to store the settings file)
     * @param {string} filePath The file path where the setting is stored (`config.toml` by default)
     * @param {[number, number, number, number]?} color This determines the color of the gui, if it's null it will have a chroma wave effect
     */
    constructor(
        moduleName,
        filePath = "config.toml",
        color = null
    ) {
        this.gui = customClickGui(
            `${Config.modulesFolder}/${moduleName}/${filePath}`,
            color == null ? color : this._getJavaColor(color) // why not
        )

        this.categories = new Map()
        // Subcategories should always be formatting in
        // "category:subcategory" (the key)
        this.subCategories = new Map()

        this.settings = {}
        this.bindings = {}
    }

    /**
     * - Initializes this gui's events and everything it depends on
     * - NOTE: this should only be called after all the properties are added
     * @returns {this}
     */
    init() {
        this.gui.init()

        return this
    }

    /**
     * - Opens this [ConfigGui]
     * @returns this for method chaining
     */
    open() {
        GuiHandler.openGui(this.gui)

        return this
    }

    /**
     * - Adds a toggle to this [GUI]
     * @template {string} T
     * @template {Element} V
     * @param {DefaultObject<T, boolean>} obj
     * @returns {this & {settings: Record<T, boolean>} & {bindings: Record<T, V>}}
     */
    addToggle({
        name,
        title,
        description = null,
        allowBinding = false,
        value = false,
        category = null,
        subcategory = null
    }) {
        const comp = new ToggleElement(
            title,
            value,
            true,
            allowBinding,
            description
            )
        this._addElement(name, comp, category, subcategory)

        if (allowBinding) this.bindings[name] = comp

        return this
    }

    /**
     * - Adds a button to this [GUI]
     * @template {string} T
     * @template {Element} V
     * @param {DefaultObject<T, null>} obj
     * @returns {this & {bindings: Record<T, V>}}
     */
    addButton({
        name = null,
        title,
        description = null,
        onClick,
        allowBinding = false,
        category = null,
        subcategory = null
    }) {
        const comp = new ButtonElement(
            title,
            allowBinding,
            description,
            onClick
            )
        this._addElement(title, comp, category, subcategory)

        if (allowBinding) this.bindings[name] = comp

        return this
    }

    /**
     * - Adds a color picker to this [GUI]
     * @template {string} T
     * @param {DefaultObject<T, [number, number, number, number]>} obj
     * @returns {this & {settings: Record<T, Color>}}
     */
    addColorPicker({
        name,
        title,
        description = null,
        value = [255, 255, 255, 255],
        category = null,
        subcategory = null
    }) {
        const color = this._getJavaColor(value)

        this._addElement(name, new ColorPickerElement(
            title,
            color,
            description
            ), category, subcategory)

        return this
    }

    /**
     * - Adds a decimal slider to this [GUI]
     * @template {string} T
     * @param {DefaultObject<T, number>} obj
     * @returns {this & {settings: Record<T, number>}}
     */
    addDecimalSlider({
        name,
        title,
        description = null,
        min = 0,
        max = 10,
        value = 0,
        category = null,
        subcategory = null
    }) {
        this._addElement(name, new DecimalSliderElement(
            title,
            min,
            max,
            value,
            description
        ), category, subcategory)

        return this
    }

    /**
     * - Adds a divider to this [GUI]
     * @param {DefaultObject<string, null>} obj
     * @returns {this}
     */
    addDivider({
        title,
        category,
        subcategory
    }) {
        this._addElement(title, new DividerElement(title), category, subcategory)

        return this
    }

    /**
     * - Adds a secure toggle to this [GUI]
     * @template {string} T
     * @param {DefaultObject<T, boolean>} obj
     * @returns {this & {settings: Record<T, boolean>}}
     */
    addSecureToggle({
        name,
        title,
        description = null,
        value = false,
        category = null,
        subcategory = null
    }) {
        this._addElement(name, new SecureToggleElement(
            title,
            value,
            description
        ), category, subcategory)

        return this
    }

    /**
     * - Adds a selection to this [GUI]
     * @template {string} T
     * @param {DefaultObject<T, string>} obj
     * @returns {this & {settings: Record<T, string>}}
     */
    addSelection({
        name,
        title,
        description = null,
        value = "placeholder",
        options = ["placeholder"],
        category = null,
        subcategory = null
    }) {
        const opts = new ArrayList()
        options.forEach(it => opts.add(it))

        this._addElement(name, new SelectElement(
            title,
            value,
            opts,
            description
        ), category, subcategory)

        return this
    }

    /**
     * - Adds a slider to this [GUI]
     * @template {string} T
     * @param {DefaultObject<T, number>} obj
     * @returns {this & {settings: Record<T, number>}}
     */
    addSlider({
        name,
        title,
        description = null,
        min = 0,
        max = 10,
        value = 0,
        category = null,
        subcategory = null
    }) {
        this._addElement(name, new SliderElement(
            title,
            min,
            max,
            value,
            description
        ), category, subcategory)

        return this
    }

    /**
     * - Adds a text input to this [GUI]
     * @template {string} T
     * @param {DefaultObject<T, string>} obj
     * @returns {this & {settings: Record<T, string>}}
     */
    addTextInput({
        name,
        title,
        description = null,
        value = "",
        category = null,
        subcategory = null
    }) {
        this._addElement(name, new TextInputElement(
            title,
            value,
            description
        ), category, subcategory)

        return this
    }

    /**
     * - Internal use.
     * @param {[number, number, number, number]} param0
     * @returns {Color}
     */
    _getJavaColor([r, g, b, a]) {
        return new Color(r / 255, g / 255, b / 255, a / 255)
    }

    /**
     * - Internal use.
     * - Adds a category (section) to this [GUI]
     * @param {string} name
     * @returns {this}
     */
    _addCategory(name) {
        if (this.categories.has(name)) throw new Error(`Category with name ${name} already exists`)

        this.categories.set(name, new Section(name).sectionOf(this.gui))

        return this
    }

    /**
     * - Internal use.
     * - Adds a subcategory to this [GUI]
     * @param {string} category
     * @param {string} name
     * @returns {this}
     */
    _addSubcategory(category, name) {
        if (this.subCategories.has(`${category}:${name}`)) throw new Error(`Subcategory with name ${name} already exists inside Category ${category}`)
        if (!this.categories.has(category)) throw new Error(`Category with name ${category} does not exist`)

        this.subCategories.set(`${category}:${name}`, new SubSection(name, false, true, false, false, null).subSectionOf(this.categories.get(category)))

        return this
    }

    /**
     * - Internal use.
     * - Adds an element to the given [Category] & [Subcategory] if these were set
     * - Mostly handles what the current element should be a child of
     * @param {string} name
     * @param {Element} element
     * @param {string} category
     * @param {string} subcategory
     * @returns {this}
     */
    _addElement(name, element, category, subcategory) {
        if (!category) throw new Error(`Category must not be empty`)
        if (name in this.settings) throw new Error(`Config with name ${name} already exists`)

        if (!this.categories.has(category)) this._addCategory(category)
        if (subcategory && !this.subCategories.has(`${category}:${subcategory}`)) this._addSubcategory(category, subcategory)

        element.elementOf(this.subCategories.get(`${category}:${subcategory}`) ?? this.categories.get(category))
        element.onChange((v) => this.settings[name] = v)

        return this
    }
}