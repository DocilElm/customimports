const ColorHandler = Java.type("dev.debuggings.clickgui.handlers.ColorHandler")
const KeyBindHandler = Java.type("dev.debuggings.clickgui.handlers.KeyBindHandler")
const DescriptionHandler = Java.type("dev.debuggings.clickgui.handlers.DescriptionHandler")

export class Handlers {
    constructor(clickGui) {
        this.clickGui = clickGui
        this.colorHandler = new ColorHandler(this.clickGui, this.clickGui.color)
        this.keyBindHandler = new KeyBindHandler(this.clickGui)
        this.descriptionHandler = new DescriptionHandler(this.clickGui)

        register(net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent, (event) => {
            this.colorHandler.onTick(event)
            this.descriptionHandler.onTick(event)
        })

        register(net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent, (event) => {
            this.keyBindHandler.onKeyInput(event)
        })
    }
}