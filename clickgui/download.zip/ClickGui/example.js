// Importing the necessary class
import ClickGui from "./ClickGui"

// Creating a new [ClickGui]
// with "example" as module name
const myConfig = new ClickGui("example")
    // Now we start adding properties
    .addToggle({
        name: "test",
        title: "Testing",
        description: "this is a test",
        category: "Category 1",
        allowBinding: true
    })
    .addButton({
        // Name entry on a button is only required if you want
        // it's binded keycode value
        name: "btn",
        title: "Button One",
        category: "Category 1",
        onClick() {
            ChatLib.chat("test!")
        },
        allowBinding: true
        // if this is set to true you need to define [name]
    })
    .addToggle({
        name: "test2",
        title: "Test 2",
        category: "Category 2",
        subcategory: "Sub category 2"
    })
    .addColorPicker({
        name: "testcolor",
        title: "Testing Color",
        category: "Category 2",
        subcategory: "Sub category 2"
    })
    .addDecimalSlider({
        name: "decimaltest",
        title: "Decimal Slider",
        category: "Category 2",
        subcategory: "Sub category 2"
    })
    .addDivider({
        title: "this is a divider",
        category: "Category 2",
        subcategory: "Sub category 2"
    })
    .addSecureToggle({
        name: "SecureToggle",
        title: "Secure Toggle",
        category: "Category 2",
        subcategory: "Sub category 2"
    })
    .addSelection({
        name: "Selection",
        title: "Selection Test",
        options: ["Test1", "Test2", "Test3"],
        value: "Test1",
        category: "Category 2",
        subcategory: "Sub category 2"
    })
    .addSlider({
        name: "SliderTest",
        title: "Slider Test",
        category: "Category 2",
        subcategory: "Sub category 2"
    })
    .addTextInput({
        name: "TextInput",
        title: "Text Input Test",
        value: "Placeholder!",
        category: "Category 2",
        subcategory: "Sub category 2"
    })
    // Calling `init` at the end of the property chain
    // so that the [GUI] gets setup properly
    // (this step is important to be done this way)
    .init()

register("step", () => {
    // If the normal toggle is enabled we print out its binded key
    if (myConfig.settings.test) {
        // This is how we get the binded keycode
        // We do it this way due to it requiring the Element component
        ChatLib.chat(myConfig.bindings.test.boundKey)
    }

    // If the secure toggle is disabled we return
    if (!myConfig.settings.SecureToggle) return

    // Otherwise we say something in chat
    ChatLib.chat("the secure toggle is enabled!")
}).setFps(1)

// Now we set a command to open our [GUI]
register("command", () => {
    myConfig.open()
}).setName("example")