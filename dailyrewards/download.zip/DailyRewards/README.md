# DailyRewards

Chattriggers module that allows users to collect Hypixel Daily Rewards in-game.

