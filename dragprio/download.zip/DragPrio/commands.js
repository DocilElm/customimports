/// <reference types="../CTAutocomplete" />
import Settings from "./config"
import { roundToHalf } from './utils'


// function to say all the commands
export function sayCommands() {

  ChatLib.chat('\n&3&lCOMMANDS:')
  ChatLib.chat('&d-----------------------------------------------------')
  new Message().addTextComponent(new TextComponent('&6/dp ').setClickValue('/dp ').setClickAction('run_command')).addTextComponent(new TextComponent('- &aOpens the gui')).chat()
  ChatLib.chat('&d-----------------------------------------------------')
  new Message().addTextComponent(new TextComponent('&6/dragmsg ').setHoverValue('&c?{true, t, false, f}').setHoverAction('show_text').setClickValue(`/dragmsg `).setClickAction('suggest_command')).addTextComponent(new TextComponent(' - &aSays the bers/arch team dragon split message, disabled by default.')).chat()
  ChatLib.chat('&d-----------------------------------------------------')
  new Message().addTextComponent(new TextComponent('&6/splitmsg ').setHoverValue('&c?{true, t, false, f}').setHoverAction('show_text').setClickValue('/sendmsg ').setClickAction('suggest_command')).addTextComponent(new TextComponent('- &aSays the power and whether to split or not based on your power config, enabled by default.')).chat()
  ChatLib.chat('&d-----------------------------------------------------')
  new Message().addTextComponent(new TextComponent('&6/dragtitle ').setHoverValue('&c?{true, t, false, f}').setHoverAction('show_text').setClickValue('/dragtitle ').setClickAction('suggest_command')).addTextComponent(new TextComponent('- &aShows the "{COLOR} IS SPAWNING!" title on screen for non-split dragons, enabled by default')).chat()
  ChatLib.chat('&d-----------------------------------------------------')
  new Message().addTextComponent(new TextComponent('&6/setpower').setHoverValue('&c{0.0 - 32.0}').setHoverAction('show_text').setClickValue('/setpower ').setClickAction('suggest_command')).addTextComponent(new TextComponent('- &aSets the power to split on, set to 19 by default.')).chat()
  ChatLib.chat('&d-----------------------------------------------------')
  new Message().addTextComponent(new TextComponent('&6/seteasypower').setHoverValue('&c{0.0 - 32.0}').setHoverAction('show_text').setClickValue('/seteasypower ').setClickAction('suggest_command')).addTextComponent(new TextComponent('- &aSets the power to do easy splits on, set to 19 by default.')).chat()
  ChatLib.chat('&d-----------------------------------------------------')
  new Message().addTextComponent(new TextComponent('&6/sendprio ').setClickValue('/sendprio ').setClickAction('run_command')).addTextComponent(new TextComponent('- &aSends your Drag prio settings to party chat for you party to use')).chat()
  ChatLib.chat('&d-----------------------------------------------------\n')
}


register('command', () => { Settings.openGUI() }).setName('dragprio').setAliases('dp')
// command to turn bers/arch team message on/off
register("command", (...args) => {
  switch (args[0]) {

    case "true":
    case 't':

      Settings.sendMessage = true
      break

    case "false":
    case 'f':

      Settings.sendMessage = false
      break

    case undefined:
      Settings.sendMessage = !Settings.sendMessage
      break

    default:
      break
  }
  ChatLib.chat(`&aSet Party Message to ${Settings.sendMessage ? 'enabled' : 'disabled'}`)
}).setName("dragmsg")


// command to turn split/no split message on/off
register("command", (...args) => {

  switch (args[0]) {

    case "true":
    case 't':

      Settings.saySplit = true
      break

    case "false":
    case 'f':

      Settings.saySplit = false
      break

    case undefined:
      Settings.saySplit = !Settings.saySplit
      break

    default:
      break
  }
  ChatLib.chat(`&aSet Split Message to ${Settings.saySplit ? 'enabled' : 'disabled'}`)
}).setName("splitmsg")


// command to turn single spawning drag titles on/off
register("command", (...args) => {

  switch (args[0]) {

    case "true":
    case 't':

      Settings.showSingleDragons = true
      break

    case "false":
    case 'f':

      Settings.showSingleDragons = false
      break

    case undefined:
      Settings.showSingleDragons = !Settings.showSingleDragons
      break

    default:
      break
  }
  ChatLib.chat(`&aSet Single Drag title display to ${Settings.showSingleDragons ? 'enabled' : 'disabled'}`)
}).setName("dragtitle")


// command to set split power
register("command", power => {

  if (!(isNaN(power)) && power >= 0 && power <= 32) {

    Settings.splitPower = roundToHalf(parseFloat(power))

    ChatLib.chat(`&aSet split power to ${Settings.splitPower}`)
  } else {

    ChatLib.chat(`&cInvalid number!`)
  }
}).setName("setpower")


// command to set split power
register("command", power => {

  if (!(isNaN(power)) && power >= 0 && power <= 32) {

    Settings.easyPower = roundToHalf(parseFloat(power))

    ChatLib.chat(`&aSet easy split power to ${Settings.easyPower}`)
  } else {

    ChatLib.chat(`&cInvalid number!`)
  }
}).setName("seteasypower")


// command to send config to party chat
register('command', () => {
  ChatLib.say(`/pc DP Settings: Power: ${Settings.splitPower} | Easy: ${Settings.easyPower} | Healer: ${Settings.healerNormal} : ${Settings.healerPurp} | Tank: ${Settings.tankNormal} : ${Settings.tankPurp}`)
}).setName('sendprio')


// command to set the split prios and config healer/tank locations
register('command', (power, easy, healerN, healerP, tankN, tankP) => {
  if ((isNaN(power)) || power < 0 || power > 32) {
    ChatLib.chat('&4Bro ur String was wrong idk dm @tbone222 with the string so i can fix if u think this is a bug')
    return
  }
  if ((isNaN(easy)) || easy < 0 || easy > 32) {
    ChatLib.chat('&4Bro ur String was wrong idk dm @tbone222 with the string so i can fix if u think this is a bug')
    return
  }
  if ((healerN != 1 && healerN != 0) || (healerP != 1 && healerP != 0) || (tankN != 1 && tankN != 0) || (tankP != 1 && tankP != 0)) {
    ChatLib.chat('&cBro ur String was wrong dm @tbone222 with the string so i can fix if u think this is a bug')
    return
  }

  Settings.splitPower = power;
  Settings.easyPower = easy;
  Settings.healerNormal = healerN
  Settings.healerPurp = healerP
  Settings.tankNormal = tankN
  Settings.tankPurp = tankP
  ChatLib.chat(`&aSettings set to Power: ${power} | Easy: ${easy} | Healer: ${healerN} : ${healerP} | Tank: ${tankN} : ${tankP}`)
}).setName('setprio')


// bro just make a help smh my head
register('command', () => {

  sayCommands()
}).setName('draghelp')
