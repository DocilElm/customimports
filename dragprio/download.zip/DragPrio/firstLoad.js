import Settings from "./config"
import { sayCommands } from './commands'


// first load thingy, yes I suck at colors don't ask
if (Settings.firstLoad) {

    ChatLib.chat("\n&6&lThanks for downloading DragPrio :D\n")
    ChatLib.chat("&6&nYou can use the following commands to configure the module:\n")
    sayCommands()
    ChatLib.chat("&6If you encounter any bugs or want any features added feel free to dm us on disc @bxsy/@tbone222 or msg us in game Bxsy/T_Bone222\n")

    Settings.firstLoad = false
}
