// global stuff
const blessings = {
    power: /Blessing of Power (.+)/,
    time: /Blessing of Time (.+)/,
}
const romanHash = {
    I: 1,
    V: 5,
    X: 10,
}


// Function to round numbers to closest half given any number
export function roundToHalf(number) {
    const rounded = Math.round(number * 2) / 2
    return Number.isInteger(rounded) ? Math.floor(rounded) : rounded
}


// Function to convert roman numerals to integers given a roman numeral
// Only works for I, V and X as this is just for blessings
function romanToInt(s) {
    let accumulator = 0
    for (let i = 0; i < s.length; i++) {
        if (s[i] === 'I' && (s[i + 1] === 'V' || s[i + 1] === 'X')) {
            accumulator += romanHash[s[i + 1]] - romanHash[s[i]]
            i++
        } else {
            accumulator += romanHash[s[i]]
        }
    }
    return accumulator
}


// Function to get the current power blessing
export function getPower() {

    let footer = TabList?.getFooter()?.removeFormatting()
    return footer.match(blessings.power) ? romanToInt(footer.match(blessings.power)[1]) : 0
}


// Function to get the current time blessing
export function getTime() {

    let footer = TabList?.getFooter()?.removeFormatting()
    return footer.match(blessings.time) ? romanToInt(footer.match(blessings.time)[1]) : 0
}


// Function to get the true power given the power and time
export function getTruePower() {

    return getPower() + getTime() / 2
}


// Function to return dungeon class given player name
export function getClass(player) {

    let tabInfo = TabList.getNames()
    for (let i = 0; i < tabInfo.length; i++) {
        let tabLine = tabInfo[i].removeFormatting()
        if (tabLine.includes(Player.getName())) {
            return tabLine.substring((tabLine.indexOf("(")) + 1)
        }
    }
}
