import { RED, DARK_GRAY, BLUE, WHITE, BOLD, RESET } from '../constants/formatting';
import { NBTTagString } from '../constants/javaTypes';
import { DOUBLE_HOOK_MESSAGES } from '../constants/triggers';

// Double hook reindrakes may produce the following messages history:
// [CHAT] &r&eIt's a &r&aDouble Hook&r&e!&r
// [CHAT] &r
// [CHAT] &r&c&lWOAH! &r&cA &r&4Reindrake &r&cwas summoned from the depths!&r
// [CHAT] &r
// [CHAT] &r
// [CHAT] &r&c&lWOAH! &r&cA &r&4Reindrake &r&cwas summoned from the depths!&r
// [CHAT] &r
// [CHAT] &r&aA Reindrake forms from the depths.&r

// [CHAT] &r&eIt's a &r&aDouble Hook&r&e! Woot woot!&r
// [CHAT] &r&e> Your bottle of thunder has fully charged!&r
// [CHAT] &r&c&lYou hear a massive rumble as Thunder emerges.&r

export function isDoubleHook() {
	const history = ChatLib.getChatLines()?.filter(l => // Those messages appear between double hook and catch messages for Reindrake / Thunder
		l !== '&r' &&
		l !== '&r&c&lWOAH! &r&cA &r&4Reindrake &r&cwas summoned from the depths!&r' &&
		l !== '&r&e> Your bottle of thunder has fully charged!&r'
	);
	const isDoubleHooked = (!!history && history.length > 1)
		? DOUBLE_HOOK_MESSAGES.includes(history[1])
		: false;
	return isDoubleHooked;
}

export function getCatchMessage(seaCreature) {
	return `--> ${getArticle(seaCreature)} ${seaCreature} has spawned <--`;
}

export function getDoubleHookCatchMessage(seaCreature) {
	return `--> DOUBLE HOOK! Two ${seaCreature}s have spawned <--`;
}

export function getPlayerDeathMessage() {
	return `--> I was killed, please wait for me until I come back <--`;
}

export function getCatchTitle(seaCreature, rarityColorCode) {
	return `${rarityColorCode}${BOLD}${seaCreature}`;
}

export function getDoubleHookCatchTitle(seaCreature, rarityColorCode) {
	return `${rarityColorCode}${BOLD}${seaCreature} ${RED}${BOLD}X2`;
}

export function getDropMessage(item, metadata) {
	return metadata && metadata.length
		? `--> ${getArticle(item)} ${item} has dropped (${metadata.join(', ')}) <--`
		: `--> ${getArticle(item)} ${item} has dropped <--`;
}

export function getDropMessagePattern(item) {
	return `--> ${getArticle(item)} ${item} has dropped` + "${*}" + `<--`;
}

export function getDropTitle(item, rarityColorCode) {
	return `${rarityColorCode}${BOLD}${item}`;
}

export function getColoredPlayerNameFromDisplayName() {
	const displayName = Player.getDisplayName(); // [Level] Nickname, e.g. §r§r§8[§d326§8] §bMoonTheSadFisher §7α§r§7
	const nameWithoutLevel = displayName.getText().split('] ').pop();
	const name = nameWithoutLevel.split(' ')[0];
	return name;
}

export function getColoredPlayerNameFromPartyChat(playerAndRank) { // &r&9Party &8> &b[MVP&d+&b] DeadlyMetal&f: &r--> A YETI has spawned <--&r
	if (!playerAndRank) return '';
	const color = playerAndRank.substring(0, 2);
	const nameWithoutRank = playerAndRank.split('] ').pop();
	return `${color}${nameWithoutRank}`;
}

export function getPlayerNameFromPartyChat(playerAndRank) { // Input: &b[MVP&d+&b] DeadlyMetal
	if (!playerAndRank) return '';
	const nameWithoutRank = playerAndRank.split('] ').pop().removeFormatting();
	return nameWithoutRank;
}

// Messages have the following format:
// &r&9Party &8> &b[MVP&d+&b] DeadlyMetal&f: &r--> A YETI has spawned <--&r
// &r&9Компания &8> &b[MVP] PivoTheSadFisher&f: &r--> A Deep Sea Orb has dropped <--&r
export function getPartyChatMessage(baseMessage) {
	return `${RESET}${BLUE}` + "${*}" + ` ${DARK_GRAY}> ` + "${rankAndPlayer}" + `${WHITE}: ${RESET}${baseMessage}${RESET}`;
	// To test using Co-op chat:
	// return `${RESET}${AQUA}Co-op > ` + "${rankAndPlayer}" + `${WHITE}: ${RESET}${baseMessage}${RESET}`;
}

// Transforms UPPERCASE TEXT to a Regular Text With Capitalized First Letters.
export function fromUppercaseToCapitalizedFirstLetters(str) {
	if (!str) {
		return '';
	}

	const words = str.split(' ');
	return words.map((word) => { 
	    return word[0].toUpperCase() + word.substring(1).toLowerCase(); 
	}).join(' ');
}

// Pluralizes the words, e.g. Thunder => Thunders, Lord Jawbus => Lord Jawbuses.
export function pluralize(str) {
	if (!str) {
		return '';
	}

	if (str.endsWith('s') || str.endsWith('z') || str.endsWith('x') || str.endsWith('sh') || str.endsWith('ch')) {
		return `${str}es`;
	}

	return `${str}s`;
}

/**
 * Converts date to string using YYYY-MM-DD hh:ss:ss format. Example: "2024-04-21 17:15:25"
 * @param {Date} date - Date to be formatted
 * @returns {string}
 */
export function formatDate(date) {
    if (!date) {
        return date;
    }

	const year = date.getFullYear();
	const month = date.getMonth() + 1;
	const day = date.getDate();
	const formattedDate = [ year, month < 10 ? `0${month}` : month, day < 10 ? `0${day}` : day ].join('-');
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    const formattedTime = [
        hours < 10 ? `0${hours}` : hours,
        minutes < 10 ? `0${minutes}` : minutes,
        seconds < 10 ? `0${seconds}` : seconds
    ].join(':');
    const formattedDateTime = formattedDate + ' ' + formattedTime;
    return formattedDateTime;
}

/**
 * Converts a number to more readable format with spaces. Example: 10500 => "10 500"
 * @param {number} number - Number to be formatted
 * @returns {string}
 */
export function formatNumberWithSpaces(number) {
	if (!number) {
		return number;
	}
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

/**
 * Converts a number to more short format in thousands, millions and billions. Examples: 100 => "100", 1000 => "1K", 1160 => "1.1K", 999999 => "999.9K", 2500000 => "2.5M"
 * @param {number} number - Number to be formatted
 * @returns {string}
 */
export function toShortNumber(number) {
	if (!number) {
		return 0;
	}

	number = Math.floor(number);

	if (number >= 1000000000) {
		return roundToFixed(number / 1000000000, 2) + 'B';
	}
	if (number >= 1000000) {
		return roundToFixed(number / 1000000, 1) + 'M';
	}
	if (number >= 1000) {
		return roundToFixed(number / 1000, 1) + 'K';
	}

	return number;

	function roundToFixed(number, digits) { // Default js toFixed() function rounds numbers, e.g. 999.999 => 1000K
		const m = 10 ** digits;
		return Math.floor(number * m) / m;
	}
}

/**
 * Converts elapsed seconds to hours, minutes and seconds. Examples: "1:05", "2:03:49", "27:03:17"
 * @param {Number} elapsedSeconds - Elapsed seconds
 * @returns {string}
 */
export function formatElapsedTime(elapsedSeconds) {
    const hours = ~~(elapsedSeconds / 3600);
    const minutes = ~~((elapsedSeconds % 3600) / 60);
    const seconds = ~~elapsedSeconds % 60;
  
    let result = '';
  
    if (hours > 0) {
        result += hours + ':' + (minutes < 10 ? '0' : '');
    }
  
    result += minutes + ':' + (seconds < 10 ? '0' : '');
    result += seconds;
  
    return result;
}

/**
 * Splits array into 2 sub-arrays starting after the specified items count. Example: [1, 2, 3, 4, 5], 3 => [1, 2, 3], [4, 5]
 * @param {array} array - Array to split
 * @param {number} count - Number of items coming into the first sub-array. The rest of items come into the second sub-array. If count is more than the array length, the second sub-array will be empty.
 * @returns {array} Array of 2 sub-arrays [[...], [...]]
 */
export function splitArray(array, count) {
    if (!array || !array.length) {
        return [[], []];
    }
    return [array.slice(0, count), array.slice(count)]
}

export function isInChatOrInventoryGui() {
	return Client.isInGui() && (Client.currentGui?.getClassName() === 'GuiInventory' || Client.currentGui?.getClassName() === 'GuiChatOF');
}

export function isInSacksGui() {
	const chestName = getCurrentGuiChestName();
	return (!!chestName && chestName.endsWith('Sack'));
}

export function isInSupercraftGui() {
	const chestName = getCurrentGuiChestName();
	return (!!chestName && chestName.endsWith('Recipe'));
}

export function getPlayerNamesInRange(distance) {
	const players = World
		.getAllPlayers()
		.filter(player =>
			(player.getUUID().version() === 4 || player.getUUID().version() === 1) && // Players and Watchdog have version 4, nicked players have version 1, this is done to exclude NPCs
			player.ping === 1 && // -1 is watchdog and ghost players, also there is a ghost player with high ping value when joining a world
			player.name != Player.getName() && // Exclude current player because they do not count for legion
			player.distanceTo(Player.getPlayer()) <= distance
		)
		.map(player => player.name)
		.filter((x, i, a) => a.indexOf(x) == i); // Distinct, sometimes the players are duplicated in the list
		
	return players;
}

export function getItemsAddedToSacks(eventMessage) {
	let items = [];

	const addedItemsMessage = new Message(eventMessage)
        .getMessageParts()
        .find(part => part.getHoverValue()?.includes('Added items:'))?.hoverValue || '';
    if (!addedItemsMessage) {
        return items;
    }
    
    const addedItemsRegex = new RegExp(/(\+[\d,]+) (.+) \((.+)\)/, "g"); // +1,344 Pufferfish (Fishing Sack)
    let match = addedItemsRegex.exec(addedItemsMessage);

    while (!!match) {
        const difference = +match[1]?.removeFormatting()?.replace(/\+/g, '')?.replace(/,/g, '') || 0;
        const itemName = match[2];
        const sackName = match[3]?.removeFormatting();
    
        if (!difference || !itemName) {
            match = addedItemsRegex.exec(addedItemsMessage);
            continue;
        }

		items.push({ itemName: itemName, difference: difference, sackName: sackName });
        match = addedItemsRegex.exec(addedItemsMessage);
    }

	return items;
}

export function getCleanItemName(itemName) {
    if (itemName && /.+ §8x[\d]+$/.test(itemName)) { // Booster cookie menu or NPCs append the amount to the item name - e.g. §9Fish Affinity Talisman §8x1
        const itemNameParts = itemName.split(' ');
        itemNameParts.pop();
        itemName = itemNameParts.join(' ');
    }
    const cleanItemName = itemName?.removeFormatting()?.replace(/§L/g, ''); // For some reason, §L is not deleted when calling removeFormatting (trophy fish) 
    return cleanItemName || '';
}

/**
 * Checks if an item is a fishing rod.
 * @param {Item} item
 * @returns {boolean}
 */
export function isFishingRod(item) {
	if (!item) return;
    const isRod = (!item.getName()?.includes('Carnival Rod') && getLore(item).some(loreLine => loreLine.includes('FISHING ROD') || loreLine.includes('FISHING WEAPON')));
	return isRod;
}

/**
 * Formats time elapsed between two dates in days, hours and minutes. Examples: "2d 8h 5m" or "less than 1m"
 * @param {Date} dateFrom - Earlier date
 * @param {Date} dateTo - Later date
 * @returns {string}
 */
export function formatTimeElapsedBetweenDates(dateFrom, dateTo = new Date()) {
	if (!dateFrom || !dateTo) {
		return '';
	}

	const totalSeconds = Math.floor((dateTo - dateFrom) / 1000);
	const totalMinutes = Math.floor(totalSeconds / 60);
	const totalHours = Math.floor(totalMinutes / 60);
	const totalDays = Math.floor(totalHours / 24);

	const days = totalDays;
	const hours = totalHours - (days * 24);
	const minutes = totalMinutes - (days * 24 * 60) - (hours * 60);
	const seconds = totalSeconds - (days * 24 * 60 * 60) - (hours * 60 * 60) - (minutes * 60);

	const isLessThanMinute = totalSeconds < 60;

	return isLessThanMinute
		? `less than 1m`
		: `${days > 0 ? days + 'd ' : ''}${days > 0 || hours > 0 ? hours + 'h ' : ''}${days > 0 || hours > 0 || minutes > 0 ? minutes + 'm' : ''}`;
}

/**
 * Get item's lore lines without item name. Native Item.getLore() interferes with other mods, e.g. it causes Skyhanni's estimated item value overlay to flash in /pv
 * @param {Item} item
 * @returns {array} Array of strings with lore lones
 */
export function getLore(item) {
	if (!item) {
		return [];
	}

    return item.getNBT().getCompoundTag('tag')?.getCompoundTag('display')?.toObject()?.Lore || [];
}

// Credits VolcAddons
/**
 * Adds a line combined from prefix and value, to the item's lore. If item's lore already contains the specified prefix, then line's value is updated by this prefix.
 * Example: for prefix "Expertise kills: " and value "800K", the added/updated lore line will be "Expertise kills: 800K"
 * @param {Item} item - Item whose lore to be modified
 * @param {string} prefix - String key to decide whether the line is already present in item's lore
 * @param {string} value - String value
 */
export function addLineToLore(item, prefix, value) {
	let loreLine = prefix + value;

	const loreTag = item.getNBT()?.getCompoundTag('tag')?.getCompoundTag('display')?.getTagMap()?.get('Lore');
	if (!loreTag) {
		return;
	}

	const list = new NBTTagList(loreTag);

	for (let i = 0; i < list.getTagCount(); i++) {
		if (list.getStringTagAt(i).includes(prefix)) {
			list.set(i, new NBTTagString(loreLine));
			return;
		}
	}

	list.appendTag(new NBTTagString(loreLine));
}

/**
 * Get item's attributes (if any).
 * @param {Item} item
 * @returns {array} Array of item's attributes in format [{ "attributeCode": "life_regeneration", "attributeLevel": 5 }]
 */
export function getItemAttributes(item) {
	if (!item) {
		return [];
	}

    const itemAttributes = item?.getNBT()?.getCompoundTag('tag')?.getCompoundTag('ExtraAttributes')?.getCompoundTag('attributes')?.toObject();
    if (!itemAttributes) {
        return [];
    }

    var attributes = [];
    Object.keys(itemAttributes).sort().forEach(attributeCode => {
        const level = itemAttributes[attributeCode];
		const code = attributeCode === 'mending' ? 'vitality' : attributeCode.toLowerCase();
		attributes.push({ attributeCode: code, attributeLevel: level });
    });

    return attributes;
}

/**
 * Get suitable article (A/An) depending on the passed string.
 * @param {string} str
 * @returns {string} Article (A/An)
 */
export function getArticle(str) {
    const isFirstLetterVowel = ['a', 'e', 'i', 'o', 'u'].indexOf(str[0].toLowerCase()) !== -1;
	return isFirstLetterVowel ? 'An' : 'A';
}

function getCurrentGuiChestName() {
	if (Client.isInGui() && Client.currentGui?.getClassName() === 'GuiChest') {
		const chestName = Client.currentGui?.get()?.field_147002_h?.func_85151_d()?.func_145748_c_()?.text;
		return chestName;
	}
	return null;
}