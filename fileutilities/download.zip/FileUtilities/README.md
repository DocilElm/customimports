# FileUtilities
FileUtilities ChatTriggers Module

```js
import FileUtilities from "../FileUtilities/main";;
```
This module provides extra utilities for files and directories not in the `FileLib` method. This includes the features of my module GZipper. All methods made before the `FileUtilities` class was implemented in 2.0.0 will remain available for use as before. For information on the functions look at DOCUMENTATION.md

[Github](https://github.com/Dolphin0xyz/FileUtilities)

Contact Dolphin0xyz#7887 on discord with inquiries
