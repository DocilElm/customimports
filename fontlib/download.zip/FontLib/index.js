const Font = Java.type("xyz.forkdev.fontlib.Font")
export default Font
