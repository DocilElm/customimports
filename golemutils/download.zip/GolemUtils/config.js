import { @Vigilant, @SwitchProperty, @SliderProperty, @PercentSliderProperty, @ButtonProperty, @SelectorProperty, @ColorProperty, Color } from "../Vigilance/index.js";

const categorytitle = "&6GolemUtils &7- by &5MinecraftSuchter &7/ &5MCSuchter"

@Vigilant("GolemUtils", "§6§lGolemUtils", {
    getCategoryComparator: () => (a, b) => {
        const categories = [
            "General",
            "On Screen",
            "World",
            "Bossbar",
            "Loot Tracker",
            "Sound & Titles",
            "Other",
            "Dragon"];
        return categories.indexOf(a.name) - categories.indexOf(b.name);
    },

    /*getSubcategoryComparator: () => (a, b) => {
        const subcategories = ["Overall", "Scanning method", "Color", "Location", "Countdown", "Time Since Stage 4", "Stage 4", "Stage 5", "Scheduled Update", "Game Update"];
        return subcategories.indexOf(a.getValue()[0].attributesExt.subcategory) - subcategories.indexOf(b.getValue()[0].attributesExt.subcategory);
    }*/
    /*
    getSubcategoryComparator: () => (a, b) => {
        const subcategories = [
            "§eOverall",
            "§eScanning method",
            "§eColor",
            "§eLocation",
            "§eStage",
            "§eCountdown",
            "§eTime Since Stage 4",
            "§eText",
            "§eBossbar",
            "§eToggle",
            "§eTitle",
            "§eSettings",
            "§eText",
            "§eStage 4",
            "§eStage 5",
            "§eScheduled Update",
            "§eGame Update",
            "§eUtilities",
            "§eCountdown",
            "§eDragon Utilities"];
        return subcategories.indexOf(a.getValue()[0].attributesExt.subcategory) - subcategories.indexOf(b.getValue()[0].attributesExt.subcategory);
    }
    */
})

class Settings {

    constructor() {
        this.initialize(this);
        this.setCategoryDescription("General", `&6&lGolemUtils\n
            &7by &5MinecraftSuchter &7/ &5MCSuchter\n
            &e&o/golemutils help &eto see all commands.`
        )
        this.setCategoryDescription("On Screen", categorytitle)
        this.setCategoryDescription("World", categorytitle)
        this.setCategoryDescription("Bossbar", categorytitle)
        this.setCategoryDescription("Loot Tracker", categorytitle)
        this.setCategoryDescription("Sound & Titles", categorytitle)
        this.setCategoryDescription("Other", categorytitle)
        this.setCategoryDescription("Dragon", categorytitle)


        this.addDependency("Color for all Texts", "Give all texts the same Color")

        this.addDependency("Golem Location Alignment", "Golem Location")
        this.addDependency("Text size for Location", "Golem Location")
        this.addDependency("Color for Location Text", "Golem Location")
        this.addDependency("Move Location Text", "Golem Location")

        this.addDependency("Golem Stage Alignment", "Golem Stage")
        this.addDependency("Text size for Stage", "Golem Stage")
        this.addDependency("Color for Stage Text", "Golem Stage")
        this.addDependency("Move Stage Text", "Golem Stage")

        this.addDependency("Golem Countdown delay message", "Golem Countdown")
        this.addDependency("Golem Countdown Alignment", "Golem Countdown")
        this.addDependency("Text size for Golem Countdown", "Golem Countdown")
        this.addDependency("Color for Golem Countdown Text", "Golem Countdown")
        this.addDependency("Move Golem Countdown Text", "Golem Countdown")

        this.addDependency("Send Since Stage 4 Time in chat", "Since Stage 4 timer")
        this.addDependency("Since Stage 4 Alignment", "Since Stage 4 timer")
        this.addDependency("Text size for Since Stage 4", "Since Stage 4 timer")
        this.addDependency("Color for Since Stage 4 Text", "Since Stage 4 timer")
        this.addDependency("Move Since Stage 4 Text", "Since Stage 4 timer")

        this.addDependency("Only show when Stage 4 or 5", "Show text next to the Golem")
        this.addDependency("Text size for statue text", "Show text next to the Golem")
        this.addDependency("Scale the text on distance", "Show text next to the Golem")
        this.addDependency("Color for statue text", "Show text next to the Golem")
        this.addDependency("Take color from On Screen category for Statue text", "Show text next to the Golem")
        this.addDependency("Grey background", "Show text next to the Golem")
        this.addDependency("X Offset for statue text", "Show text next to the Golem")
        this.addDependency("Y Offset for statue text", "Show text next to the Golem")
        this.addDependency("Z Offset for statue text", "Show text next to the Golem")

        this.addDependency("Show spawning progress", "Show Golem Bossbar")
        this.addDependency("Show health Number", "Show Golem Bossbar")
        this.addDependency('Say "Golem" above the Bossbar', "Show Golem Bossbar")

        this.addDependency("Stage 4 Sound volume", "Stage 4 Sound")
        this.addDependency("Stage 4 Sound Test", "Stage 4 Sound")

        this.addDependency("Stage 5 Sound volume", "Stage 5 Sound")
        this.addDependency("Stage 5 Sound Test", "Stage 5 Sound")

        this.addDependency("Reboot Volume", "Reboot Sound")
        this.addDependency("Reboot Sound Test", "Reboot Sound")

        this.addDependency("Update Volume", "Update Sound")
        this.addDependency("Update Sound Test", "Update Sound")

        this.addDependency("Dragon Countdown delay message", "Dragon Countdown")
        this.addDependency("Dragon Countdown Alignment", "Dragon Countdown")
        this.addDependency("Text size for Dragon Countdown", "Dragon Countdown")
        this.addDependency("Color for Dragon Countdown Text", "Dragon Countdown")
        this.addDependency("Take color from On Screen category for Dragon Countdown", "Dragon Countdown")
        this.addDependency("Move Dragon Countdown Text", "Dragon Countdown")
    }


    @SwitchProperty({
        name: "Overall",
        category: "General",
        subcategory: "§eOverall",
        description: "Toggle the whole Module",
    })
    overall = true

    @SwitchProperty({
        name: "Location & Stage scan everywhere in End",
        description: "Faster but uses a bit more performance (recommended)",
        category: "General",
        subcategory: "§eScanning method",
    })
    scaninend = true

    @SwitchProperty({
        name: "Increase scanning rate",
        description: "Faster but uses a bit more performance (recommended)",
        category: "General",
        subcategory: "§eScanning method",
    })
    scanningrate = true

    @SelectorProperty({
        name: "Change scanning speed",
        description: "Choose rate per minute\n&lAuto reloads CT Modules after closing\n&lthis settings menu &r(when changing something)",
        category: "General",
        subcategory: "§eScanning method",
        options: ["1 (pre 2.2.0 default)", "3 (new default)", "5 (recommended)", "10 (fast)", "15 (fastest)"]
    })
    scanningrate = 1;



    @SwitchProperty({
        name: "Give all texts the same Color",
        description: "Shoose Color below",
        category: "On Screen",
        subcategory: "§eColor",
    })
    colorforalltoggle = false

    @ColorProperty({
        name: "Color for all Texts",
        description: "Pick a color!",
        category: "On Screen",
        subcategory: "§eColor",
    })
    colorforalltext = Color.GREEN;



    @SwitchProperty({
        name: "Golem Location",
        description: "Shows Golem location onscreen",
        category: "On Screen",
        subcategory: "§eLocation",
    })
    glocation = true

    @SelectorProperty({
        name: "Golem Location Alignment",
        description: "Alignment for Golem Location",
        category: "On Screen",
        subcategory: "§eLocation",
        options: ["Left", "Right", "Center"]
    })
    locationa = 0;

    @SliderProperty({
        name: "Text size for Location",
        description: "Pick a Size (default 10)",
        min: 3,
        max: 50,
        category: "On Screen",
        subcategory: "§eLocation",
    })
    locations = 10;

    @ColorProperty({
        name: "Color for Location Text",
        description: "Pick a color!",
        category: "On Screen",
        subcategory: "§eLocation"
    })
    locationc = Color.GREEN;

    @ButtonProperty({
        name: "Move Location Text",
        description: "Press to move the location",
        category: "On Screen",
        subcategory: "§eLocation",
        placeholder: "Click!",
    })
    golemutilslocationbutton() {
        ChatLib.command("dgolemlocation", true)
    }



    @SwitchProperty({
        name: "Golem Stage",
        description: "Shows Golem Stage onscreen",
        category: "On Screen",
        subcategory: "§eStage",
    })
    gstage = true

    @SelectorProperty({
        name: "Golem Stage Alignment",
        description: "Alignment for Golem Stage",
        category: "On Screen",
        subcategory: "§eStage",
        options: ["Left", "Right", "Center"]
    })
    stagea = 0;

    @SliderProperty({
        name: "Text size for Stage",
        description: "Pick a Size (default 10)",
        min: 3,
        max: 50,
        category: "On Screen",
        subcategory: "§eStage",
    })
    stages = 10;

    @ColorProperty({
        name: "Color for Stage Text",
        description: "Pick a color!",
        category: "On Screen",
        subcategory: "§eStage"
    })
    stagec = Color.GREEN;

    @ButtonProperty({
        name: "Move Stage Text",
        description: "Press to move the location",
        category: "On Screen",
        subcategory: "§eStage",
        placeholder: "Click!",
    })
    golemutilsstagebutton() {
        ChatLib.command("dgolemstage", true)
    }



    @SwitchProperty({
        name: "Golem Countdown",
        description: "Shows Golem Countdown to spawn",
        category: "On Screen",
        subcategory: "§eCountdown",
    })
    gcountdown = true

    @SwitchProperty({
        name: "Golem Countdown delay message",
        description: "Sends message in chat for how long the Golem got delayed",
        category: "On Screen",
        subcategory: "§eCountdown",
    })
    gcountdowndelay = true

    @SelectorProperty({
        name: "Golem Countdown Alignment",
        description: "Alignment for Golem Countdown",
        category: "On Screen",
        subcategory: "§eCountdown",
        options: ["Left", "Right", "Center"]
    })
    gcountdowna = 0;

    @SliderProperty({
        name: "Text size for Golem Countdown",
        description: "Pick a Size (default 10)",
        min: 3,
        max: 50,
        category: "On Screen",
        subcategory: "§eCountdown",
    })
    gcountdowns = 10;

    @ColorProperty({
        name: "Color for Golem Countdown Text",
        description: "Pick a color!",
        category: "On Screen",
        subcategory: "§eCountdown"
    })
    gcountdownc = Color.GREEN;

    @ButtonProperty({
        name: "Move Golem Countdown Text",
        description: "Press to move the location",
        category: "On Screen",
        subcategory: "§eCountdown",
        placeholder: "Click!",
    })
    gcountdownbutton() {
        ChatLib.command("dgolemcountdown", true)
    }



    @SwitchProperty({
        name: "Since Stage 4 timer",
        description: "Displays Time Since Stage 4",
        category: "On Screen",
        subcategory: "§eTime Since Stage 4",
    })
    timesinces4 = true

    @SwitchProperty({
        name: "Send Since Stage 4 Time in chat",
        description: "sends the time in chat",
        category: "On Screen",
        subcategory: "§eTime Since Stage 4",
    })
    timesinces4chat = true

    @SelectorProperty({
        name: "Since Stage 4 Alignment",
        description: "Alignment for Since Stage 4",
        category: "On Screen",
        subcategory: "§eTime Since Stage 4",
        options: ["Left", "Right", "Center"]
    })
    timesinces4a = 0;

    @SliderProperty({
        name: "Text size for Since Stage 4",
        description: "Pick a Size (default 10)",
        min: 3,
        max: 50,
        category: "On Screen",
        subcategory: "§eTime Since Stage 4",
    })
    timesinces4s = 10;

    @ColorProperty({
        name: "Color for Since Stage 4 Text",
        description: "Pick a color!",
        category: "On Screen",
        subcategory: "§eTime Since Stage 4",
    })
    timesinces4c = Color.GREEN;

    @ButtonProperty({
        name: "Move Since Stage 4 Text",
        description: "Press to move the location",
        category: "On Screen",
        subcategory: "§eTime Since Stage 4",
        placeholder: "Click!",
    })
    timesinces4b() {
        ChatLib.command("dgolemsinces4", true)
    }



    @SwitchProperty({
        name: "Show text next to the Golem",
        description: "Used to locate him easier",
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetext = true

    @SwitchProperty({
        name: "Only show when Stage 4 or 5",
        description: "Hides the text when its not Stage 4 or 5",
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetexthide = false

    @SliderProperty({
        name: "Text size for statue text",
        description: "Pick a Size (default 15)",
        min: 3,
        max: 50,
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetexts = 15;

    @SwitchProperty({
        name: "Scale the text on distance",
        description: "Makes the text larger when being further away",
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetextscale = true

    @ColorProperty({
        name: "Color for statue text",
        description: "Pick a color!",
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetextc = Color.GREEN;

    @SwitchProperty({
        name: "Take color from On Screen category for Statue text",
        description: "ignores the above",
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetextcall = false

    @SwitchProperty({
        name: "Grey background",
        description: "give the text a grey background",
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetextbackground = true

    @SliderProperty({
        name: "X Offset for statue text",
        description: "X coordinate (default 0)",
        min: -10,
        max: 10,
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetextoffx = 0;

    @SliderProperty({
        name: "Y Offset for statue text",
        description: "Y coordinate (default 0)",
        min: -10,
        max: 10,
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetextoffy = 0;

    @SliderProperty({
        name: "Z Offset for statue text",
        description: "Z coordinate (default 0)",
        min: -10,
        max: 10,
        category: "World",
        subcategory: "§eText",
    })
    golemstatuetextoffz = 0;



    @SwitchProperty({
        name: "Show Golem Bossbar",
        description: "Shows a Bossbar for the Endstone Protector",
        category: "Bossbar",
        subcategory: "§eBossbar",
    })
    gshowbossbar = true

    @SwitchProperty({
        name: "Show spawning progress",
        description: "Just like when the Wither is spawning",
        category: "Bossbar",
        subcategory: "§eBossbar",
    })
    gshowbossbarloading = true

    @SwitchProperty({
        name: "Show health Number",
        description: "Shows maximum and current health",
        category: "Bossbar",
        subcategory: "§eBossbar",
    })
    gshowbossbarhealthnumber = true

    @SwitchProperty({
        name: 'Say "Golem" above the Bossbar',
        description: "Adds a Title to it",
        category: "Bossbar",
        subcategory: "§eBossbar",
    })
    gshowbossbarname = true



    @SwitchProperty({
        name: "Tier Boost Core Title",
        description: "Display a Title when dropping a Core",
        category: "Loot Tracker",
        subcategory: "§eTitle",
    })
    gtierboostcoretitle = true

    @SwitchProperty({
        name: "Legendary Golem Pet Title",
        description: "Display a Title when dropping a Legendary Golem",
        category: "Loot Tracker",
        subcategory: "§eTitle",
    })
    glegendarygolempettitle = true

    @SwitchProperty({
        name: "Epic Golem Pet Title",
        description: "Display a Title when dropping a Epic Golem",
        category: "Loot Tracker",
        subcategory: "§eTitle",
    })
    gepicgolempettitle = true



    @SwitchProperty({
        name: "Golem Loot Tracker Toggle",
        description: "Shows your Golem drops",
        category: "Loot Tracker",
        subcategory: "§eSettings",
    })
    gloottracker = true

    @SliderProperty({
        name: "Loot Tracker History amount",
        description: "How many values GolemUtils should save (default 50)",
        min: 10,
        max: 250,
        category: "Loot Tracker",
        subcategory: "§eSettings",
    })
    gloottrackerhistory = 50;
    
    @SelectorProperty({
        name: "Golem Loot Tracker Alignment",
        description: "Alignment for Golem Countdown",
        category: "Loot Tracker",
        subcategory: "§eSettings",
        options: ["Left", "Right", "Center"]
    })
    gloottrackera = 0;

    @SliderProperty({
        name: "Text size for Golem Loot Tracker",
        description: "Pick a Size (default 10)",
        min: 3,
        max: 50,
        category: "Loot Tracker",
        subcategory: "§eSettings",
    })
    gloottrackers = 10;

    @SwitchProperty({
        name: "Color the items as original in the Golem Loot Tracker",
        description: "for example Tier Boost Core is Gold then",
        category: "Loot Tracker",
        subcategory: "§eSettings",
    })
    gloottrackerrare = true

    @ColorProperty({
        name: "Color for Golem Loot Tracker Text",
        description: "Pick a color!",
        category: "Loot Tracker",
        subcategory: "§eSettings"
    })
    gloottrackerc = Color.GREEN;

    @SwitchProperty({
        name: "Take color from On Screen category for Golem Loot Tracker",
        description: "ignores the above",
        category: "Loot Tracker",
        subcategory: "§eSettings",
    })
    gloottrackercall = false

    @ButtonProperty({
        name: "Move Golem Loot Tracker Text",
        description: "Press to move the location",
        category: "Loot Tracker",
        subcategory: "§eSettings",
        placeholder: "Click!",
    })
    gloottrackerbutton() {
        ChatLib.command("dgolemloottracker", true)
    }



    @SwitchProperty({
        name: "Golem Loot Tracker Kills",
        description: "Shows your amount of Kills in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerkills = true

    @SwitchProperty({
        name: "Golem Loot Tracker time since last Kill",
        description: "Shows you time since last Kill in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackersincelastkill = true

    @SwitchProperty({
        name: "Golem Loot Tracker Last Hits",
        description: "Shows your amount of Last Hits in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlasthits = false

    @SwitchProperty({
        name: "Golem Loot Tracker time since last hit",
        description: "Shows you time since last hit in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackersincelasthit = false

    @SwitchProperty({
        name: "Golem Loot Tracker last hit percentage",
        description: "Shows your last hit average in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlasthitavg = true

    @SwitchProperty({
        name: "Golem Loot Tracker last damage",
        description: "Shows your last damage in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlastdamage = false

    @SwitchProperty({
        name: "Golem Loot Tracker avg damage",
        description: "Shows your avg damage (last 10) in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackeravgdamage = false

    @SwitchProperty({
        name: "Golem Loot Tracker last dps",
        description: "Shows your last dps in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlastdps = false

    @SwitchProperty({
        name: "Golem Loot Tracker avg dps",
        description: "Shows your avg dps (last 10) in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackeravgdps = true




    @SwitchProperty({
        name: "Golem Loot Tracker last Since S4 Time",
        description: "Shows your last Since S4 Time in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlastsinces4time = false

    @SwitchProperty({
        name: "Golem Loot Tracker avg Since S4 Time",
        description: "Shows your avg Since S4 Time (last 10) in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackeravgsinces4time = true

    @SwitchProperty({
        name: "Golem Loot Tracker last Delay Time",
        description: "Shows your last Delay Time in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlastdelaytime = false

    @SwitchProperty({
        name: "Golem Loot Tracker avg Delay Time",
        description: "Shows your avg Delay Time (last 10) in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackeravgdelaytime = false

    @SwitchProperty({
        name: "Golem Loot Tracker last Fight Time",
        description: "Shows your last dps in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlastfighttime = false

    @SwitchProperty({
        name: "Golem Loot Tracker avg Fight Time",
        description: "Shows your avg Fight Time (last 10) in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackeravgfighttime = true

    @SwitchProperty({
        name: "Golem Loot Tracker last position",
        description: "Shows your last position in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlastposition = false

    @SwitchProperty({
        name: "Golem Loot Tracker Zealot kills",
        description: "Shows your total Zealot kills in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerzealots = false

    @SwitchProperty({
        name: "Golem Loot Tracker Runecrafting XP",
        description: "Shows your total earned Runecrafting XP in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerrunecraftingxp = true

    @SwitchProperty({
        name: "Golem Loot Tracker Bits",
        description: "Shows your total earned Bits in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerbits = false

    @SwitchProperty({
        name: "Golem Loot Tracker Enstone Rose",
        description: "Shows your amount of Enstone Rose in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerendstonerose = false

    @SwitchProperty({
        name: "Golem Loot Tracker Enchanted End Stone",
        description: "Shows your amount of Enchanted End Stone in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerenchantedendstone = false

    @SwitchProperty({
        name: "Golem Loot Tracker Crystal Fragments",
        description: "Shows your amount of Crystal Fragments in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackercrystalfragments = false

    @SwitchProperty({
        name: "Golem Loot Tracker Epic Golem Pets",
        description: "Shows your amount of Epic Golem Pets in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerepicgolempets = true

    @SwitchProperty({
        name: "Golem Loot Tracker time since last Epic Golem Pet",
        description: "Shows you time since last Epic Golem Pet in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackersinceepicgolempet = false

    @SwitchProperty({
        name: "Golem Loot Tracker Epic Golem Pet percentage",
        description: "Shows your Epic Golem Pet average in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerepicgolempetavg = true

    @SwitchProperty({
        name: "Golem Loot Tracker Legendary Golem Pets",
        description: "Shows your amount of Legendary Golem Pets in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlegendarygolempets = true

    @SwitchProperty({
        name: "Golem Loot Tracker time since last Legendary Golem Pet",
        description: "Shows you time since last Legendary Golem Pet in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackersincelegendarygolempet = false

    @SwitchProperty({
        name: "Golem Loot Tracker Legendary Golem Pet percentage",
        description: "Shows your Legendary Golem Pet average in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackerlegendarygolempetavg = true

    @SwitchProperty({
        name: "Golem Loot Tracker Tier Boost Cores",
        description: "Shows your amount of Tier Boost Cores in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackertierboostcore = true

    @SwitchProperty({
        name: "Golem Loot Tracker time since last Tier Boost Core",
        description: "Shows you time since last Tier Boost Core in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackersincetierboostcore = true

    @SwitchProperty({
        name: "Golem Loot Tracker Tier Boost Core percentage",
        description: "Shows your Tier Boost Core average in the Loot Tracker",
        category: "Loot Tracker",
        subcategory: "§eText - Tracker",
    })
    gloottrackertierboostcoreavg = true



    @SwitchProperty({
        name: "Stage 4 Title",
        description: "Shows a Title when Stage 4 is found",
        category: "Sound & Titles",
        subcategory: "§eStage 4",
    })
    stage4title = true

    @SwitchProperty({
        name: "Stage 4 Sound",
        description: "Plays sound when Stage 4 is found",
        category: "Sound & Titles",
        subcategory: "§eStage 4",
    })
    stage4sound = true

    @SliderProperty({
        name: "Stage 4 Sound volume",
        description: "Could be very loud (default 50)",
        min: 0,
        max: 100,
        category: "Sound & Titles",
        subcategory: "§eStage 4",
    })
    stage4volume = 50;

    @ButtonProperty({
        name: "Stage 4 Sound Test",
        description: "To test sound",
        category: "Sound & Titles",
        subcategory: "§eStage 4",
        placeholder: "Click!",
    })
    cstage4test() {
        ChatLib.command("cstage4test", true)
    }

    @SwitchProperty({
        name: "Stage 5 Title",
        description: "Shows a Title when Stage 5 is found",
        category: "Sound & Titles",
        subcategory: "§eStage 5",
    })
    stage5title = true

    @SwitchProperty({
        name: "Stage 5 Sound",
        description: "Plays sound when Stage 5 is found",
        category: "Sound & Titles",
        subcategory: "§eStage 5",
    })
    stage5sound = true

    @SliderProperty({
        name: "Stage 5 Sound volume",
        description: "Could be very loud (default 50)",
        min: 0,
        max: 100,
        category: "Sound & Titles",
        subcategory: "§eStage 5",
    })
    stage5volume = 50;

    @ButtonProperty({
        name: "Stage 5 Sound Test",
        description: "To test sound",
        category: "Sound & Titles",
        subcategory: "§eStage 5",
        placeholder: "Click!",
    })
    cstage5test() {
        ChatLib.command("cstage5test", true)
    }

    @SwitchProperty({
        name: "Reboot Sound",
        description: "Toggle Sound for Scheduled Reboot",
        category: "Sound & Titles",
        subcategory: "§eScheduled Update",
    })
    sreboots = true

    @SliderProperty({
        name: "Reboot Volume",
        description: "Could be very loud (default 50)",
        min: 0,
        max: 100,
        category: "Sound & Titles",
        subcategory: "§eScheduled Update",
    })
    srebootvolume = 50;

    @ButtonProperty({
        name: "Reboot Sound Test",
        description: "To test sound",
        category: "Sound & Titles",
        subcategory: "§eScheduled Update",
        placeholder: "Click!",
    })
    creboottest() {
        ChatLib.command("creboottest", true)
    }

    @SwitchProperty({
        name: "Update Sound",
        description: "Toggle Sound for Update Reboot",
        category: "Sound & Titles",
        subcategory: "§eGame Update",
    })
    ureboots = true

    @SliderProperty({
        name: "Update Volume",
        description: "Could be very loud (default 50)",
        min: 0,
        max: 100,
        category: "Sound & Titles",
        subcategory: "§eGame Update",
    })
    urebootvolume = 50;

    @ButtonProperty({
        name: "Update Sound Test",
        description: "To test sound",
        category: "Sound & Titles",
        subcategory: "§eGame Update",
        placeholder: "Click!",
    })
    cupdatetest() {
        ChatLib.command("cupdatetest", true)
    }




    @SwitchProperty({
        name: "Golem fight timer",
        description: "Sends message in chat with fight time",
        category: "Other",
        subcategory: "§eUtilities",
    })
    gfight = true

    @SwitchProperty({
        name: "Golem DPS",
        description: "Sends message in chat with your Golem DPS (also Top 3)",
        category: "Other",
        subcategory: "§eUtilities",
    })
    gdps = true

    @SwitchProperty({
        name: "Drop Quality",
        description: "Gives information about your possible drops",
        category: "Other",
        subcategory: "§eUtilities",
    })
    gdrops = true

    @SwitchProperty({
        name: "Restart checker",
        description: "Usually server restart after day 31",
        category: "Other",
        subcategory: "§eUtilities",
    })
    serverday = true

    @SwitchProperty({
        name: "Click playernames to pv",
        description: "Click playername in Leaderboard to pv with NEU",
        category: "Other",
        subcategory: "§eUtilities",
    })
    pvleaderboard = true



    @SwitchProperty({
        name: "Dragon Countdown",
        description: "Shows Dragon Countdown to spawn",
        category: "Dragon",
        subcategory: "§eCountdown",
    })
    dcountdown = true

    @SwitchProperty({
        name: "Dragon Countdown delay message",
        description: "Sends message in chat for how long the Dragon got delayed",
        category: "Dragon",
        subcategory: "§eCountdown",
    })
    dcountdowndelay = true

    @SelectorProperty({
        name: "Dragon Countdown Alignment",
        description: "Alignment for Dragon Countdown",
        category: "Dragon",
        subcategory: "§eCountdown",
        options: ["Left", "Right", "Center"]
    })
    dcountdowna = 0;

    @SliderProperty({
        name: "Text size for Dragon Countdown",
        description: "Pick a Size (default 10)",
        min: 3,
        max: 50,
        category: "Dragon",
        subcategory: "§eCountdown",
    })
    dcountdowns = 10;

    @ColorProperty({
        name: "Color for Dragon Countdown Text",
        description: "Pick a color!",
        category: "Dragon",
        subcategory: "§eCountdown"
    })
    dcountdownc = Color.GREEN;

    @SwitchProperty({
        name: "Take color from On Screen category for Dragon Countdown",
        description: "ignores the above",
        category: "Dragon",
        subcategory: "§eCountdown",
    })
    dcountdowncall = false

    @ButtonProperty({
        name: "Move Dragon Countdown Text",
        description: "Press to move the location",
        category: "Dragon",
        subcategory: "§eCountdown",
        placeholder: "Click!",
    })
    dcountdownbutton() {
        ChatLib.command("ddragoncountdown", true)
    }



    @SwitchProperty({
        name: "Dragon fight timer",
        description: "Sends message in chat with fight time",
        category: "Dragon",
        subcategory: "§eDragon Utilities",
    })
    dfight = true

    @SwitchProperty({
        name: "Dragon DPS",
        description: "Sends message in chat with your Dragon DPS (also Top 3)",
        category: "Dragon",
        subcategory: "§eDragon Utilities",
    })
    ddps = true
}

export default new Settings;