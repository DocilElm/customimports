/// <reference types="../CTAutocomplete" />
/// <reference lib="es2015" />

import Settings from "./config.js"
import PogObject from "../PogData"

/*
  #####                                   #     #                           
 #     #   ####   #       ######  #    #  #     #  #####  #  #        ####  
 #        #    #  #       #       ##  ##  #     #    #    #  #       #      
 #  ####  #    #  #       #####   # ## #  #     #    #    #  #        ####  
 #     #  #    #  #       #       #    #  #     #    #    #  #            # 
 #     #  #    #  #       #       #    #  #     #    #    #  #       #    # 
  #####    ####   ######  ######  #    #   #####     #    #  ######   ####  
https://www.messletters.com/de/big-text/ banner
*/
/*
 ######                          
 #     #    ##     ####   ###### 
 #     #   #  #   #       #      
 ######   #    #   ####   #####  
 #     #  ######       #  #      
 #     #  #    #  #    #  #      
 ######   #    #   ####   ###### 
*/
const prefix = "&7[&6GolemUtils&7]&6"
const StartSeparator = "&b&m------------------------&r  &6GolemUtils  &b&m------------------------&r"
const EndSeparator = "&b&m-------------------------------------------------------------&r"

const EntityArmorStand = Java.type("net.minecraft.entity.item.EntityArmorStand");


let gloottrackertextcmd
register("command", (...args) => {
	if (args[0] == undefined) {
		Settings.openGUI()
	} else if (args[0].toLowerCase() === "settings") {
		Settings.openGUI()
	} else if (!Settings.overall) {
		ChatLib.chat(new Message(`${prefix} You disabled GolemUtils, turn it on in the Settings (turn on Overall) `, new TextComponent("&6[Settings]").setClick("run_command", "/golemutils").setHoverValue("&eClick to run command")));
	} else if (args[0].toLowerCase() === "move") {
		if (args[1]?.toLowerCase() == "location") {
			ChatLib.command("dgolemlocation", true)
		} else if (args[1]?.toLowerCase() == "stage") {
			ChatLib.command("dgolemstage", true)
		} else if (args[1]?.toLowerCase() == "golemcountdown") {
			ChatLib.command("dgolemcountdown", true)
		} else if (args[1]?.toLowerCase() == "sinces4") {
			ChatLib.command("dgolemsinces4", true)
		} else if (args[1]?.toLowerCase() == "golemloottracker") {
			ChatLib.command("dgolemloottracker", true)
		} else if (args[1]?.toLowerCase() == "dragoncountdown") {
			ChatLib.command("ddragoncountdown", true)
		} else {
			commandpossibleargs(["location", "stage", "golemcountdown", "sinces4", "golemloottracker", "dragoncountdown"])
		}
	} else if (args[0].toLowerCase() == "lootcalc") {
		if (args[1, 2, 3] != undefined) {
			if (!Number.isInteger(parseInt(args[1])) || !Number.isInteger(parseInt(args[2])) || !Number.isInteger(parseInt(args[3])) || !Number.isInteger(parseInt(args[4]))) {
				integerhelp()
			} else {
				if (args[1] == 1) args[1] = 200;
				else if (args[1] == 2) args[1] = 175;
				else if (args[1] == 3) args[1] = 150;
				else if (args[1] == 4) args[1] = 125;
				else if (args[1] == 5) args[1] = 110;
				else if (args[1] >= 6 && args[1] <= 8) args[1] = 100;
				else if (args[1] == 9 || args[1] == 10) args[1] = 90;
				else if (args[1] == 11 || args[1] == 12) args[1] = 80;
				else if (args[1] >= 13) args[1] = 70;
				args[1] = parseInt(args[1])

				if (args[4] > 100) { args[4] = 100 }
				else args[4] = parseInt(args[4])

				args[2] = parseInt(args[2].replace(/\,/g, ""))
				args[3] = parseInt(args[3].replace(/\,/g, ""))

				if (args[2] > args[3]) {
					ChatLib.chat(`${prefix} [YourDamage] is higher then [FirstPlaceDamage].`)
					return
				}

				let glootquality = Math.round(args[1] + (50 * (args[2] / args[3])) + args[4])

				let glootcalctext
				if (glootquality >= 250) { glootcalctext = "&6&lPossible Golem Loot\n&eTier Boost Core &a✔ (250)\n&eLegendary Golem Pet &a✔ (235)\n&eEpic Golem Pet &a✔ (220)" }
				else if (glootquality <= 249 && glootquality >= 235) { glootcalctext = "&6&lPossible Golem Loot\n&eTier Boost Core &c✖ (250)\n&eLegendary Golem Pet &a✔ (235)\n&eEpic Golem Pet &a✔ (220)" }
				else if (glootquality <= 234 && glootquality >= 220) { glootcalctext = "&6&lPossible Golem Loot\n&eTier Boost Core &c✖ (250)\n&eLegendary Golem Pet &c✖ (235)\n&eEpic Golem Pet &a✔ (220)" }
				else if (glootquality <= 219) { glootcalctext = "&6&lPossible Golem Loot\n&eTier Boost Core &c✖ (250)\n&eLegendary Golem Pet &c✖ (235)\n&eEpic Golem Pet &c✖ (220)" }

				ChatLib.chat(new Message(`${prefix} That would be &6&o${glootquality} &6loot Quality. `, new TextComponent("&6[HOVER]").setHoverValue(`${glootcalctext}\n\n&6You Insered:\n&ePlace: ${args[1]}\n&eYour Damage: ${args[2].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}\n&eFirst Place Damage: ${args[3].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}\n&eContribution: ${args[4]}`)));
			}
		} else {
			ChatLib.chat(new TextComponent(`${prefix} &e/golemutils lootcalc [Place] [YourDamage] [FirstPlaceDamage] [Contribution] &7&o- Calculate possible Golem Loot.`).setClick("suggest_command", "/golemutils lootcalc [Place] [YourDamage] [FirstPlaceDamage] [Contribution]").setHoverValue("&eClick to copy into chat."))
		}
	} else if (args[0].toLowerCase() == "loottracker") {
		if (args[1] == undefined) {
			sendgtrackerHelp()
		} else if (args[1].toLowerCase() == "stats") {
			gloottrackertextcmd = true
			ChatLib.chat(gloottrackertextfunc().join("\n&e"))
			gloottrackertextcmd = false
		} else if (args[1].toLowerCase() == "history") {
			if (args[2]?.toLowerCase() == "damage") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.Damage, args[2].toLowerCase(), "Damage", 0)
			} else if (args[2]?.toLowerCase() == "dps") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.DPS, args[2].toLowerCase(), "DPS", 0)
			} else if (args[2]?.toLowerCase() == "position") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.Position_History, args[2].toLowerCase(), "Position History", 0)
			} else if (args[2]?.toLowerCase() == "sinces4time") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.Since_S4_Time, args[2].toLowerCase(), "Since S4 Time", 0)
			} else if (args[2]?.toLowerCase() == "delaytime") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.Delay_Time, args[2].toLowerCase(), "Delay Time", 0)
			} else if (args[2]?.toLowerCase() == "fighttime") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.Delay_Time, args[2].toLowerCase(), "Fight Time", 0)
			} else if (args[2]?.toLowerCase() == "epicgolempet") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.Epic_Golem_Pet_History, args[2].toLowerCase(), "Epic Golem Pets", 1)
			} else if (args[2]?.toLowerCase() == "legendarygolempet") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.Legendary_Golem_Pet_History, args[2].toLowerCase(), "Legendary Golem Pets", 1)
			} else if (args[2]?.toLowerCase() == "tierboostcore") {
				loottrackerhistory(args[3], pogdata.GolemLootTracker.Tier_Boost_Core_History, args[2].toLowerCase(), "Tier Boost Cores", 1)
			} else {
				commandpossibleargs(golemutilsloottrackerhistory)
			}
		}
		else if (["add", "set"].includes(args[1].toLowerCase())) {
			if (args[2]?.toLowerCase() == "kills") {
				pogdata.GolemLootTracker.Kills = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Kills, "Kills")
			} else if (args[2]?.toLowerCase() == "lasthits") {
				pogdata.GolemLootTracker.Last_Hits = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Last_Hits, "Last Hits")
			} else if (args[2]?.toLowerCase() == "position") {
				pogdata.GolemLootTracker.Position = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Position, "Position")
			} else if (args[2]?.toLowerCase() == "zealots") {
				pogdata.GolemLootTracker.Zealots = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Zealots, "Zealots")
			} else if (args[2]?.toLowerCase() == "runecraftingxp") {
				pogdata.GolemLootTracker.RunecraftingXP = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.RunecraftingXP, "Runecrafting XP")
			} else if (args[2]?.toLowerCase() == "bits") {
				pogdata.GolemLootTracker.Bits = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Bits, "Bits")
			} else if (args[2]?.toLowerCase() == "endstonerose") {
				pogdata.GolemLootTracker.Endstone_Rose = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Endstone_Rose, "Endstone Roses")
			} else if (args[2]?.toLowerCase() == "enchantedendstone") {
				pogdata.GolemLootTracker.Enchanted_End_Stone = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Enchanted_End_Stone, "Enchanted End Stone")
			} else if (args[2]?.toLowerCase() == "crystalfragment") {
				pogdata.GolemLootTracker.Crystal_Fragment = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Crystal_Fragment, "Crystal Fragments")
			} else if (args[2]?.toLowerCase() == "epicgolempet") {
				pogdata.GolemLootTracker.Epic_Golem_Pet = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Epic_Golem_Pet, "Epic Golem Pets")
			} else if (args[2]?.toLowerCase() == "legendarygolempet") {
				pogdata.GolemLootTracker.Legendary_Golem_Pet = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Legendary_Golem_Pet, "Legendary Golem Pets")
			} else if (args[2]?.toLowerCase() == "tierboostcore") {
				pogdata.GolemLootTracker.Tier_Boost_Core = loottrackermodify(args[1], args[2], args[3], pogdata.GolemLootTracker.Tier_Boost_Core, "Tier Boost Cores")
			} else {
				commandpossibleargs(golemutilsloottrackeraddset)
			}
			pogdata.save()
		} else if (args[1].toLowerCase() == "reset") {
			if (args[2]?.toLowerCase() == "all") {
				pogdata.GolemLootTracker.Kills = 0
				pogdata.GolemLootTracker.Since_Last_Kill = 0
				pogdata.GolemLootTracker.Last_Hits = 0
				pogdata.GolemLootTracker.Since_Last_Hits = 0
				pogdata.GolemLootTracker.Damage = []
				pogdata.GolemLootTracker.DPS = []
				pogdata.GolemLootTracker.Position = 0
				pogdata.GolemLootTracker.Position_History = []
				pogdata.GolemLootTracker.Since_S4_Time = []
				pogdata.GolemLootTracker.Delay_Time = []
				pogdata.GolemLootTracker.Fight_Time = []
				pogdata.GolemLootTracker.Zealots = 0
				pogdata.GolemLootTracker.RunecraftingXP = 0
				pogdata.GolemLootTracker.Bits = 0
				pogdata.GolemLootTracker.Endstone_Rose = 0
				pogdata.GolemLootTracker.Enchanted_End_Stone = 0
				pogdata.GolemLootTracker.Crystal_Fragment = 0
				pogdata.GolemLootTracker.Epic_Golem_Pet = 0
				pogdata.GolemLootTracker.Epic_Golem_Pet_History = []
				pogdata.GolemLootTracker.Legendary_Golem_Pet = 0
				pogdata.GolemLootTracker.Legendary_Golem_Pet_History = []
				pogdata.GolemLootTracker.Tier_Boost_Core = 0
				pogdata.GolemLootTracker.Tier_Boost_Core_History = []
				ChatLib.chat(`${prefix} Reset all stats!`)
			} else if (args[2]?.toLowerCase() == "kills") {
				pogdata.GolemLootTracker.Kills = 0
				ChatLib.chat(`${prefix} Reset Golem Kill count.`)
			} else if (args[2]?.toLowerCase() == "sincekill") {
				pogdata.GolemLootTracker.Since_Last_Kill = 0
				ChatLib.chat(`${prefix} Reset Golem Since Last Kill.`)
			} else if (args[2]?.toLowerCase() == "lasthits") {
				pogdata.GolemLootTracker.Last_Hits = 0
				ChatLib.chat(`${prefix} Reset Golem Last Hits count.`)
			} else if (args[2]?.toLowerCase() == "sincelasthit") {
				pogdata.GolemLootTracker.Since_Last_Hits = 0
				ChatLib.chat(`${prefix} Reset Golem Since Last Hit.`)
			} else if (args[2]?.toLowerCase() == "damage") {
				pogdata.GolemLootTracker.Damage = []
				ChatLib.chat(`${prefix} Reset Golem Damage History.`)
			} else if (args[2]?.toLowerCase() == "dps") {
				pogdata.GolemLootTracker.DPS = []
				ChatLib.chat(`${prefix} Reset Golem DPS History.`)
			} else if (args[2]?.toLowerCase() == "position") {
				pogdata.GolemLootTracker.Position = 0
				ChatLib.chat(`${prefix} Reset Last Golem Position.`)
			} else if (args[2]?.toLowerCase() == "positionhistory") {
				pogdata.GolemLootTracker.Position_History = []
				ChatLib.chat(`${prefix} Reset Golem Position History.`)
			} else if (args[2]?.toLowerCase() == "sinces4time") {
				pogdata.GolemLootTracker.Since_S4_Time = []
				ChatLib.chat(`${prefix} Reset Golem Since S4 Time History.`)
			} else if (args[2]?.toLowerCase() == "delaytime") {
				pogdata.GolemLootTracker.Delay_Time = []
				ChatLib.chat(`${prefix} Reset Golem Delay Time History.`)
			} else if (args[2]?.toLowerCase() == "fighttime") {
				pogdata.GolemLootTracker.Fight_Time = []
				ChatLib.chat(`${prefix} Reset Golem Fight Time History.`)
			} else if (args[2]?.toLowerCase() == "endstonerose") {
				pogdata.GolemLootTracker.Endstone_Rose = 0
				ChatLib.chat(`${prefix} Reset Endstone Rose count.`)
			} else if (args[2]?.toLowerCase() == "enchantedendstone") {
				pogdata.GolemLootTracker.Enchanted_End_Stone = 0
				ChatLib.chat(`${prefix} Reset Enchanted End Stone count.`)
			} else if (args[2]?.toLowerCase() == "crystalfragment") {
				pogdata.GolemLootTracker.Crystal_Fragment = 0
				ChatLib.chat(`${prefix} Reset Crystal Fragment count.`)
			} else if (args[2]?.toLowerCase() == "epicgolempet") {
				pogdata.GolemLootTracker.Epic_Golem_Pet = 0
				ChatLib.chat(`${prefix} Reset Epic Golem Pet count.`)
			} else if (args[2]?.toLowerCase() == "epicgolempethistory") {
				pogdata.GolemLootTracker.Epic_Golem_Pet_History = []
				ChatLib.chat(`${prefix} Reset Epic Golem Pet History.`)
			} else if (args[2]?.toLowerCase() == "legendarygolempet") {
				pogdata.GolemLootTracker.Legendary_Golem_Pet = 0
				ChatLib.chat(`${prefix} Reset Legendary Golem Pet count.`)
			} else if (args[2]?.toLowerCase() == "legendarygolempethistory") {
				pogdata.GolemLootTracker.Legendary_Golem_Pet_History = []
				ChatLib.chat(`${prefix} Reset Legendary Golem Pet History.`)
			} else if (args[2]?.toLowerCase() == "tierboostcore") {
				pogdata.GolemLootTracker.Tier_Boost_Core = 0
				ChatLib.chat(`${prefix} Reset Tier Boost Core count.`)
			} else if (args[2]?.toLowerCase() == "tierboostcorehistory") {
				pogdata.GolemLootTracker.Tier_Boost_Core_History = []
				ChatLib.chat(`${prefix} Reset Tier Boost Core History.`)
			} else {
				commandpossibleargs(golemutilsloottrackerreset)
			}
			pogdata.save()
		} else {
			sendgtrackerHelp()
		}
	} else {
		senddefaultHelp()
	}
}).setTabCompletions((args) => {
	if (args.length == 1) {
		return tabcomplete(args[0], golemutilshelp)
	} else if (args.length == 2) {
		if (args[0] == "move") {
			return tabcomplete(args[1], golemutilsmove)
		} else if (args[0] == "lootcalc") {
			return tabcomplete(args[1], ["help"])
		} else if (args[0] == "loottracker") {
			return tabcomplete(args[1], golemutilsloottracker)
		} else {
			return [args[args.length - 1]]
		}
	} else if (args.length == 3) {
		if (args[0] == "loottracker") {
			if (args[1] == "history") {
				return tabcomplete(args[2], golemutilsloottrackerhistory)
			} else if (["add", "set"].includes(args[1])) {
				return tabcomplete(args[2], golemutilsloottrackeraddset)
			} else if (args[1] == "reset") {
				return tabcomplete(args[2], golemutilsloottrackerreset)
			} else {
				return [args[args.length - 1]]
			}
		} else {
			return [args[args.length - 1]]
		}
	} else {
		return [args[args.length - 1]]
	}
}).setName("golemutils", true)

function tabcomplete(argin, arrayin) {
	let output = []
	arrayin.forEach(arglist => {
		if (arglist.startsWith(argin)) {
			output.push(arglist)
		}
	})
	if (output.length > 0) {
		return output
	} else {
		return [argin]
	}
}

function senddefaultHelp() {
	const senddefaultHelpmessage = new Message(
		`${StartSeparator}\n`,
		new TextComponent(" &c• &e/golemutils\n   &7&o- Open the Settings menu.\n").setClick("suggest_command", "/golemutils").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &e/golemutils move\n   &7&o- Command to move onscreen stuff.\n").setClick("suggest_command", "/golemutils move").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &e/golemutils lootcalc [Place] [YourDamage] [FirstPlaceDamage] [Contribution]\n   &7&o- Calculate possible Golem Loot.\n").setClick("suggest_command", "/golemutils lootcalc [Place] [YourDamage] [FirstPlaceDamage] [Contribution]").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &e/golemutils loottracker help\n   &7&o- Gives you the loottracker help menu.\n").setClick("suggest_command", "/golemutils loottracker help").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &e/golemutils help\n   &7&o- Sends this help message.\n").setClick("suggest_command", "/golemutils help").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &5Discord\n   &7&o- Golemers Discord Invite Link.\n").setClick("open_url", "https://discord.gg/p3YA45XXhc").setHoverValue("&eClick to join Discord"),
		"  &a✯ &eUse tab for autocomplete &a✯",
		EndSeparator
	)
	ChatLib.chat(senddefaultHelpmessage);
}

function sendgtrackerHelp() {
	const sendgtrackerHelpmessage = new Message(
		`${StartSeparator}\n`,
		new TextComponent(" &c• &e/golemutils loottracker stats\n   &7&o- Gives you all stats.\n").setClick("suggest_command", "/golemutils loottracker stats").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &e/golemutils loottracker history [item]\n   &7&o- Gives you a History of the given item.\n").setClick("suggest_command", "/golemutils loottracker history [item]").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &e/golemutils loottracker [add/set] [item] [count]\n   &7&o- Add or Set the given item to your given value.\n").setClick("suggest_command", "/golemutils loottracker [add/set] [item] [count]").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &e/golemutils loottracker reset [all/item]\n   &7&o- Reset all or the value of the given item.\n").setClick("suggest_command", "/golemutils loottracker reset [all/item]").setHoverValue("&eClick to copy into chat."),
		new TextComponent(" &c• &e/golemutils loottracker help\n   &7&o- Gives you this menu.\n").setClick("suggest_command", "/golemutils loottracker help").setHoverValue("&eClick to copy into chat."),
		"  &a✯ &eUse tab for autocomplete &a✯",
		EndSeparator
	)
	ChatLib.chat(sendgtrackerHelpmessage);
}

function integerhelp() {
	ChatLib.chat(`${prefix} You need to input integer numbers!`)
}

function commandpossibleargs(argarray) {
	ChatLib.chat(`${prefix} Possible Inputs: ${argarray.join(", ")}`)
}

const golemutilshelp = ["move", "lootcalc", "loottracker", "settings", "help"]
const golemutilsmove = ["location", "stage", "golemcountdown", "sinces4", "golemloottracker", "dragoncountdown"]
const golemutilsloottracker = ["stats", "history", "add", "set", "reset", "help"]
const golemutilsloottrackerhistory = ["damage", "dps", "position", "sinces4time", "delaytime", "fighttime", "epicgolempet", "legendarygolempet", "tierboostcore"]
const golemutilsloottrackeraddset = ["kills", "lasthits", "position", "zealots", "runecraftingxp", "bits", "endstonerose", "enchantedendstone", "crystalfragment", "epicgolempet", "legendarygolempet", "tierboostcore"]
const golemutilsloottrackerreset = ["all", "kills", "sincekill", "lasthits", "sincelasthit", "damage", "dps", "position", "positionhistory", "sinces4time", "delaytime", "fighttime", "zealots", "runecraftingxp", "bits", "endstonerose", "enchantedendstone", "crystalfragment", "epicgolempet", "epicgolempethistory", "legendarygolempet", "legendarygolempethistory", "tierboostcore", "tierboostcorehistory"]

function loottrackerhistory(pagein, array, cmd, displayname, mode) {
	let stringarray = []
	stringarray.push(StartSeparator)
	let p
	if (mode == 0) {
		if (pagein == undefined || !Number.isInteger(parseInt(pagein)) || parseInt(pagein) <= 0) {
			p = 1
		} else if (parseInt(pagein) > Math.ceil(array.length / 10)) {
			p = Math.ceil(array.length / 10)
		} else {
			p = parseInt(pagein)
		}
	} else if (mode == 1) {
		if (pagein == undefined || !Number.isInteger(parseInt(pagein)) || parseInt(pagein) <= 0) {
			p = 1
		} else if (parseInt(pagein) > Math.ceil(array.length / 10 / 2)) {
			p = Math.ceil(array.length / 10 / 2)
		} else {
			p = parseInt(pagein)
		}
	}
	stringarray.push(`     &6&l${displayname} History`)
	if (array.length == 0) {
		stringarray.push(`  &c• No Data`)
		ChatLib.chat(stringarray.join("\n"))
	} else {
		if (["damage", "dps"].includes(cmd)) {
			for (i in array) {
				if (i >= (p - 1) * 10 && i < p * 10) {
					stringarray.push(`  &e#${array.length - parseInt(i)} &c• &e${array[i].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
				}
			}
		} else if ("sinces4time" == cmd) {
			for (i in array) {
				if (i >= (p - 1) * 10 && i < p * 10) {
					stringarray.push(`  &e#${array.length - parseInt(i)} &c• &e${Math.round(array[i] / 60 % 60)}m ${Math.round(array[i] % 60)}s`)
				}
			}
		} else if (["delaytime", "fighttime"].includes(cmd)) {
			for (i in array) {
				if (i >= (p - 1) * 10 && i < p * 10) {
					stringarray.push(`  &e#${array.length - parseInt(i)} &c• &e${array[i]}s`)
				}
			}
		} else if (["epicgolempet", "legendarygolempet", "tierboostcore"].includes(cmd)) {
			for (i in array) {
				if (i % 2 == 0) {
					if (i >= ((p - 1) * 10) * 2 && i < (p * 10) * 2) {
						stringarray.push(`  &e#${array[i]} &c• &e${gettimestamp(array[parseInt(i) + 1])}`)
					}
				}
			}
		} else if ("position" == cmd) {
			let c = 0
			for (i in array) {
				if (array[i] > 0) {
					if (c % 5 == 0) {
						stringarray.push("\n  ")
					}
					c++
					stringarray.push(`  &e#${parseInt(i) + 1} - ${array[i]}x;  `)
				}
			}
			ChatLib.chat(stringarray.join(""))
		}
		if ("position" !== cmd) {
			if (mode == 0) {
				ChatLib.chat(stringarray.join("\n"))
				ChatLib.chat(new Message(
					"     ", new TextComponent(`&a&l<< `).setClick("run_command", `/golemutils loottracker history ${cmd} ${p - 1}`).setHoverValue("&eClick to view previous page"),
					`&a${displayname} (Page &2${p} &aof &2${Math.ceil(array.length / 10)}&a) `,
					new TextComponent(`&a&l>>`).setClick("run_command", `/golemutils loottracker history ${cmd} ${p + 1}`).setHoverValue("&eClick to view next page")))
			} else if (mode == 1) {
				ChatLib.chat(stringarray.join("\n"))
				ChatLib.chat(new Message(
					"     ", new TextComponent(`&a&l<< `).setClick("run_command", `/golemutils loottracker history ${cmd} ${p - 1}`).setHoverValue("&eClick to view previous page"),
					`&a${displayname} (Page &2${p} &aof &2${Math.ceil(array.length / 10 / 2)}&a) `,
					new TextComponent(`&a&l>>`).setClick("run_command", `/golemutils loottracker history ${cmd} ${p + 1}`).setHoverValue("&eClick to view next page")))
			}
		}
	}
	ChatLib.chat(EndSeparator)
}

function loottrackermodify(modify, item, arg, pogdatain, displayname) {
	if (arg == undefined) {
		integerhelp()
	} else if (!Number.isInteger(parseInt(arg))) {
		integerhelp()
	} else if (["kills", "lasthits", "position", "zealots", "runecraftingxp", "bits", "endstonerose", "enchantedendstone", "crystalfragment", "epicgolempet", "legendarygolempet", "tierboostcore"].includes(item)) {
		if ("add" == modify) {
			ChatLib.chat(`${prefix} Added ${arg} to ${displayname}.`)
			return (pogdatain + parseInt(arg))
		} else {
			ChatLib.chat(`${prefix} Set ${displayname} to ${arg}.`)
			return (parseInt(arg))
		}
	} else {
		integerhelp()
	}
}

function gettimestamp(timestampdata) {
	let date = new Date(timestampdata)
	let timestampmonth
	let timestampdate
	let timestamphours
	let timestampminutes
	let timestampseconds

	let timestampyear = date.getFullYear()

	if ((date.getMonth() + 1) <= 9) { timestampmonth = "0" + (date.getMonth() + 1) }
	else { timestampmonth = (date.getMonth() + 1) }

	if (date.getDate() <= 9) { timestampdate = "0" + date.getDate() }
	else { timestampdate = date.getDate() }

	if (date.getHours() <= 9) { timestamphours = "0" + date.getHours() }
	else { timestamphours = date.getHours() }

	if (date.getMinutes() <= 9) { timestampminutes = "0" + date.getMinutes() }
	else { timestampminutes = date.getMinutes() }

	if (date.getSeconds() <= 9) { timestampseconds = "0" + date.getSeconds() }
	else { timestampseconds = date.getSeconds() }

	return `&eDate: ${timestampdate}.${timestampmonth}.${timestampyear}, Time: ${timestamphours}:${timestampminutes}:${timestampseconds}`
}



//Leaderboard pv
//final blow
register("chat", (p1, ign, event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (!Settings.pvleaderboard) return
	cancel(event)
	ChatLib.chat(new Message(`${p1}`, new TextComponent(` ${ign}`).setClick("run_command", `/pv ${(striprank(ign.removeFormatting()))}`).setHoverValue(`&e${prefix} Click to pv ${striprank(ign.removeFormatting())}.`), ` &7dealt the final blow.&r`));
}).setCriteria("${p1} &r${ign} &r&7dealt the final blow.&r").setContains();
//1-3
register("chat", (p1, ign, p2, event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (!Settings.pvleaderboard) return
	cancel(event)
	ChatLib.chat(new Message(`${p1} &r&7- `, new TextComponent(`${ign}`).setClick("run_command", `/pv ${(striprank(ign.removeFormatting()))}`).setHoverValue(`&e${prefix} Click to pv ${striprank(ign.removeFormatting())}.`), ` &r&7- ${p2}`));
}).setCriteria("&r${p1} &r&7- &r${ign} &r&7- &r${p2}&r").setContains();

function striprank(rankedPlayer) {
	return rankedPlayer.replace(/\[[\w+\+-]+] /, "")
}

function formatdamage(damage) {
	return parseInt(damage.removeFormatting().replace(/\,/g, "").replace("(NEW RECORD!)", "").trim())
}



/*
 #######                            
 #        #  #       ######   ####  
 #        #  #       #       #      
 #####    #  #       #####    ####  
 #        #  #       #            # 
 #        #  #       #       #    # 
 #        #  ######  ######   ####  
*/
let version = "3.1.4"

const pogdata = new PogObject("GolemUtils", {
	"Info": {
		"started": false,
		"version": version,
	},
	"GolemLocation": {
		"x": 150,
		"y": 10,
	},
	"GolemStage": {
		"x": 150,
		"y": 20,
	},
	"GolemCountdown": {
		"x": 150,
		"y": 30,
	},
	"GolemSinceS4": {
		"x": 150,
		"y": 40,
	},
	"DragonCountdown": {
		"x": 150,
		"y": 50,
	},
	"GolemLootTracker": {
		"x": 150,
		"y": 60,
		"Kills": 0,
		"Since_Last_Kill": 0,
		"Last_Hits": 0,
		"Since_Last_Hits": 0,
		"Damage": [],
		"DPS": [],
		"Position": 0,
		"Position_History": [],
		"Since_S4_Time": [],
		"Delay_Time": [],
		"Fight_Time": [],
		"Zealots": 0,
		"RunecraftingXP": 0,
		"Bits": 0,
		"Endstone_Rose": 0,
		"Enchanted_End_Stone": 0,
		"Crystal_Fragment": 0,
		"Epic_Golem_Pet": 0,
		"Epic_Golem_Pet_History": [],
		"Legendary_Golem_Pet": 0,
		"Legendary_Golem_Pet_History": [],
		"Tier_Boost_Core": 0,
		"Tier_Boost_Core_History": [],
	},
}, "data.json")
pogdata.save()



function inskyblock() {
	if (ChatLib.removeFormatting(Scoreboard.getTitle()).toLowerCase().includes("skyblock")) {
		if (!pogdata.Info.started) {
			pogdata.Info.started = true
			setTimeout(() => {
				pogdata.save()
				ChatLib.chat(new Message(`${StartSeparator}\n &eWelcome to &6&lGolemUtils ${Player.getName()}&e!\n &eThis Module is made for people who grind the Endstone Protector a lot. It has many different features and also contains some stuff for Dragons, go explore them!\n`, new TextComponent("   &6[Help Menu]   ").setClick("suggest_command", "/golemutils help").setHoverValue("&eClick to type command"), new TextComponent("&5[Discord]\n").setClick("open_url", "https://discord.gg/p3YA45XXhc").setHoverValue("&eClick to join Discord"), `${EndSeparator}`));
			}, 5000);
		}
		if (pogdata.Info.version != version) {
			pogdata.Info.version = version
			setTimeout(() => {
				pogdata.save()
				ChatLib.chat(new Message(`${prefix} GolemUtils updated to ${version}! `, new TextComponent("&6[Changelog]").setClick("open_url", "https://discord.gg/p3YA45XXhc").setHoverValue("&eClick to join Golemers Discord.")));
			}, 5000);
		}
	}
}



/*
 #######                       #####  
 #        #    #  #####       #     # 
 #        ##   #  #    #            # 
 #####    # #  #  #    #         ###  
 #        #  # #  #    #         #    
 #        #   ##  #    #              
 #######  #    #  #####          #    
*/
let inend
let indragonnest
function endcheckfunc() {
	if (!Settings.overall) return
	if (!World.isLoaded()) return
	if (Settings.scaninend) {
		if (!inend) {
			if (TabList.getNames()[41] != undefined) {
				if (TabList.getNames()[41].removeFormatting() == "Area: The End") {
					inend = true
				}
			}
		}
	}
	if (!indragonnest) {
		Scoreboard.getLines().forEach(line => {
			if (line != undefined) {
				if (ChatLib.removeFormatting(line).replace(/[🐍👹🌠🎂🎉🎁🏀⚽🍭👾🔮👽💣🍫]/g, "").trim() == "⏣ Dragon's Nest") {
					indragonnest = true
				}
			}
		})
	}
}



/*
 ######                                            
 #     #  #   ####   #####   #         ##    #   # 
 #     #  #  #       #    #  #        #  #    # #  
 #     #  #   ####   #    #  #       #    #    #   
 #     #  #       #  #####   #       ######    #   
 #     #  #  #    #  #       #       #    #    #   
 ######   #   ####   #       ######  #    #    #   
*/
//Displays
const dgolemlocation = new Gui();
let tempdgolemlocation
register("command", () => {
	dgolemlocation.open()
	ChatLib.chat(`${prefix} Click Anywhere in Screen to Move the Location of the "Location".`)
	ChatLib.chat(`${prefix} Press ESC to exit.`)
	setTimeout(() => {
		tempdgolemlocation = true
	}, 100);
}).setName("dgolemlocation")

const dgolemstage = new Gui();
let tempdgolemstage
register("command", () => {
	dgolemstage.open()
	ChatLib.chat(`${prefix} Click Anywhere in Screen to Move the Location of the "Stage".`)
	ChatLib.chat(`${prefix} Press ESC to exit.`)
	setTimeout(() => {
		tempdgolemstage = true
	}, 100);
}).setName("dgolemstage")

const dgolemcountdown = new Gui();
let tempdgolemcountdown
register("command", () => {
	dgolemcountdown.open()
	ChatLib.chat(`${prefix} Click Anywhere in Screen to Move the Location of the "Golem Countdown".`)
	ChatLib.chat(`${prefix} Press ESC to exit.`)
	setTimeout(() => {
		tempdgolemcountdown = true
	}, 100);
}).setName("dgolemcountdown")

const dgolemsinces4 = new Gui();
let tempdgolemsinces4
register("command", () => {
	dgolemsinces4.open()
	ChatLib.chat(`${prefix} Click Anywhere in Screen to Move the Location of the "Since Stage 4".`)
	ChatLib.chat(`${prefix} Press ESC to exit.`)
	setTimeout(() => {
		tempdgolemsinces4 = true
	}, 100);
}).setName("dgolemsinces4")

const dgolemloottracker = new Gui();
let tempdgolemloottracker
register("command", () => {
	dgolemloottracker.open()
	ChatLib.chat(`${prefix} Click Anywhere in Screen to Move the Location of the "Golem Loot Tracker".`)
	ChatLib.chat(`${prefix} Press ESC to exit.`)
	setTimeout(() => {
		tempdgolemloottracker = true
	}, 100);
}).setName("dgolemloottracker")

const ddragoncountdown = new Gui();
let tempddragoncountdown
register("command", () => {
	ddragoncountdown.open()
	ChatLib.chat(`${prefix} Click Anywhere in Screen to Move the Location of the "Dragon Countdown".`)
	ChatLib.chat(`${prefix} Press ESC to exit.`)
	setTimeout(() => {
		tempddragoncountdown = true
	}, 100);
}).setName("ddragoncountdown")


function displayopenfunc() {
	if (!dgolemlocation.isOpen()) {
		tempdgolemlocation = false
	}
	if (!dgolemstage.isOpen()) {
		tempdgolemstage = false
	}
	if (!dgolemcountdown.isOpen()) {
		tempdgolemcountdown = false
	}
	if (!dgolemsinces4.isOpen()) {
		tempdgolemsinces4 = false
	}
	if (!dgolemloottracker.isOpen()) {
		tempdgolemloottracker = false
	}
	if (!ddragoncountdown.isOpen()) {
		tempddragoncountdown = false
	}
}

register("dragged", (dx, dy, xpos, ypos) => {
	if (!Settings.overall) return
	if (dgolemlocation.isOpen()) {
		pogdata.GolemLocation.x = Math.round(xpos)
		pogdata.GolemLocation.y = Math.round(ypos)
		pogdata.save()
	} else if (dgolemstage.isOpen()) {
		pogdata.GolemStage.x = Math.round(xpos)
		pogdata.GolemStage.y = Math.round(ypos)
		pogdata.save()
	} else if (dgolemcountdown.isOpen()) {
		pogdata.GolemCountdown.x = Math.round(xpos)
		pogdata.GolemCountdown.y = Math.round(ypos)
		pogdata.save()
	} else if (dgolemsinces4.isOpen()) {
		pogdata.GolemSinceS4.x = Math.round(xpos)
		pogdata.GolemSinceS4.y = Math.round(ypos)
		pogdata.save()
	} else if (dgolemloottracker.isOpen()) {
		pogdata.GolemLootTracker.x = Math.round(xpos)
		pogdata.GolemLootTracker.y = Math.round(ypos)
		pogdata.save()
	} else if (ddragoncountdown.isOpen()) {
		pogdata.DragonCountdown.x = Math.round(xpos)
		pogdata.DragonCountdown.y = Math.round(ypos)
		pogdata.save()
	}
})



let glocationobject = new Text("Loc: Loading...", 50, 50)
function glocationfunc() {
	if (!tempdgolemlocation) {
		if (!Settings.overall) return
		if (!Settings.glocation) return
		if (!(inend || indragonnest)) return
	}
	glocationobject.setString(`Loc: ${loc}`)
		.setX(parseInt(pogdata.GolemLocation.x))
		.setY(parseInt(pogdata.GolemLocation.y))
		.setAlign(displayallignment(Settings.locationa))
		.setScale(Settings.locations / 10)
		.setColor(renderercolor(Settings.colorforalltoggle, Settings.locationc))
		.setShadow(true)
		.draw()
}

let gstageobject = new Text("Loading", 50, 50)
function gstagefunc() {
	if (!tempdgolemstage) {
		if (!Settings.overall) return
		if (!Settings.gstage) return
		if (!(inend || indragonnest)) return
	}
	gstageobject.setString(`Stage: ${stage}`)
		.setX(parseInt(pogdata.GolemStage.x))
		.setY(parseInt(pogdata.GolemStage.y))
		.setAlign(displayallignment(Settings.stagea))
		.setScale(Settings.stages / 10)
		.setColor(renderercolor(Settings.colorforalltoggle, Settings.stagec))
		.setShadow(true)
		.draw()
}

let timesinces4object = new Text("Since S4: Loading...", 50, 50)
function timesinces4func() {
	if (!tempdgolemsinces4) {
		if (!Settings.overall) return
		if (!Settings.timesinces4) return
		if (!(inend || indragonnest)) return
		if (stage == 0 || stage == 1 || stage == 2 || stage == 3 || stage == 5 || stage == "Spawned" || stage == "Scanning...") return
	}
	let timediff = (Date.now() - timesinces4time) / 1000
	timesinces4object.setString(`Since S4: ${Math.floor(timediff / 60 % 60)}m ${Math.floor(timediff % 60)}s`)
		.setX(parseInt(pogdata.GolemSinceS4.x))
		.setY(parseInt(pogdata.GolemSinceS4.y))
		.setAlign(displayallignment(Settings.timesinces4a))
		.setScale(Settings.timesinces4s / 10)
		.setColor(renderercolor(Settings.colorforalltoggle, Settings.timesinces4c))
		.setShadow(true)
		.draw()
}

let gcountdownnobject = new Text("Golem: Loading...", 50, 50)
function gcountdownfunc() {
	if (!tempdgolemcountdown) {
		if (!Settings.overall) return
		if (!Settings.gcountdown) return
		if (!(inend || indragonnest)) return
		if (!gcountdowntimertoggle) return
		if (stage == 0 || stage == 1 || stage == 2 || stage == 3 || stage == 4 || stage == "Spawned" || stage == "Scanning...") return
	}
	let time = ((gcountdowntimerstime - Date.now()) / 1000 + 20).toFixed(1)
	if (time < 0) { time = `+${time * -1}` }
	gcountdownnobject.setString(`Golem: ${time}s`)
		.setX(parseInt(pogdata.GolemCountdown.x))
		.setY(parseInt(pogdata.GolemCountdown.y))
		.setAlign(displayallignment(Settings.gcountdowna))
		.setScale(Settings.gcountdowns / 10)
		.setColor(renderercolor(Settings.colorforalltoggle, Settings.gcountdownc))
		.setShadow(true)
		.draw()
}

let gloottrackerobject = new Text(`&lGolem Stats\nLoading...`, 50, 50)
function gloottrackerfunc() {
	if (!tempdgolemloottracker) {
		if (!Settings.overall) return
		if (!Settings.gloottracker) return
		if (!(inend || indragonnest)) return
	}
	gloottrackerobject.setX(parseInt(pogdata.GolemLootTracker.x))
		.setY(parseInt(pogdata.GolemLootTracker.y))
		.setAlign(displayallignment(Settings.gloottrackera))
		.setScale(Settings.gloottrackers / 10)
		.setColor(renderercolor(Settings.gloottrackercall, Settings.gloottrackerc))
		.setShadow(true).draw()
}
function gloottrackerupdatefunc() {
	if (!tempdgolemloottracker) {
		if (!Settings.overall) return
		if (!Settings.gloottracker) return
		if (!(inend || indragonnest)) return
	}
	gloottrackerobject.setString(gloottrackertextfunc().join("\n"))
}


let dcountdownnobject = new Text("Dragon: Loading...", 50, 50)
function dcountdownfunc() {
	if (!tempddragoncountdown) {
		if (!Settings.overall) return
		if (!Settings.dcountdown) return
		if (!(inend || indragonnest)) return
		if (!dcountdowntimertoggle) return
	}
	let time = ((dcountdowntimerstime - Date.now()) / 1000 + 9).toFixed(1)
	if (time < 0) { time = `+${time * -1}` }
	dcountdownnobject.setString(`Dragon: ${time}s`)
		.setX(parseInt(pogdata.DragonCountdown.x))
		.setY(parseInt(pogdata.DragonCountdown.y))
		.setAlign(displayallignment(Settings.dcountdowna))
		.setScale(Settings.dcountdowns / 10)
		.setColor(renderercolor(Settings.dcountdowncall, Settings.dcountdownc))
		.setShadow(true).draw()
}



function displayallignment(setting) {
	if (setting == 0) { return "Left" }
	else if (setting == 1) { return "Right" }
	else if (setting == 2) { return "Center" }
}

function renderercolor(colorforall, setting) {
	if (colorforall) {
		return Renderer.color(Settings.colorforalltext.getRed(), Settings.colorforalltext.getGreen(), Settings.colorforalltext.getBlue(), Settings.colorforalltext.getAlpha())
	} else {
		return Renderer.color(setting.getRed(), setting.getGreen(), setting.getBlue(), setting.getAlpha())
	}
}


/*
  #####                                                     
 #     #   ####     ##    #    #  #    #  #  #    #   ####  
 #        #    #   #  #   ##   #  ##   #  #  ##   #  #    # 
  #####   #       #    #  # #  #  # #  #  #  # #  #  #      
	   #  #       ######  #  # #  #  # #  #  #  # #  #  ### 
 #     #  #    #  #    #  #   ##  #   ##  #  #   ##  #    # 
  #####    ####   #    #  #    #  #    #  #  #    #   ####  
*/
let scanningratenumber = 3
if (Settings.scanningrate == 0) { scanningratenumber = 1 }
else if (Settings.scanningrate == 1) { scanningratenumber = 3 }
else if (Settings.scanningrate == 2) { scanningratenumber = 5 }
else if (Settings.scanningrate == 3) { scanningratenumber = 10 }
else if (Settings.scanningrate == 4) { scanningratenumber = 15 }

function autoreloadfunc() {
	if (Client.currentGui.get() instanceof Java.type('gg.essential.vigilance.gui.SettingsGui')) return
	if (Settings.scanningrate == 0) { if (scanningratenumber != 1) { autoreload() } }
	else if (Settings.scanningrate == 1) { if (scanningratenumber != 3) { autoreload() } }
	else if (Settings.scanningrate == 2) { if (scanningratenumber != 5) { autoreload() } }
	else if (Settings.scanningrate == 3) { if (scanningratenumber != 10) { autoreload() } }
	else if (Settings.scanningrate == 4) { if (scanningratenumber != 15) { autoreload() } }
}

function autoreload() {
	Client.showTitle("&6GolemUtils", "&6Reloading Modules", 5, 60, 5)
	ChatTriggers.loadCT()
}

let gloc
let golemdied
let loc = "Scanning..."
let stage = "Scanning..."
register("step", () => {
	if (!Settings.overall) return
	if (!World.isLoaded()) return
	if (!(inend || indragonnest)) return
	if (gloc) return
	if (Settings.glocation || Settings.gstage || Settings.stage4sound || Settings.stage5sound || Settings.stage4title || Settings.stage5title || Settings.gcountdown || Settings.timesinces4 || Settings.ddps || Settings.golemstatuetext) {
		gposleft()
		gposmiddlefront()
		gposmiddlecenter()
		gposmiddlebehind()
		gposrightfront()
		gposrightbehind()
		//After every location got scanned
		if (locscan1 && locscan2 && locscan3 && locscan4 && locscan5 && locscan6) {
			if (stage != 0) {
				gloc = true
				stage = 0
				loc = "No Golem"
			}
		}
	}
}).setFps(scanningratenumber)

function gposleft() {
	if (!locscan1) {
		xscan = -649; zscan = -219
		if (checkforgolem(xscan, 0, zscan)) return
		if (checkforgolem(xscan, 1, zscan)) return
		if (checkforgolem(xscan, 5, zscan)) {
			gloc = true
			loc = "Left"
			stage = 1
		} else if (checkforgolem(xscan, 6, zscan)) {
			gloc = true
			loc = "Left"
			stage = 2
		} else if (checkforgolem(xscan, 7, zscan)) {
			gloc = true
			loc = "Left"
			stage = 3
		} else if (checkforgolem(xscan, 8, zscan)) {
			gloc = true
			loc = "Left"
			stage = 4
			fcstage4alert()
			fcstage4title()
			serverdaycheck()
		} else if (checkforgolem(xscan, 9, zscan)) {
			gloc = true
			if (stage != 5) {
				fcstage5alert()
				fcstage5title()
			}
			loc = "Left"
			stage = 5
		} else {
			locscan1 = true
		}
	}
}

function gposmiddlefront() {
	if (!locscan2) {
		xscan = -644; zscan = -269
		if (checkforgolem(xscan, 0, zscan)) return
		if (checkforgolem(xscan, 1, zscan)) return
		if (checkforgolem(xscan, 5, zscan)) {
			gloc = true
			loc = "Middle Front"
			stage = 1
		} else if (checkforgolem(xscan, 6, zscan)) {
			gloc = true
			loc = "Middle Front"
			stage = 2
		} else if (checkforgolem(xscan, 7, zscan)) {
			gloc = true
			loc = "Middle Front"
			stage = 3
		} else if (checkforgolem(xscan, 8, zscan)) {
			gloc = true
			loc = "Middle Front"
			stage = 4
			fcstage4alert()
			fcstage4title()
			serverdaycheck()
		} else if (checkforgolem(xscan, 9, zscan)) {
			gloc = true
			if (stage != 5) {
				fcstage5alert()
				fcstage5title()
			}
			loc = "Middle Front"
			stage = 5
		} else {
			locscan2 = true
		}
	}
}

function gposmiddlecenter() {
	if (!locscan3) {
		xscan = -689; zscan = -273
		if (checkforgolem(xscan, 0, zscan)) return
		if (checkforgolem(xscan, 1, zscan)) return
		if (checkforgolem(xscan, 5, zscan)) {
			gloc = true
			loc = "Middle Center"
			stage = 1
		} else if (checkforgolem(xscan, 6, zscan)) {
			gloc = true
			loc = "Middle Center"
			stage = 2
		} else if (checkforgolem(xscan, 7, zscan)) {
			gloc = true
			loc = "Middle Center"
			stage = 3
		} else if (checkforgolem(xscan, 8, zscan)) {
			gloc = true
			loc = "Middle Center"
			stage = 4
			fcstage4alert()
			fcstage4title()
			serverdaycheck()
		} else if (checkforgolem(xscan, 9, zscan)) {
			gloc = true
			if (stage != 5) {
				fcstage5alert()
				fcstage5title()
			}
			loc = "Middle Center"
			stage = 5
		} else {
			locscan3 = true
		}
	}
}

function gposmiddlebehind() {
	if (!locscan4) {
		xscan = -727; zscan = -284
		if (checkforgolem(xscan, 0, zscan)) return
		if (checkforgolem(xscan, 1, zscan)) return
		if (checkforgolem(xscan, 5, zscan)) {
			gloc = true
			loc = "Middle Behind"
			stage = 1
		} else if (checkforgolem(xscan, 6, zscan)) {
			gloc = true
			loc = "Middle Behind"
			stage = 2
		} else if (checkforgolem(xscan, 7, zscan)) {
			gloc = true
			loc = "Middle Behind"
			stage = 3
		} else if (checkforgolem(xscan, 8, zscan)) {
			gloc = true
			loc = "Middle Behind"
			stage = 4
			fcstage4alert()
			fcstage4title()
			serverdaycheck()
		} else if (checkforgolem(xscan, 9, zscan)) {
			gloc = true
			if (stage != 5) {
				fcstage5alert()
				fcstage5title()
			}
			loc = "Middle Behind"
			stage = 5
		} else {
			locscan4 = true
		}
	}
}

function gposrightfront() {
	if (!locscan5) {
		xscan = -639; zscan = -328
		if (checkforgolem(xscan, 0, zscan)) return
		if (checkforgolem(xscan, 1, zscan)) return
		if (checkforgolem(xscan, 5, zscan)) {
			gloc = true
			loc = "Right Front"
			stage = 1
		} else if (checkforgolem(xscan, 6, zscan)) {
			gloc = true
			loc = "Right Front"
			stage = 2
		} else if (checkforgolem(xscan, 7, zscan)) {
			gloc = true
			loc = "Right Front"
			stage = 3
		} else if (checkforgolem(xscan, 8, zscan)) {
			gloc = true
			loc = "Right Front"
			stage = 4
			fcstage4alert()
			fcstage4title()
			serverdaycheck()
		} else if (checkforgolem(xscan, 9, zscan)) {
			gloc = true
			if (stage != 5) {
				fcstage5alert()
				fcstage5title()
			}
			loc = "Right Front"
			stage = 5
		} else {
			locscan5 = true
		}
	}
}

function gposrightbehind() {
	if (!locscan6) {
		xscan = -678; zscan = -332
		if (checkforgolem(xscan, 0, zscan)) return
		if (checkforgolem(xscan, 1, zscan)) return
		if (checkforgolem(xscan, 5, zscan)) {
			gloc = true
			loc = "Right Behind"
			stage = 1
		} else if (checkforgolem(xscan, 6, zscan)) {
			gloc = true
			loc = "Right Behind"
			stage = 2
		} else if (checkforgolem(xscan, 7, zscan)) {
			gloc = true
			loc = "Right Behind"
			stage = 3
		} else if (checkforgolem(xscan, 8, zscan)) {
			gloc = true
			loc = "Right Behind"
			stage = 4
			fcstage4alert()
			fcstage4title()
			serverdaycheck()
		} else if (checkforgolem(xscan, 9, zscan)) {
			gloc = true
			loc = "Right Behind"
			stage = 5
			if (stage != 5) {
				fcstage5alert()
				fcstage5title()
			}
		} else {
			locscan6 = true
		}
	}
}

function checkforgolem(xscan, yscan, zscan) {
	if (yscan == 0) {
		return World.getBlockAt(xscan, yscan, zscan) === undefined
	} else if (yscan == 1) {
		return World.getBlockAt(xscan, yscan, zscan).getType().getRegistryName() === "minecraft:air"
	} else {
		return (World.getBlockAt(xscan, yscan, zscan).getType().getRegistryName() === "minecraft:skull" || World.getBlockAt(xscan, yscan, zscan).getType().getRegistryName() === "minecraft:stained_hardened_clay") && World.getBlockAt(xscan, yscan-1, zscan).getType().getRegistryName() === "minecraft:end_stone"
	}
}


register("chat", () => {
	if (!Settings.overall) return
	if (!(inend || indragonnest)) return
	if (Settings.glocation || Settings.gstage) {
		if (stage == "Scanning..." || stage == 0) {
			loc = "Spawned"
			stage = "Spawned"
			fcstage5alert()
			fcstage5title()
		}
	}
}).setCriteria(/^&r&c&lBEWARE - An Endstone Protector has risen!&r/).setContains();

function goleminscoreboard() {
	if (!Settings.overall) return
	if (!World.isLoaded()) return
	if (!(inend || indragonnest)) return
	if (Settings.glocation || Settings.gstage) {
		if (golemdied) return
		if (stage == "Spawned") return
		if (stage == "Scanning..." || stage == 0) {
			Scoreboard.getLines().forEach(line => {
				if (line == undefined) return
				if (line.toString().removeFormatting().includes("Protector HP: ")) {
					loc = "Spawned"
					stage = "Spawned"
					fcstage5alert()
					fcstage5title()
				}
			})
		}
	}
}

function golementityfunc() {
	if (!Settings.overall) return
	if (Settings.glocation || Settings.gstage) {
		if (!(inend || indragonnest)) return
		if (golemdied) return
		if (stage == "Scanning..." || stage == 0) {
			World.getAllEntitiesOfType(EntityArmorStand).forEach(entity => {
				if (entity.getName().includes("Endstone Protector")) {
					loc = "Spawned"
					stage = "Spawned"
					fcstage5alert()
					fcstage5title()
				}
			});
		}
	}
}


register("chat", () => {
	if (stage == 0 || stage == "Scanning...") {
		setTimeout(() => {
			locrescan()
		}, 2000);
	} else {
		golemdied = false
		locrescan()
	}
}).setCriteria(/^&r&c&lYou feel a tremor from beneath the earth!&r/).setContains();

register("chat", () => {
	fcstage5alert()
	fcstage5title()
	stage = 5
}).setCriteria(/^&r&c&lThe ground begins to shake as an Endstone Protector rises from below!&r/).setContains();

register("chat", () => {
	golemdied = true
	gloc = true
	stage = 0
	loc = "No Golem"
}).setCriteria(/^&r&f                    &r&6&lENDSTONE PROTECTOR DOWN!&r/).setContains();



register("chat", (event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (stage == 5) {
		locrescan()
	}
}).setCriteria("DRAGON DOWN!&r").setContains();

let locscan1
let locscan2
let locscan3
let locscan4
let locscan5
let locscan6
function locrescan() {
	if (stage == 0 || stage == "Spawned") {
		loc = "Scanning..."
		locscan1 = false
		locscan2 = false
		locscan3 = false
		locscan4 = false
		locscan5 = false
		locscan6 = false
		gloc = false

		//World
		gtesselatortoggle = false
	}
	if (stage == 0 || stage == 1 || stage == 2 || stage == 3) {
		stage++
	}
	if (stage == 4 && (inend || indragonnest)) {
		fcstage4alert()
		fcstage4title()
		serverdaycheck()
	}
}


function serverdaycheck() {
	if (!Settings.overall) return
	if (!Settings.serverday) return
	if (!(inend || indragonnest)) return
	let serverday = World.getTime() / 20 / 60 / 20
	if (serverday >= 32 && serverday <= 40) {
		setTimeout(() => {
			ChatLib.chat(`${prefix} This lobby might &crestart &6before the Golem spawns (Day: ${serverday.toFixed(2)}).`)
		}, 100);
	}
}

/*
 #     #                                 
 #  #  #   ####   #####   #       #####  
 #  #  #  #    #  #    #  #       #    # 
 #  #  #  #    #  #    #  #       #    # 
 #  #  #  #    #  #####   #       #    # 
 #  #  #  #    #  #   #   #       #    # 
  ## ##    ####   #    #  ######  #####  
*/

let gtesselatorx
let gtesselatorz
let gtesselatortoggle
function gtessellatorcoordsfunc() {
	if (!Settings.overall) return
	if (!Settings.golemstatuetext) return
	if (gtesselatortoggle) return
	if (stage == 0 || stage == "Spawned" || loc == "Scanning..." || loc == "No Golem") return
	if (loc == "Left") {
		gtesselatortoggle = true; gtesselatorx = -648.5; gtesselatorz = -218.5
	} else if (loc == "Middle Front") {
		gtesselatortoggle = true; gtesselatorx = -643.5; gtesselatorz = -268.5
	} else if (loc == "Middle Center") {
		gtesselatortoggle = true; gtesselatorx = -688.5; gtesselatorz = -272.5
	} else if (loc == "Middle Behind") {
		gtesselatortoggle = true; gtesselatorx = -726.5; gtesselatorz = -283.5
	} else if (loc == "Right Front") {
		gtesselatortoggle = true; gtesselatorx = -638.5; gtesselatorz = -327.5
	} else if (loc == "Right Behind") {
		gtesselatortoggle = true; gtesselatorx = -677.5; gtesselatorz = -331.5
	}
}
register("renderWorld", () => {
	if (!Settings.overall) return
	if (!Settings.golemstatuetext) return
	if (gtesselatorx == undefined || gtesselatorz == undefined) return
	if (stage == 0 || stage == "Spawned" || loc == "Scanning..." || loc == "No Golem") return
	if (Settings.golemstatuetexthide) {
		if (stage != 4 && stage != 5) return
	}
	if (Settings.golemstatuetextcall) golemstatuetextc = Renderer.color(Settings.colorforalltext.getRed(), Settings.colorforalltext.getGreen(), Settings.colorforalltext.getBlue(), Settings.colorforalltext.getAlpha())
	if (!Settings.golemstatuetextcall) golemstatuetextc = Renderer.color(Settings.golemstatuetextc.getRed(), Settings.golemstatuetextc.getGreen(), Settings.golemstatuetextc.getBlue(), Settings.golemstatuetextc.getAlpha())
	if (Settings.golemstatuetextscale) { golemstatuetextscale = true; golemstatuetexts = (0.09 * Settings.golemstatuetexts) }
	if (!Settings.golemstatuetextscale) { golemstatuetextscale = false; golemstatuetexts = (0.09 * Settings.golemstatuetexts / 10) }
	Tessellator.enableAlpha().drawString('GOLEM', gtesselatorx + Settings.golemstatuetextoffx, 7.5 + Settings.golemstatuetextoffy, gtesselatorz + Settings.golemstatuetextoffz, golemstatuetextc, Settings.golemstatuetextbackground, golemstatuetexts, golemstatuetextscale);
});



/*
 ######                                                  
 #     #   ####    ####    ####   #####     ##    #####  
 #     #  #    #  #       #       #    #   #  #   #    # 
 ######   #    #   ####    ####   #####   #    #  #    # 
 #     #  #    #       #       #  #    #  ######  #####  
 #     #  #    #  #    #  #    #  #    #  #    #  #   #  
 ######    ####    ####    ####   #####   #    #  #    # 
*/

let gbossinrange
let gdisplaybar
let displaylife
let gshowbossbarloading
let gbossbaroffsetobjective
let gbossbaroffsetdragon
let currenthpint = 5000000
let currenthp = "5M"
let maxhpint = 5000000
let maxhp = "5M"

function ggethealth() {
	if (!Settings.overall) return
	if (!Settings.gshowbossbar) return
	if (!(inend || indragonnest)) return
	gbossinrange = false
	World.getAllEntitiesOfType(EntityArmorStand).forEach(entity => {
		if (entity.getName().includes("Endstone Protector")) {
			gbossinrange = true
			entity = ChatLib.removeFormatting(entity.getName())
			hp = entity.match(/Endstone Protector.*\/.*❤/)[0].replace('Endstone Protector ', '').replace("❤", '').split('/')
			currenthp = hp[0]
			maxhp = hp[1]
			gdisplaybar = true

			if (currenthp.includes("k")) {
				currenthpint = currenthp.replace("k", "")
				currenthpint = currenthpint * 1000
			} else if (currenthp.includes("M")) {
				currenthpint = currenthp.replace("M", "")
				currenthpint = currenthpint * 1000000
			} else if (currenthp == 0) {
				currenthpint = 0
			}
			currenthpint = Math.round(currenthpint)
			if (maxhp.includes("k")) {
				maxhpint = maxhp.replace("k", "")
				maxhpint = maxhpint * 1000
			} else if (maxhp.includes("M")) {
				maxhpint = maxhp.replace("M", "")
				maxhpint = maxhpint * 1000000
			}
		}
	})
}



register("renderOverlay", () => {
	if (!Settings.overall) return
	if (!(inend || indragonnest)) return
	if (!Settings.gshowbossbar) return
	if (!gbossinrange) return
	if (!(gdisplaybar || gshowbossbarloading)) return
	if (currenthpint == undefined || maxhpint == undefined) return

	let widthpre = Renderer.screen.getWidth();
	let width = widthpre / 4;
	let y = 20

	Scoreboard.getLines().forEach(line => {
		let lines = ChatLib.removeFormatting(line.getName()).replace(/[🐍👹🌠🎂🎉🎁🏀⚽🍭👾🔮👽💣🍫]/g, "").trim();
		if (lines.includes("Objective")) {
			gbossbaroffsetobjective = true
		}
		if (gbossbaroffsetobjective) {
			y = 35
		}

		if (lines.includes("Dragon HP:")) {
			gbossbaroffsetdragon = true
		}
		if (gbossbaroffsetdragon) {
			y = 35
		}
	})

	Renderer.drawLine(Renderer.BLACK, width * 1.5, y, width * 2.5, y, 10);
	Renderer.drawLine(Renderer.GRAY, width * 1.5 + 1, y, width * 2.5 - 1, y, 10 - 2);

	if (Settings.gshowbossbarname) {
		Renderer.drawStringWithShadow("&6&lGolem", widthpre / 2 - Renderer.getStringWidth("Golem") / 2 - 5, y - 14);
	}

	if (gdisplaybar) {
		rightx = width * 1.5 + (width - 1) * currenthpint / maxhpint
		if (rightx > width * 1.5) Renderer.drawLine(Renderer.GOLD, width * 1.5 + 1, y, rightx, y, 10 - 2)
	}

	if (gshowbossbarloading && Settings.gshowbossbarloading) {
		let widthloading = Renderer.screen.getWidth() / 4
		let rightxloading = widthloading * 1.5 + (widthloading - 1) * gshowbossbarloadingnumber * 0.005
		Renderer.drawLine(Renderer.GOLD, width * 1.5 + 1, y, rightxloading, y, 10 - 2)
		if (Settings.gshowbossbarhealthnumber) {
			if (y == 35) { y = 38 }
			displaylife = `&0${Math.round(100 * (gshowbossbarloadingnumber * 0.005))}%`
			Renderer.scale(0.85)
			Renderer.drawString(`${displaylife}`, (widthpre / 2 - Renderer.getStringWidth(displaylife) / 2) / 0.85, y)
		}
	}

	if (gdisplaybar && Settings.gshowbossbarhealthnumber) {
		if (y == 35) { y = 38 }
		displaylife = `&0${currenthp}/${maxhp}`
		Renderer.finishDraw();
		Renderer.scale(0.85)
		Renderer.drawString(`${displaylife}`, (widthpre / 2 - Renderer.getStringWidth(displaylife) / 2) / 0.85, y)
	}
});

let gshowbossbarloadingnumber = 1
//Stage 5
register("chat", () => {
	if (!Settings.overall) return
	if (!Settings.gshowbossbar) return
	gshowbossbarloading = true
	gshowbossbarloadingnumber = 1
}).setCriteria(/^&r&c&lThe ground begins to shake as an Endstone Protector rises from below!&r/).setContains();
function gbossbarnumber() {
	if (!Settings.overall) return
	if (!Settings.gshowbossbar) return
	if (!gshowbossbarloading) return
	if (gshowbossbarloadingnumber <= 199) { gshowbossbarloadingnumber++ }
}



//Spawn
register("chat", () => {
	if (!Settings.overall) return
	if (!Settings.gshowbossbar) return
	gshowbossbarloading = false
	gdisplaybar = true
}).setCriteria(/^&r&c&lBEWARE - An Endstone Protector has risen!&r/).setContains();
//Down
register("chat", () => {
	if (!Settings.overall) return
	if (!Settings.gshowbossbar) return
	gshowbossbarloadingnumber = 1
	setTimeout(() => {
		gdisplaybar = false
	}, 5000);
}).setCriteria(/^&r&f                    &r&6&lENDSTONE PROTECTOR DOWN!&r/).setContains();

register("chat", (event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	gbossbaroffsetobjective = false
}).setCriteria("&5☬ &r&d&lThe" && "Dragon&r&d&l has spawned!&r").setContains();
register("chat", () => {
	if (!Settings.overall) return;
	gbossbaroffsetdragon = false
}).setCriteria(/^&r&5☬ &r&dThe Dragon Egg has spawned!&r/).setContains();

/*
  #####                                          
 #     #   ####   #    #  #    #  #####    ####  
 #        #    #  #    #  ##   #  #    #  #      
  #####   #    #  #    #  # #  #  #    #   ####  
	   #  #    #  #    #  #  # #  #    #       # 
 #     #  #    #  #    #  #   ##  #    #  #    # 
  #####    ####    ####   #    #  #####    ####  
*/
//Sounds with test command
function cstage4alert() {
	for (c = 0; c < 20; c++) {
		World.playSound("mob.irongolem.hit", Settings.stage4volume / 100, 1);
	}
}
register("command", () => {
	cstage4alert()
}).setName("cstage4test")

function cstage5alert() {
	for (c = 0; c < 20; c++) {
		World.playSound("random.anvil_land", Settings.stage5volume / 100, 1);
	}
}
register("command", () => {
	cstage5alert()
}).setName("cstage5test")


//Functions to call somewhere
function fcstage4alert() {
	if (Settings.stage4sound) {
		cstage4alert()
	}
}
function fcstage5alert() {
	if (Settings.stage5sound) {
		cstage5alert()
	}
}



/*
 #######                                                                 
 #        #   ####   #    #  #####      #####  #  #    #  ######  #####  
 #        #  #    #  #    #    #          #    #  ##  ##  #       #    # 
 #####    #  #       ######    #          #    #  # ## #  #####   #    # 
 #        #  #  ###  #    #    #          #    #  #    #  #       #####  
 #        #  #    #  #    #    #          #    #  #    #  #       #   #  
 #        #   ####   #    #    #          #    #  #    #  ######  #    # 
*/
//Reset Golem Fight timer
let gfight
let gtime
//Spawn
register("chat", () => {
	if (!Settings.overall) return
	gtime = Date.now()
}).setCriteria(/^&r&c&lBEWARE - An Endstone Protector has risen!&r/).setContains();
//Down
register("chat", () => {
	if (!Settings.overall) return
	if (gtime != undefined) {
		gfight = (Date.now() - gtime) / 1000
		if (pogdata.GolemLootTracker.Fight_Time != undefined) {
			pogdata.GolemLootTracker.Fight_Time.unshift(parseFloat(gfight.toFixed(1)))
			if (pogdata.GolemLootTracker.Fight_Time.length > Settings.gloottrackerhistory) {
				pogdata.GolemLootTracker.Fight_Time.length = Settings.gloottrackerhistory
			}
		} else {
			pogdata.GolemLootTracker.Fight_Time.push(parseFloat(gfight.toFixed(1)))

		}
		pogdata.save()
	}
	if (Settings.gfight) {
		setTimeout(() => {
			if (gtime == undefined) {
				ChatLib.chat(`${prefix} Golem spawn time unknown (Fight Time).`)
			} else {
				ChatLib.chat(`${prefix} Golem Fight took &6&o${gfight.toFixed(1)}s&6.`)
			}
		}, 200);
	}
	setTimeout(() => {
		gtime = undefined
	}, 2000);
}).setCriteria(/^&r&f                    &r&6&lENDSTONE PROTECTOR DOWN!&r/).setContains();



//Drag
//Reset Dragon Fight timer
let dfight
let dtime
register("chat", (event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	dtime = Date.now()
}).setCriteria("&5☬ &r&d&lThe" && "Dragon&r&d&l has spawned!&r").setContains();

register("chat", (event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (dtime != undefined) {
		dfight = (Date.now() - dtime) / 1000
	}
	if (Settings.dfight) {
		setTimeout(() => {
			if (dtime == undefined) {
				ChatLib.chat(`${prefix} Dragon spawn time unknown (Fight Time).`)
			} else {
				ChatLib.chat(`${prefix} Dragon Fight took &6&o${dfight.toFixed(1)}s&6.`)
			}
		}, 200);
	}
	setTimeout(() => {
		dtime = undefined
	}, 2000);
}).setCriteria("DRAGON DOWN!&r").setContains();

/*
 #####   #####    ####  
 #    #  #    #  #      
 #    #  #    #   ####  
 #    #  #####        # 
 #    #  #       #    # 
 #####   #        ####  
*/
//Down
let gdamage
let gdamagearray = []
let ddamage
let ddamagearray = []
register("chat", () => {
	if (!Settings.overall) return
	if (!Settings.gdps) return
	if (gtime == undefined) {
		setTimeout(() => {
			ChatLib.chat(`${prefix} Golem spawn time unknown (DPS).`)
		}, 201);
	} else {
		gdamage = true
	}
}).setCriteria(/^&r&f                    &r&6&lENDSTONE PROTECTOR DOWN!&r/).setContains();

register("chat", (event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (!Settings.ddps) return
	if (dtime == undefined) {
		setTimeout(() => {
			ChatLib.chat(`${prefix} Dragon spawn time unknown (DPS).`)
		}, 201);
	} else {
		ddamage = true
	}
}).setCriteria("DRAGON DOWN!&r").setContains();

//DPS from top 3
register("chat", (damage, event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (gdamage || ddamage) {
		if (gtime != undefined || dtime != undefined) {
			damage = formatdamage(damage)
			if (gdamage) {
				gdamagearray.push(`&e${gdamagearray.length + 1}. ${Math.round(damage / 1000 / gfight)}k`)
			} else if (ddamage) {
				ddamagearray.push(`&e${ddamagearray.length + 1}. ${Math.round(damage / 1000 / dfight)}k`)
			}
		}
	}
}).setCriteria(" &r&7- &r&e${damage}&r").setContains();



//Your Damage
register("chat", (yourdamage, event) => {
	if (!Settings.overall) return
	if (!ChatLib.getChatMessage(event, true).removeFormatting().startsWith("   ")) return
	if (gdamage || ddamage) {
		if (gdamage) {
			gdamage = false
			gyourdamage = formatdamage(yourdamage)
			setTimeout(() => {
				if (gtime != undefined) {
					if (gyourdamage == 0) {
						ChatLib.chat(new Message(`${prefix} You did no dmg to the Golem. `, new TextComponent("&6[HOVER]").setHoverValue(`&6&lTOP 3 Golem DPS\n${gdamagearray.join("\n")}`)))
					} else {
						let dps = Math.round(gyourdamage / 1000 / gfight)
						ChatLib.chat(new Message(`${prefix} You did &6&o${dps}k &6dps to the Golem. `, new TextComponent("&6[HOVER]").setHoverValue(`&6&lTOP 3 Golem DPS\n${gdamagearray.join("\n")}\n\n&eYour DPS: ${dps}k`)))
						if (pogdata.GolemLootTracker.DPS != undefined) {
							pogdata.GolemLootTracker.DPS.unshift(Math.round(gyourdamage / gfight))
							if (pogdata.GolemLootTracker.DPS.length > Settings.gloottrackerhistory) {
								pogdata.GolemLootTracker.DPS.length = Settings.gloottrackerhistory
							}
						} else {
							pogdata.GolemLootTracker.DPS.push(Math.round(gyourdamage / gfight))
						}
						pogdata.save()
					}
					gdamagearray = []
				}
			}, 201);
		} else if (ddamage) {
			ddamage = false
			dyourdamage = formatdamage(yourdamage)
			setTimeout(() => {
				if (dtime != undefined) {
					if (dyourdamage == 0) {
						ChatLib.chat(new Message(`${prefix} You did no dmg to the Dragon. `, new TextComponent("&6[HOVER]").setHoverValue(`&6&lTOP 3 Dragon DPS\n${ddamagearray.join("\n")}`)))
					} else {
						let dps = Math.round(dyourdamage / 1000 / dfight)
						ChatLib.chat(new Message(`${prefix} You did &6&o${dps}k &6dps to the Dragon. `, new TextComponent("&6[HOVER]").setHoverValue(`&6&lTOP 3 Dragon DPS\n${ddamagearray.join("\n")}\n\n&eYour DPS: ${dps}k`)))
					}
					ddamagearray = []
				}
			}, 201);
		}

	}
}).setCriteria("&r&eYour Damage: &r&a${yourdamage} &r").setContains();



/*
######                                  
#     #  #####    ####   #####    ####  
#     #  #    #  #    #  #    #  #      
#     #  #    #  #    #  #    #   ####  
#     #  #####   #    #  #####        # 
#     #  #   #   #    #  #       #    # 
######   #    #   ####   #        ####  
*/

let gfirstplacedamage
let gfirstplacedamagetoggle
let gyourdamage
let gyourdamagetoggle
let golemplace
let golemplacetoggle
let gzealotkills
let gzealotkillstoggle

let gdropsgetting
//Down
register("chat", () => {
	gfirstplacedamage = undefined
	gfirstplacedamagetoggle = true
	gyourdamage = undefined
	gyourdamagetoggle = true
	golemplace = undefined
	golemplacetoggle = true
	gzealotkills = undefined
	gzealotkillstoggle = true

	gdropsgetting = true
}).setCriteria(/^&r&f                    &r&6&lENDSTONE PROTECTOR DOWN!&r/).setContains();

register("chat", (gfirstplacedamagetemp, event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (!Settings.gdrops) return
	if (!gdropsgetting) return
	if (!gfirstplacedamagetoggle) return
	gfirstplacedamagetoggle = false
	gfirstplacedamage = gfirstplacedamagetemp.replace(/\,/g, "")
}).setCriteria(" &r&7- &r&e${gfirstplacedamagetemp}&r").setContains();
register("chat", (gyourdamagetemp, event) => {
	if (!Settings.overall) return
	if (!ChatLib.getChatMessage(event, true).removeFormatting().startsWith("   ")) return
	if (!Settings.gdrops) return
	if (!gdropsgetting) return
	if (!gyourdamagetoggle) return
	gyourdamagetoggle = false
	gyourdamage = gyourdamagetemp.replace(/\,/g, "").replace("&r&d&l(NEW RECORD!)", "").trim()
}).setCriteria("&r&eYour Damage: &r&a${gyourdamagetemp} &r").setContains();
register("chat", (golemplacetemp, event) => {
	if (!Settings.overall) return
	if (!ChatLib.getChatMessage(event, true).removeFormatting().startsWith("   ")) return
	if (!Settings.gdrops) return
	if (!gdropsgetting) return
	if (!golemplacetoggle) return
	golemplacetoggle = false
	golemplace = golemplacetemp
}).setCriteria(" &r&7(Position #${golemplacetemp})&r").setContains();

let gbasequality
let gtotalquality
let gdroptexthover
register("chat", (gzealotkillstemp, event) => {
	if (!Settings.overall) return
	if (!ChatLib.getChatMessage(event, true).removeFormatting().startsWith("   ")) return
	if (!Settings.gdrops) return
	if (!gdropsgetting) return
	if (!gzealotkillstoggle) return

	gzealotkillstoggle = false
	gdropsgetting = false
	gzealotkills = parseInt(gzealotkillstemp)

	if (gzealotkills > 100) {
		gzealotkills = 100
	}

	if (golemplace == 1) gbasequality = 200;
	if (golemplace == 2) gbasequality = 175;
	if (golemplace == 3) gbasequality = 150;
	if (golemplace == 4) gbasequality = 125;
	if (golemplace == 5) gbasequality = 110;
	if (golemplace >= 6 && golemplace <= 8) gbasequality = 100;
	if (golemplace == 9 || golemplace == 10) gbasequality = 90;
	if (golemplace == 11 || golemplace == 12) gbasequality = 80;
	if (golemplace >= 13) {
		if (gyourdamage >= 1) gbasequality = 70;
		if (gyourdamage < 1) gbasequality = 10;
	}

	gbasequality = parseInt(gbasequality)
	gtotalquality = (gbasequality + ((50 * (gyourdamage / gfirstplacedamage)) + gzealotkills))
	gtotalquality = Math.round(gtotalquality)

	if (gtotalquality >= 250) gdroptexthover = "&6&lPossible Golem Loot\n&eTier Boost Core &a✔ (250)\n&eLegendary Golem Pet &a✔ (235)\n&eEpic Golem Pet &a✔ (220)";
	if (gtotalquality <= 249 && gtotalquality >= 235) gdroptexthover = "&6&lPossible Golem Loot\n&eTier Boost Core &c✖ (250)\n&eLegendary Golem Pet &a✔ (235)\n&eEpic Golem Pet &a✔ (220)";
	if (gtotalquality <= 234 && gtotalquality >= 220) gdroptexthover = "&6&lPossible Golem Loot\n&eTier Boost Core &c✖ (250)\n&eLegendary Golem Pet &c✖ (235)\n&eEpic Golem Pet &a✔ (220)";
	if (gtotalquality <= 219) gdroptexthover = "&6&lPossible Golem Loot\n&eTier Boost Core &c✖ (250)\n&eLegendary Golem Pet &c✖ (235)\n&eEpic Golem Pet &c✖ (220)";
	setTimeout(() => {
		ChatLib.chat(new Message(`${prefix} You have &6&o${gtotalquality} &6loot Quality. `, new TextComponent("&6[HOVER]").setHoverValue(gdroptexthover)))
	}, 202);
}).setCriteria("&r&eZealots Contributed: &r&a${gzealotkillstemp}&r&e/100&r").setContains();






let ghaslasthit
let gover0dmgcheck
let gover0dmg
let gscanloot
let gendstonerose
let genchantedendstone
let gcrystalfragment
let g4thdrop
register("chat", () => {
	ghaslasthit = true
	gover0dmgcheck = true
	gover0dmg = false
}).setCriteria(/^&r&f                    &r&6&lENDSTONE PROTECTOR DOWN!&r/).setContains();

register("chat", (ign, event) => {
	if (!ghaslasthit) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	ghaslasthit = false
	if (striprank(ign.removeFormatting()).trim() == `${Player.getName()}`) {
		if (!Number.isInteger(pogdata.GolemLootTracker.Last_Hits)) {
			pogdata.GolemLootTracker.Last_Hits = 0
		}
		pogdata.GolemLootTracker.Last_Hits = pogdata.GolemLootTracker.Last_Hits + 1
		pogdata.GolemLootTracker.Since_Last_Hits = Date.now()
		pogdata.save()
	}
}).setCriteria(" &r${ign}&r&f &r&7dealt the final blow.&r").setContains();

register("chat", (damage, pos, event) => {
	if (!gover0dmgcheck) return
	if (!ChatLib.getChatMessage(event, true).removeFormatting().startsWith("   ")) return
	gover0dmgcheck = false
	gover0dmg = true
	damage = formatdamage(damage)
	if (parseInt(damage) > 0) {
		gendstonerose = false
		genchantedendstone = false
		gcrystalfragment = false
		g4thdrop = false
		gscanloot = true
		setTimeout(() => {
			gscanloot = false
		}, 5000);

		if (pogdata.GolemLootTracker.Damage != undefined) {
			pogdata.GolemLootTracker.Damage.unshift(parseInt(damage))
			if (pogdata.GolemLootTracker.Damage.length > Settings.gloottrackerhistory) {
				pogdata.GolemLootTracker.Damage.length = Settings.gloottrackerhistory
			}
		} else {
			pogdata.GolemLootTracker.Damage.push(parseInt(damage))
		}

		pogdata.GolemLootTracker.Position = parseInt(pos)

		if (pogdata.GolemLootTracker.Position_History[parseInt(pos) - 1] != undefined) {
			pogdata.GolemLootTracker.Position_History[parseInt(pos) - 1] = pogdata.GolemLootTracker.Position_History[parseInt(pos) - 1] + 1
		} else {
			pogdata.GolemLootTracker.Position_History[parseInt(pos) - 1] = 1
		}

		if (!Number.isInteger(pogdata.GolemLootTracker.Kills)) {
			pogdata.GolemLootTracker.Kills = 0
		}
		pogdata.GolemLootTracker.Kills = pogdata.GolemLootTracker.Kills + 1
		pogdata.GolemLootTracker.Since_Last_Kill = Date.now()
		pogdata.save()
	}
}).setCriteria("&r&eYour Damage: &r&a${damage} &r&7(Position #${pos})&r").setContains();

register("chat", (gloottrackerzealotstemp, event) => {
	if (!Settings.overall) return
	if (!ChatLib.getChatMessage(event, true).removeFormatting().startsWith("   ")) return
	if (!gover0dmg) return
	let gloottrackerzealots = parseInt(gloottrackerzealotstemp)
	if (gloottrackerzealots > 0) {
		if (!Number.isInteger(pogdata.GolemLootTracker.Zealots)) {
			pogdata.GolemLootTracker.Zealots = 0
		}
		pogdata.GolemLootTracker.Zealots = pogdata.GolemLootTracker.Zealots + gloottrackerzealots
		pogdata.save()
	}
}).setCriteria("&r&eZealots Contributed: &r&a${gloottrackerzealotstemp}&r&e/100&r").setContains();

register("chat", (xp, event) => {
	if (!Settings.overall) return
	let message = ChatLib.getChatMessage(event, true)
	if (!message.removeFormatting().startsWith("   ")) return
	if (!gover0dmg) return
	xp = parseInt(xp)
	if (xp > 0) {
		if (!Number.isInteger(pogdata.GolemLootTracker.RunecraftingXP)) {
			pogdata.GolemLootTracker.RunecraftingXP = 0
		}
		pogdata.GolemLootTracker.RunecraftingXP = pogdata.GolemLootTracker.RunecraftingXP + xp
	}
	if (message.removeFormatting().includes("Bits: ")) {
		if (!Number.isInteger(pogdata.GolemLootTracker.Bits)) {
			pogdata.GolemLootTracker.Bits = 0
		}
		pogdata.GolemLootTracker.Bits = pogdata.GolemLootTracker.Bits + parseInt(message.removeFormatting().match(/(\d+)(?!.*\d)/, "")[0])
	}
	pogdata.save()
}).setCriteria("&r&eRunecrafting: &r&d+${xp} XP").setContains()

function gscanforlootfunc() {
	if (!gscanloot) return

	World.getAllEntitiesOfType(EntityArmorStand).forEach(entity => {
		if (!gendstonerose && entity.getName().includes("§9Endstone Rose")) {
			gendstonerose = true
			if (!Number.isInteger(pogdata.GolemLootTracker.Endstone_Rose)) {
				pogdata.GolemLootTracker.Endstone_Rose = 0
			}
			pogdata.GolemLootTracker.Endstone_Rose = pogdata.GolemLootTracker.Endstone_Rose + 1
			pogdata.save()

		} else if (!genchantedendstone && entity.getName().includes("§aEnchanted End Stone")) {
			genchantedendstone = true
			if (!Number.isInteger(pogdata.GolemLootTracker.Enchanted_End_Stone)) {
				pogdata.GolemLootTracker.Enchanted_End_Stone = 0
			}
			if (entity.getName().includes("x")) {
				pogdata.GolemLootTracker.Enchanted_End_Stone = pogdata.GolemLootTracker.Enchanted_End_Stone + parseInt(entity.getName().removeFormatting().replace(/\D+/g, ""))
			} else {
				pogdata.GolemLootTracker.Enchanted_End_Stone = pogdata.GolemLootTracker.Enchanted_End_Stone + 1
			}
			pogdata.save()

		} else if (!gcrystalfragment && entity.getName().includes("§5Crystal Fragment")) {
			gcrystalfragment = true
			if (!Number.isInteger(pogdata.GolemLootTracker.Crystal_Fragment)) {
				pogdata.GolemLootTracker.Crystal_Fragment = 0
			}
			if (entity.getName().includes("x")) {
				pogdata.GolemLootTracker.Crystal_Fragment = pogdata.GolemLootTracker.Crystal_Fragment + parseInt(entity.getName().removeFormatting().replace(/\D+/g, ""))
			} else {
				pogdata.GolemLootTracker.Crystal_Fragment = pogdata.GolemLootTracker.Crystal_Fragment + 1
			}
			pogdata.save()


		} else if (!g4thdrop && entity.getName().includes("§7[Lvl 1] §5Golem")) {
			g4thdrop = true
			if (!Number.isInteger(pogdata.GolemLootTracker.Epic_Golem_Pet)) {
				pogdata.GolemLootTracker.Epic_Golem_Pet = 0
			}
			pogdata.GolemLootTracker.Epic_Golem_Pet = pogdata.GolemLootTracker.Epic_Golem_Pet + 1
			if (pogdata.GolemLootTracker.Epic_Golem_Pet_History != undefined) {
				pogdata.GolemLootTracker.Epic_Golem_Pet_History.unshift(parseInt(pogdata.GolemLootTracker.Epic_Golem_Pet), Date.now())
			} else {
				pogdata.GolemLootTracker.Epic_Golem_Pet_History.push(parseInt(pogdata.GolemLootTracker.Epic_Golem_Pet), Date.now())
			}
			pogdata.save()
			if (Settings.gepicgolempettitle) {
				Client.showTitle("§7[Lvl 1] §5Golem", `&e#${pogdata.GolemLootTracker.Epic_Golem_Pet}`, 5, 40, 5)
			}
			ChatLib.chat(`${prefix} ${Player.getName()} &ehas obtained &7[Lvl 1] &5Golem&e!`)

		} else if (!g4thdrop && entity.getName().includes("§7[Lvl 1] §6Golem")) {
			g4thdrop = true
			if (!Number.isInteger(pogdata.GolemLootTracker.Legendary_Golem_Pet)) {
				pogdata.GolemLootTracker.Legendary_Golem_Pet = 0
			}
			pogdata.GolemLootTracker.Legendary_Golem_Pet = pogdata.GolemLootTracker.Legendary_Golem_Pet + 1
			if (pogdata.GolemLootTracker.Legendary_Golem_Pet_History != undefined) {
				pogdata.GolemLootTracker.Legendary_Golem_Pet_History.unshift(parseInt(pogdata.GolemLootTracker.Legendary_Golem_Pet), Date.now())
			} else {
				pogdata.GolemLootTracker.Legendary_Golem_Pet_History.push(parseInt(pogdata.GolemLootTracker.Legendary_Golem_Pet), Date.now())
			}
			pogdata.save()
			if (Settings.glegendarygolempettitle) {
				Client.showTitle("§7[Lvl 1] §6Golem", `&e#${pogdata.GolemLootTracker.Legendary_Golem_Pet}`, 5, 50, 10)
			}
			ChatLib.chat(`${prefix} ${Player.getName()} &ehas obtained &7[Lvl 1] &6Golem&e!`)

		} else if (!g4thdrop && entity.getName().includes("§6Tier Boost Core")) {
			g4thdrop = true
			if (!Number.isInteger(pogdata.GolemLootTracker.Tier_Boost_Core)) {
				pogdata.GolemLootTracker.Tier_Boost_Core = 0
			}
			pogdata.GolemLootTracker.Tier_Boost_Core = pogdata.GolemLootTracker.Tier_Boost_Core + 1
			if (pogdata.GolemLootTracker.Tier_Boost_Core_History != undefined) {
				pogdata.GolemLootTracker.Tier_Boost_Core_History.unshift(parseInt(pogdata.GolemLootTracker.Tier_Boost_Core), Date.now())
			} else {
				pogdata.GolemLootTracker.Tier_Boost_Core_History.push(parseInt(pogdata.GolemLootTracker.Tier_Boost_Core), Date.now())
			}
			pogdata.save()
			if (Settings.gtierboostcoretitle) {
				Client.showTitle("§6Tier Boost Core", `&e#${pogdata.GolemLootTracker.Tier_Boost_Core}`, 5, 80, 15)
			}
			ChatLib.chat(`${prefix} ${Player.getName()} &ehas obtained &6Tier Boost Core&e!`)
		}
	})
	if (gendstonerose && genchantedendstone && gcrystalfragment && g4thdrop) {
		gscanloot = false
	}
}



let loottrackerarray = []
function gloottrackertextfunc() {
	loottrackerarray = []
	if (gloottrackertextcmd) {
		loottrackerarray.push(StartSeparator)
		loottrackerarray.push(`&lEndstone Protector Stats`)
	} else {
		loottrackerarray.push(`&lGolem Stats`)
	}

	if (Settings.gloottrackerkills || gloottrackertextcmd) {
		loottrackerarray.push(`Kills: ${pogdata.GolemLootTracker.Kills.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
	}

	if (Settings.gloottrackersincelastkill || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Since_Last_Kill == 0 || pogdata.GolemLootTracker.Since_Last_Kill == undefined) {
			loottrackerarray.push(`Since Last Kill: Unknown`)
		} else {
			loottrackerarray.push(`Since Last Kill: ${gloottrackertime(pogdata.GolemLootTracker.Since_Last_Kill)}`)
		}
	}

	if (Settings.gloottrackerlasthits || gloottrackertextcmd) {
		loottrackerarray.push(`Last Hits: ${pogdata.GolemLootTracker.Last_Hits.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
	}

	if (Settings.gloottrackersincelasthit || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Since_Last_Hits == 0 || pogdata.GolemLootTracker.Since_Last_Hits == undefined) {
			loottrackerarray.push(`Since Last Hit: Unknown`)
		} else {
			loottrackerarray.push(`Since Last Hit: ${gloottrackertime(pogdata.GolemLootTracker.Since_Last_Hits)}`)
		}
	}

	if (Settings.gloottrackerlasthitavg || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Kills == 0) {
			loottrackerarray.push(`Last Hit%: Unknown`)
		} else {
			loottrackerarray.push(`Last Hit%: ${(pogdata.GolemLootTracker.Last_Hits / pogdata.GolemLootTracker.Kills * 100).toFixed(1)}%`)
		}
	}

	if (Settings.gloottrackerlastdamage || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Damage[0] == undefined) {
			loottrackerarray.push(`Last Damage: Unknown`)
		} else {
			loottrackerarray.push(`Last Damage: ${(pogdata.GolemLootTracker.Damage[0].toString()).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackeravgdamage || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Damage == 0) {
			loottrackerarray.push(`AVG Damage: Unknown`)
		} else {
			let added = 0
			for (i in pogdata.GolemLootTracker.Damage) {
				if (i < 10) {
					added = added + pogdata.GolemLootTracker.Damage[i]
				}
			}
			let count = pogdata.GolemLootTracker.Damage.length
			if (count > 10) { count = 10 }
			loottrackerarray.push(`AVG Damage: ${Math.round(added / count).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackerlastdps || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.DPS[0] == undefined) {
			loottrackerarray.push(`Last DPS: Unknown`)
		} else {
			loottrackerarray.push(`Last DPS: ${(pogdata.GolemLootTracker.DPS[0].toString()).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackeravgdps || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.DPS == 0) {
			loottrackerarray.push(`AVG DPS: Unknown`)
		} else {
			let added = 0
			for (i in pogdata.GolemLootTracker.DPS) {
				if (i < 10) {
					added = added + pogdata.GolemLootTracker.DPS[i]
				}
			}
			let count = pogdata.GolemLootTracker.DPS.length
			if (count > 10) { count = 10 }
			loottrackerarray.push(`AVG DPS: ${Math.round(added / count).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackerlastsinces4time || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Since_S4_Time[0] == undefined) {
			loottrackerarray.push(`Last Since S4 Time: Unknown`)
		} else {
			loottrackerarray.push(`Last Since S4 Time: ${(pogdata.GolemLootTracker.Since_S4_Time[0])}s`)
		}
	}

	if (Settings.gloottrackeravgsinces4time || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Since_S4_Time == 0) {
			loottrackerarray.push(`AVG Since S4 Time: Unknown`)
		} else {
			let added = 0
			for (i in pogdata.GolemLootTracker.Since_S4_Time) {
				if (i < 10) {
					added = added + pogdata.GolemLootTracker.Since_S4_Time[i]
				}
			}
			let count = pogdata.GolemLootTracker.Since_S4_Time.length
			if (count > 10) { count = 10 }
			loottrackerarray.push(`AVG Since S4 Time: ${Math.round(added / count / 60 % 60)}m ${Math.round(added / count % 60)}s`)
		}
	}

	if (Settings.gloottrackerlastdelaytime || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Delay_Time[0] == undefined) {
			loottrackerarray.push(`Last Delay Time: Unknown`)
		} else {
			if (pogdata.GolemLootTracker.Delay_Time[0] < 0) {
				loottrackerarray.push(`Last Delay Time: +${pogdata.GolemLootTracker.Delay_Time[0] * -1}s`)
			} else {
				loottrackerarray.push(`Last Delay Time: ${pogdata.GolemLootTracker.Delay_Time[0]}s`)
			}
		}
	}

	if (Settings.gloottrackeravgdelaytime || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Delay_Time == 0) {
			loottrackerarray.push(`AVG Delay Time: Unknown`)
		} else {
			let added = 0
			for (i in pogdata.GolemLootTracker.Delay_Time) {
				if (i < 10) {
					added = added + pogdata.GolemLootTracker.Delay_Time[i]
				}
			}
			let count = pogdata.GolemLootTracker.Delay_Time.length
			if (count > 10) { count = 10 }
			let time = (added / count).toFixed(2)
			if (time < 0) { time = `+${time * -1}` }
			loottrackerarray.push(`AVG Delay Time: ${time}s`)
		}
	}

	if (Settings.gloottrackerlastfighttime || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Fight_Time[0] == undefined) {
			loottrackerarray.push(`Last Fight Time: Unknown`)
		} else {
			loottrackerarray.push(`Last Fight Time: ${pogdata.GolemLootTracker.Fight_Time[0]}s`)
		}
	}

	if (Settings.gloottrackeravgfighttime || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Fight_Time == 0) {
			loottrackerarray.push(`AVG Fight Time: Unknown`)
		} else {
			let added = 0
			for (i in pogdata.GolemLootTracker.Fight_Time) {
				if (i < 10) {
					added = added + pogdata.GolemLootTracker.Fight_Time[i]
				}
			}
			let count = pogdata.GolemLootTracker.Fight_Time.length
			if (count > 10) { count = 10 }
			loottrackerarray.push(`AVG Fight Time: ${(added / count).toFixed(1)}s`)
		}
	}

	if (Settings.gloottrackerlastposition || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Position == undefined || pogdata.GolemLootTracker.Position == 0) {
			loottrackerarray.push(`Last Position: Unknown`)
		} else {
			loottrackerarray.push(`Last Position: #${(pogdata.GolemLootTracker.Position)}`)
		}
	}

	if (Settings.gloottrackerzealots || gloottrackertextcmd) {
		loottrackerarray.push(`Zealots: ${pogdata.GolemLootTracker.Zealots.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
	}

	if (Settings.gloottrackerrunecraftingxp || gloottrackertextcmd) {
		loottrackerarray.push(`Runecrafting XP: ${pogdata.GolemLootTracker.RunecraftingXP.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
	}

	if (Settings.gloottrackerbits || gloottrackertextcmd) {
		loottrackerarray.push(`Bits: ${pogdata.GolemLootTracker.Bits.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
	}

	if (Settings.gloottrackerendstonerose || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			loottrackerarray.push(`&9Endstone Roses&r: ${pogdata.GolemLootTracker.Endstone_Rose.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		} else {
			loottrackerarray.push(`Endstone Roses: ${pogdata.GolemLootTracker.Endstone_Rose.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackerenchantedendstone || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			loottrackerarray.push(`&aEnchanted End Stone&r: ${pogdata.GolemLootTracker.Enchanted_End_Stone.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		} else {
			loottrackerarray.push(`Enchanted End Stone: ${pogdata.GolemLootTracker.Enchanted_End_Stone.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackercrystalfragments || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			loottrackerarray.push(`&5Crystal Fragments&r: ${pogdata.GolemLootTracker.Crystal_Fragment.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		} else {
			loottrackerarray.push(`Crystal Fragments: ${pogdata.GolemLootTracker.Crystal_Fragment.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackerepicgolempets || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			loottrackerarray.push(`&5Epic Golem Pets&r: ${pogdata.GolemLootTracker.Epic_Golem_Pet.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		} else {
			loottrackerarray.push(`Epic Golem Pets: ${pogdata.GolemLootTracker.Epic_Golem_Pet.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackersinceepicgolempet || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Epic_Golem_Pet_History[0] == 0 || pogdata.GolemLootTracker.Epic_Golem_Pet_History[0] == undefined) {
			if (Settings.gloottrackerrare && !gloottrackertextcmd) {
				loottrackerarray.push(`Since &5Epic Pet&r: Unknown`)
			} else {
				loottrackerarray.push(`Since Epic Pet: Unknown`)
			}
		} else {
			if (Settings.gloottrackerrare && !gloottrackertextcmd) {
				loottrackerarray.push(`Since &5Epic Pet&r: ${gloottrackertime(pogdata.GolemLootTracker.Epic_Golem_Pet_History[1])}`)
			} else {
				loottrackerarray.push(`Since Epic Pet: ${gloottrackertime(pogdata.GolemLootTracker.Epic_Golem_Pet_History[1])}`)
			}
		}
	}

	if (Settings.gloottrackerepicgolempetavg || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			if (pogdata.GolemLootTracker.Kills == 0) {
				loottrackerarray.push(`&5Epic Golem Pet%&r: Unknown`)
			} else {
				loottrackerarray.push(`&5Epic Golem Pet%&r: ${(pogdata.GolemLootTracker.Epic_Golem_Pet / pogdata.GolemLootTracker.Kills * 100).toFixed(1)}%`)
			}
		} else {
			if (pogdata.GolemLootTracker.Kills == 0) {
				loottrackerarray.push(`Epic Golem Pet%: 0%`)
			} else {
				loottrackerarray.push(`Epic Golem Pet%: ${(pogdata.GolemLootTracker.Epic_Golem_Pet / pogdata.GolemLootTracker.Kills * 100).toFixed(1)}%`)
			}
		}
	}

	if (Settings.gloottrackerlegendarygolempets || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			loottrackerarray.push(`&6Legendary Golem Pets&r: ${pogdata.GolemLootTracker.Legendary_Golem_Pet.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		} else {
			loottrackerarray.push(`Legendary Golem Pets: ${pogdata.GolemLootTracker.Legendary_Golem_Pet.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackersincelegendarygolempet || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Legendary_Golem_Pet_History[0] == 0 || pogdata.GolemLootTracker.Legendary_Golem_Pet_History[0] == undefined) {
			if (Settings.gloottrackerrare && !gloottrackertextcmd) {
				loottrackerarray.push(`Since &6Legendary Pet&r: Unknown`)
			} else {
				loottrackerarray.push(`Since Legendary Pet: Unknown`)
			}
		} else {
			if (Settings.gloottrackerrare && !gloottrackertextcmd) {
				loottrackerarray.push(`Since &6Legendary Pet&r: ${gloottrackertime(pogdata.GolemLootTracker.Legendary_Golem_Pet_History[1])}`)
			} else {
				loottrackerarray.push(`Since Legendary Pet: ${gloottrackertime(pogdata.GolemLootTracker.Legendary_Golem_Pet_History[1])}`)
			}
		}
	}

	if (Settings.gloottrackerlegendarygolempetavg || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			if (pogdata.GolemLootTracker.Kills == 0) {
				loottrackerarray.push(`&6Legendary Golem Pet%&r: Unknown`)
			} else {
				loottrackerarray.push(`&6Legendary Golem Pet%&r: ${(pogdata.GolemLootTracker.Legendary_Golem_Pet / pogdata.GolemLootTracker.Kills * 100).toFixed(1)}%`)
			}
		} else {
			if (pogdata.GolemLootTracker.Kills == 0) {
				loottrackerarray.push(`Legendary Golem Pet%: 0%`)
			} else {
				loottrackerarray.push(`Legendary Golem Pet%: ${(pogdata.GolemLootTracker.Legendary_Golem_Pet / pogdata.GolemLootTracker.Kills * 100).toFixed(1)}%`)
			}
		}
	}

	if (Settings.gloottrackertierboostcore || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			loottrackerarray.push(`&6Tier Boost Cores&r: ${pogdata.GolemLootTracker.Tier_Boost_Core.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		} else {
			loottrackerarray.push(`Tier Boost Cores: ${pogdata.GolemLootTracker.Tier_Boost_Core.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`)
		}
	}

	if (Settings.gloottrackersincetierboostcore || gloottrackertextcmd) {
		if (pogdata.GolemLootTracker.Tier_Boost_Core_History[0] == 0 || pogdata.GolemLootTracker.Tier_Boost_Core_History[0] == undefined) {
			if (Settings.gloottrackerrare && !gloottrackertextcmd) {
				loottrackerarray.push(`Since &6Tier Boost Core&r: Unknown`)
			} else {
				loottrackerarray.push(`Since Tier Boost Core: Unknown`)
			}
		} else {
			if (Settings.gloottrackerrare && !gloottrackertextcmd) {
				loottrackerarray.push(`Since &6Tier Boost Core&r: ${gloottrackertime(pogdata.GolemLootTracker.Tier_Boost_Core_History[1])}`)
			} else {
				loottrackerarray.push(`Since Tier Boost Core: ${gloottrackertime(pogdata.GolemLootTracker.Tier_Boost_Core_History[1])}`)
			}
		}
	}

	if (Settings.gloottrackertierboostcoreavg || gloottrackertextcmd) {
		if (Settings.gloottrackerrare && !gloottrackertextcmd) {
			if (pogdata.GolemLootTracker.Kills == 0) {
				loottrackerarray.push(`&6Tier Boost Core%&r: Unknown`)
			} else {
				loottrackerarray.push(`&6Tier Boost Core%&r: ${(pogdata.GolemLootTracker.Tier_Boost_Core / pogdata.GolemLootTracker.Kills * 100).toFixed(1)}%`)
			}
		} else {
			if (pogdata.GolemLootTracker.Kills == 0) {
				loottrackerarray.push(`Tier Boost Core%: 0%`)
			} else {
				loottrackerarray.push(`Tier Boost Core%: ${(pogdata.GolemLootTracker.Tier_Boost_Core / pogdata.GolemLootTracker.Kills * 100).toFixed(1)}%`)
			}
		}
	}
	if (gloottrackertextcmd) {
		loottrackerarray.push(EndSeparator)
	}
	return loottrackerarray
}

function gloottrackertime(item) {
	let timeday = Math.floor((Date.now() - item) / 1000 / 60 / 60 / 24)
	let timehour = Math.floor((Date.now() - item) / 1000 / 60 / 60 % 24)
	let timeminute = Math.floor((Date.now() - item) / 1000 / 60 % 60)
	let timesecond = Math.floor((Date.now() - item) / 1000 % 60)
	let timestring

	if (timeday > 0) {
		timestring = `${timeday}d`
	}
	if (timehour > 0 || timeday > 0) {
		if (timestring == undefined) {
			timestring = `${timehour}h`
		} else {
			timestring = `${timestring} ${timehour}h`
		}
	}
	if (timeminute > 0 || timehour > 0 || timeday > 0) {
		if (timestring == undefined) {
			timestring = `${timeminute}m`
		} else {
			timestring = `${timestring} ${timeminute}m`
		}
	}
	if (timesecond > 0 || timeminute > 0 || timehour > 0 || timeday == 0) {
		if (timestring == undefined) {
			timestring = `${timesecond}s`
		} else {
			timestring = `${timestring} ${timesecond}s`
		}
	}
	if (timestring == undefined) {
		timestring = `Just now!`
	}
	return timestring
}



/*
  #####                                                                 
 #     #   ####   #    #  #    #  #####  #####    ####   #    #  #    # 
 #        #    #  #    #  ##   #    #    #    #  #    #  #    #  ##   # 
 #        #    #  #    #  # #  #    #    #    #  #    #  #    #  # #  # 
 #        #    #  #    #  #  # #    #    #    #  #    #  # ## #  #  # # 
 #     #  #    #  #    #  #   ##    #    #    #  #    #  ##  ##  #   ## 
  #####    ####    ####   #    #    #    #####    ####   #    #  #    # 
*/
let gcountdowntimertoggle
let gcountdowntimerstime = Date.now()
register("chat", () => {
	if (!Settings.overall) return
	if (!Settings.gcountdown) return
	gcountdowntimertoggle = true
	gcountdowntimerstime = Date.now()
}).setCriteria(/^&r&c&lThe ground begins to shake as an Endstone Protector rises from below!&r/).setContains();
register("chat", () => {
	if (!Settings.overall) return
	if (!Settings.gcountdown) return
	if (Settings.gcountdowndelay) {
		setTimeout(() => {
			if (gcountdowntimertoggle) {
				gcountdowntimertoggle = false
				let time = parseFloat(((gcountdowntimerstime - Date.now()) / 1000 + 20).toFixed(2))
				if (time == 0) {
					ChatLib.chat(`${prefix} Golem had &6&ono &6spawn delay.`)
				} else {
					if (time < 0) {
						ChatLib.chat(`${prefix} Golem spawned &6&o${time * -1}s &6delayed.`)
					} else {
						ChatLib.chat(`${prefix} Golem spawned &6&o${time}s &6earlier.`)
					}
				}
				if (pogdata.GolemLootTracker.Delay_Time != undefined) {
					pogdata.GolemLootTracker.Delay_Time.unshift(time)
					if (pogdata.GolemLootTracker.Delay_Time.length > Settings.gloottrackerhistory) {
						pogdata.GolemLootTracker.Delay_Time.length = Settings.gloottrackerhistory
					}
				} else {
					pogdata.GolemLootTracker.Delay_Time.push(time)
				}
				pogdata.save()
			} else {
				ChatLib.chat(`${prefix} Golem spawn starttime unknown (countdown).`)
			}
		}, 1);
	}
}).setCriteria(/^&r&c&lBEWARE - An Endstone Protector has risen!&r/).setContains();


let dcountdowntimertoggle
let dcountdowntimerstime = Date.now()
register("chat", (event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (!Settings.dcountdown) return
	dcountdowntimertoggle = true
	dcountdowntimerstime = Date.now()
}).setCriteria("&5☬" && "&7(&r&a8&r&7/&r&a8&r&7)").setContains();
register("chat", (event) => {
	if (!Settings.overall) return
	if (ChatLib.getChatMessage(event, true).includes(":")) return
	if (!Settings.dcountdown) return
	if (Settings.dcountdowndelay) {
		setTimeout(() => {
			if (dcountdowntimertoggle) {
				dcountdowntimertoggle = false
				let time = ((dcountdowntimerstime - Date.now()) / 1000 + 9).toFixed(2)
				if (time == 0) {
					ChatLib.chat(`${prefix} Dragon had &6&ono &6spawn delay.`)
				} else if (time < 0) {
					ChatLib.chat(`${prefix} Dragon spawned &6&o${time * -1}s &6delayed.`)
				} else {
					ChatLib.chat(`${prefix} Dragon spawned &6&o${time}s &6earlier.`)
				}
			} else {
				ChatLib.chat(`${prefix} Dragon spawn starttime unknown (countdown).`)
			}
		}, 1);
	}
}).setCriteria("&5☬ &r&d&lThe" && "Dragon&r&d&l has spawned!&r").setContains();


/*
  #####                                   #####   #       
 #     #  #  #    #   ####   ######      #     #  #    #  
 #        #  ##   #  #    #  #           #        #    #  
  #####   #  # #  #  #       #####        #####   #    #  
	   #  #  #  # #  #       #                 #  ####### 
 #     #  #  #   ##  #    #  #           #     #       #  
  #####   #  #    #   ####   ######       #####        #  
*/

let timesinces4time = Date.now()
register("chat", () => {
	if (!Settings.overall) return
	timesinces4time = Date.now()
}).setCriteria(/^&r&c&lYou feel a tremor from beneath the earth!&r/).setContains();

register("chat", () => {
	if (!Settings.overall) return
	if (Settings.timesinces4chat) {
		setTimeout(() => {
			let timediff = (Date.now() - timesinces4time) / 1000
			ChatLib.chat(`${prefix} Time Since S4: &6&o${(timediff / 60 % 60).toFixed(0)}m ${(timediff % 60).toFixed(0)}s&6.`)
			if (pogdata.GolemLootTracker.Since_S4_Time != undefined) {
				pogdata.GolemLootTracker.Since_S4_Time.unshift(parseFloat(timediff.toFixed(1)))
				if (pogdata.GolemLootTracker.Since_S4_Time.length > Settings.gloottrackerhistory) {
					pogdata.GolemLootTracker.Since_S4_Time.length = Settings.gloottrackerhistory
				}
			} else {
				pogdata.GolemLootTracker.Since_S4_Time.push(parseFloat(timediff.toFixed(1)))

			}
			pogdata.save()
		}, 99);
	}
}).setCriteria(/^&r&c&lThe ground begins to shake as an Endstone Protector rises from below!&r/).setContains();



/*
 #######                                   
	#     #  #####  #       ######   ####  
	#     #    #    #       #       #      
	#     #    #    #       #####    ####  
	#     #    #    #       #            # 
	#     #    #    #       #       #    # 
	#     #    #    ######  ######   ####  
*/
function fcstage4title() {
	if (Settings.stage4title) {
		Client.showTitle("&cGolem Stage 4", "", 5, 40, 5);
	}
}

function fcstage5title() {
	if (Settings.stage5title) {
		Client.showTitle("&cGolem Stage 5", "", 5, 40, 5);
	}
}



/*
 ######                                         
 #     #  ######  #####    ####    ####   ##### 
 #     #  #       #    #  #    #  #    #    #   
 ######   #####   #####   #    #  #    #    #   
 #   #    #       #    #  #    #  #    #    #   
 #    #   #       #    #  #    #  #    #    #   
 #     #  ######  #####    ####    ####     #   
*/
function fcreboottest() {
	for (c = 0; c < 20; c++) {
		World.playSound("mob.irongolem.death", Settings.srebootvolume / 100, 0)
	}
}
register("chat", () => {
	if (!Settings.overall) return;
	if (Settings.sreboots) {
		fcreboottest()
	}
}).setCriteria(/^&r&c\[Important\] &r&eThis server will restart soon: &r&bScheduled Reboot&r/).setContains();
register("command", () => {
	fcreboottest()
}).setName("creboottest")

//Game update
function fcupdatetest() {
	for (c = 0; c < 20; c++) {
		World.playSound("mob.irongolem.death", Settings.urebootvolume / 100, 0)
	}
}
register("chat", () => {
	if (!Settings.overall) return;
	if (Settings.ureboots) {
		fcupdatetest()
	}
}).setCriteria(/^&r&c\[Important\] &r&eThis server will restart soon: &r&bFor a game update&r/).setContains();
register("chat", () => {
	if (!Settings.overall) return;
	if (Settings.ureboots) {
		fcupdatetest()
	}
}).setCriteria(/^&r&c\[Important\] &r&eThis server will restart soon: &r&bGame Update&r/).setContains();
register("command", () => {
	fcupdatetest()
}).setName("cupdatetest")



/*
 #    #   ####   #####   #       #####   #        ####     ##    #####  
 #    #  #    #  #    #  #       #    #  #       #    #   #  #   #    # 
 #    #  #    #  #    #  #       #    #  #       #    #  #    #  #    # 
 # ## #  #    #  #####   #       #    #  #       #    #  ######  #    # 
 ##  ##  #    #  #   #   #       #    #  #       #    #  #    #  #    # 
 #    #   ####   #    #  ######  #####   ######   ####   #    #  #####  
*/

let justloaded = true
register("worldLoad", () => {
	if (justloaded) {
		justloaded = false
	} else {
		//General
		isSB = false

		//Displays
		tempdgolemlocation = false
		tempdgolemstage = false
		tempdgolemcountdown = false
		tempdgolemsinces4 = false

		//Reset location
		gloc = false
		inend = false
		indragonnest = false
		locscan1 = false
		locscan2 = false
		locscan3 = false
		locscan4 = false
		locscan5 = false
		locscan6 = false
		loc = "Scanning..."
		stage = "Scanning..."
		golemdied = false

		//WORLD
		gtesselatortoggle = false
		gtesselatorx = undefined
		gtesselatorz = undefined

		//Bossbar
		currenthpint = 5000000
		currenthp = "5M"
		maxhpint = 5000000
		maxhp = "5M"
		gdisplaybar = false
		displaylife = undefined
		gshowbossbarloading = false
		gbossbaroffsetobjective = false
		gbossbaroffsetdragon = false

		//Countdown
		//Golem
		gcountdowntimertoggle = false
		gcountdowntimerstime = Date.now()
		//Dragon
		dcountdowntimertoggle = false
		dcountdowntimerstime = Date.now()

		//Time Since Stage
		timesinces4time = Date.now()

		//Reset Golem Fight timer
		gfight = undefined
		gtime = undefined

		//Reset Dragon Fight timer
		dfight = undefined
		dtime = undefined

		//DPS
		//Golem
		gdpsgetting = false
		gdps = undefined
		gdps1st = undefined
		gdps1stt = false
		gdps2nd = undefined
		gdps2ndt = false
		gdps3rd = undefined
		gdps3rdt = false
		//Dragon
		ddpsgetting = false
		ddps = undefined
		ddps1st = undefined
		ddps1stt = false
		ddps2nd = undefined
		ddps2ndt = false
		ddps3rd = undefined
		ddps3rdt = false

		//Drops
		ghaslasthit = false
		gover0dmgcheck = false
		gover0dmg = false
		gscanloot = false
		gendstonerose = false
		genchantedendstone = false
		gcrystalfragment = false
		g4thdrop = false
	}
});



/*
 #######                                                    
	#     #####   #   ####    ####   ######  #####    ####  
	#     #    #  #  #    #  #    #  #       #    #  #      
	#     #    #  #  #       #       #####   #    #   ####  
	#     #####   #  #  ###  #  ###  #       #####        # 
	#     #   #   #  #    #  #    #  #       #   #   #    # 
	#     #    #  #   ####    ####   ######  #    #   ####  
*/
register("step", () => {
	displayopenfunc()
	golementityfunc()
	gtessellatorcoordsfunc()
	gscanforlootfunc()
}).setFps(20)

register("step", () => {
	gbossbarnumber() // NEEDS 10
}).setFps(10)

register("step", () => {
	autoreloadfunc()
	endcheckfunc()
	gloottrackerupdatefunc()
	ggethealth()
}).setFps(5)

register("step", () => {
	goleminscoreboard()
}).setDelay(2)

register("step", () => {
	inskyblock()
}).setDelay(1)



register("renderOverlay", () => {
	glocationfunc()
	gstagefunc()
	timesinces4func()
	gcountdownfunc()
	gloottrackerfunc()
	dcountdownfunc()
})