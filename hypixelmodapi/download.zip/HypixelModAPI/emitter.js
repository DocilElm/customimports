import { EventEmitter } from "./utils/EventEmitter.js"

export const emitter = new EventEmitter()
