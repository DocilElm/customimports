import { Color } from "../BloomCore/utils/Utils";
import {
    @ButtonProperty,
    @CheckboxProperty,
    Color,
    @ColorProperty,
    @PercentSliderProperty,
    @SelectorProperty,
    @SwitchProperty,
    @TextProperty,
    @Vigilant,
    @SliderProperty
} from '../Vigilance/index';

const getModuleVersion = () => JSON.parse(FileLib.read("LegalMap", "metadata.json")).version

@Vigilant("LegalMap", "LegalMap", {
    getCategoryComparator: () => (a, b) => {
        const categories = ["General", "Players", "Rooms", "Info"];
        return categories.indexOf(a.name) - categories.indexOf(b.name);
    }
})
class Config {
    constructor() {
        this.initialize(this)
        this.setCategoryDescription("General", 
            `
            &6&l&nLegalMap ${getModuleVersion()}


            &bNote: An API key is required for some features. To set it, use &f/lm setkey <apikey>&b.


            &7By UnclaimedBloom6
            `
        )
        this.setCategoryDescription("Info", 
            `
            &bIs this module bannable?
            &7No. This module only uses information which is normally available to the player, including the Scoreboard, Tab List, hotbar map and chat messages.



            &bWhat is LegalMap?
            &7LegalMap is a Dungeon Map with a design identical to IllegalMap (a dungeon scanning module). It aims to show the player all of the useful information possible without being overwhelming.



            &bHow does it work?
            &7The module scans the player's hotbar map in the dungeon and uses that information to redraw the map on your screen. The module checks certain pixels on the map which lets it get the exact shape and size of the dungeon.
            


            &bHow does it know which puzzles have been opened?
            &7When new purple pixels are detected on the map, LegalMap checks the tab list for puzzles which have not been assigned to a room yet, and assigns it.
            &7The name of the puzzle can then be rendered on the map (If you have Show Puzzles enabled).

            `
        )
    }

    mapMoveGui = new Gui()
    editDungeonInfoGui = new Gui()
    borderScaleGui = new Gui()

    // ---------------------------------------------------------------
    // General

    @SwitchProperty({
        name: "&aMap Enabled",
        description: "Toggle whether the map appears.",
        category: "General"
    })
    enabled = true;

    @ButtonProperty({
        name: "&aEdit Map",
        description: "Move the map, change the map scale, head scale etc.",
        category: "General"
    })
    MoveMap() {
        this.mapMoveGui.open()
    };

    @ColorProperty({
        name: "Background Color",
        description: "Change the background color and transparency of the map.",
        category: "General"
    })
    backgroundColor = new Color(0, 0, 0, 179/255);

    @SwitchProperty({
        name: "Hide In Boss",
        description: "Hides the map after you enter boss.\n&eNOTE: The dungeon info will also be hidden if it is set to 'Under Map'.",
        category: "General"
    })
    hideInBoss = false;

    @SwitchProperty({
        name: "Seperate In Boss",
        description: "When you enter boss, the dungeon info text will be set to 'Seprate' and will still be visible if 'Hide In Boss' is enabled.",
        category: "General"
    })
    seperateInBoss = false;

    @SwitchProperty({
        name: "&bScore Milestones",
        description: "Tells you when 270/300 score has been reached (Does not send a message in party chat).",
        category: "General",
        subcategory: "Score Milestones"
    })
    scoreMilestones = true;

    @SwitchProperty({
        name: "&aAnnounce 300 Score",
        description: "Announces in party chat when 300 score has been reached.",
        category: "General",
        subcategory: "Score Milestones"
    })
    announce300 = false;

    @TextProperty({
        name: "&a300 Score Message",
        description: "The message to send in party chat when 300 score has been reached (If announce 300 is enabled).",
        category: "General",
        subcategory: "Score Milestones",
        placeholder: "300 Score Reached!"
    })
    announce300Message = "300 Score Reached!"

    @SwitchProperty({
        name: "&eAnnounce 270 Score",
        description: "Announces in party chat when 270 score has been reached.",
        category: "General",
        subcategory: "Score Milestones"
    })
    announce270 = false;
    
    @TextProperty({
        name: "&e270 Score Message",
        description: "The message to send in party chat when 270 score has been reached (If announce 270 is enabled).",
        category: "General",
        subcategory: "Score Milestones",
        placeholder: "270 Score Reached!"
    })
    announce270Message = "270 Score Reached!"

    @SwitchProperty({
        name: "&eAnnounce Mimic Dead",
        description: "Announce in party chat when the mimic has been killed.",
        category: "General",
        subcategory: "Mimic"
    })
    announceMimic = false;

    @TextProperty({
        name: "&cMimic Killed Message",
        description: "If Announce Mimic Dead is enabled, say this message in party chat when the mimic has been killed near you.",
        category: "General",
        subcategory: "Mimic",
        placeholder: "Mimic Dead!"
    })
    announceMimicMessage = "Mimic Dead!";

    @TextProperty({
        name: "&cMimic Detection Messages",
        description: "If one of your party members has a mimic killed message which is not detected by the mod already, add it here separated with a comma.\nEg: mimic dead, mimic killed, breefing killed, and so on...",
        category: "General",
        subcategory: "Mimic",
        placeholder: ""
    })
    extraMimicMessages = "";

    @SelectorProperty({
        name: "&dDungeon Info",
        description: "Change where the dungeon info is rendered.\nThe dungeon into is the text under the map which shows the secrets, crypts etc.",
        category: "General",
        subcategory: "Dungeon Info",
        options: ["Under Map", "Separate", "Hidden"]
    })
    dungeonInfo = 0;

    @ButtonProperty({
        name: "&dEdit Dungeon Info",
        description: "If Dungeon Info is set to 'Separate' then this will let you move it and change the scale.",
        category: "General",
        subcategory: "Dungeon Info",
        placeholder: "Edit"
    })
    EditDungeonInfo() {
        this.editDungeonInfoGui.open()
    };

    @ColorProperty({
        name: "&dBackground Color",
        description: "Change the background color of the dungeon info (If separate). Set to fully transparent to disable.",
        category: "General",
        subcategory: "Dungeon Info"
    })
    dungeonInfoBackgroundColor = new Color(0, 0, 0, 179/255);

    @SelectorProperty({
        name: "&7Map Border",
        description: "Displays a border around the map.",
        category: "General",
        subcategory: "Map Border",
        options: ["Disabled", "§cR§aG§bB", "Solid Color", "Hollow"]
    })
    mapBorder = 0;

    @ColorProperty({
        name: "&7Border Color",
        description: "Change the color of the map border. Will only show if border is set to 'Solid Color' or 'Hollow'",
        category: "General",
        subcategory: "Map Border"
    })
    borderColor = new Color(0, 0, 0, 1);
    
    @ButtonProperty({
        name: "&7Edit Border",
        description: "Change the scale of the border and the RGB speed.",
        category: "General",
        subcategory: "Map Border"
    })
    EditBorderScale() {
        this.borderScaleGui.open()
    };



    // ---------------------------------------------------------------
    // Players

    @SwitchProperty({
        name: "&ePlayer Heads",
        description: "Show player heads on the map.",
        category: "Players",
        subcategory: "Player Heads"
    })
    playerHeads = true;

    @SwitchProperty({
        name: "&bSpirit Leap Names",
        description: "Show player's usernames on the map when holding spirit leaps or infinileap.",
        category: "Players",
        subcategory: "Player Names"
    })
    spiritLeapNames = true;

    @SwitchProperty({
        name: "&bShow Player Ranks",
        description: "Show players ranks when their name is being rendered on the map.\nEg &fUnclaimedBloom6 &7-> &6[MVP&0++&6] UnclaimedBloom6&7.\n&aRequires API key. &b/lm setkey <api key>&a.",
        category: "Players",
        subcategory: "Player Names"
    })
    showPlayerRanks = true;

    @SwitchProperty({
        name: "&bShow Own Name",
        description: "If show spirit leap names is enabled, render your own name as well.",
        category: "Players",
        subcategory: "Player Names"
    })
    showOwnName = false;

    // ---------------------------------------------------------------
    // Rooms

    @ColorProperty({
        name: "&8Wither Door Color",
        description: "Changes the wither door color.",
        category: "Rooms",
        subcategory: "Wither Doors"
    })
    witherDoorColor = new Color(0, 0, 0, 1);

    @SwitchProperty({
        name: "&dShow Puzzles",
        description: "Show the names of puzzles on the map after they are opened.",
        category: "Rooms",
        subcategory: "Puzzles"
    })
    showPuzzles = true;

    @SwitchProperty({
        name: "&dChange Puzzle Color",
        description: "Changes the color of the puzzle text depending on the checkmark in that room.\nNo longer displays original checkmark for the room.",
        category: "Rooms",
        subcategory: "Puzzles"
    })
    changePuzzleColor = false;
    
    @SelectorProperty({
        name: "&2Checkmark Style",
        description: "Show the names of puzzles on the map after they are opened.",
        category: "Rooms",
        subcategory: "Rooms",
        options: ["Regular", "Vanilla"]
    })
    checkmarkStyle = 0;
    
    @SwitchProperty({
        name: "&cWhite Checkmark Blood",
        description: "Puts a white checkmark on blood room once the watcher has finished spawning mobs, but they have not all been killed.",
        category: "Rooms",
        subcategory: "Blood"
    })
    whiteCheckBlood = true;

    // ---------------------------------------------------------------
    // Rooms
    @ButtonProperty({
        name: "&d&lBoop!",
        description: "This is a placeholder.",
        category: "Info"
    })
    Btn() {};
}

export default new Config()