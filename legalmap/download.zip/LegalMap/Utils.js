import { Color } from "../BloomCore/utils/Utils"
import PogObject from "../PogData"
import Config from "./Config"

export const prefix = "&8[&bLegalMap&8]"

export const lmData = new PogObject("LegalMap", {
    "firstTime": true,
    "map": {
        "x": 0,
        "y": 0,
        "scale": 1,
        "headScale": 1,
        "checkmarkScale": 1
    },
    "dungeonInfo": {
        "x": 0,
        "y": 0,
        "scale": 1
    },
    "border": {
        "scale": 1,
        "rgbSpeed": 1
    },
    "debugMap": false
}, "data.json")

export const defaultMapImage = new Image("DefaultMap.png", "./assets/DefaultMap.png")
export const greenCheck = new Image("BloomMapGreenCheck.png", "./assets/BloomMapGreenCheck.png")
export const whiteCheck = new Image("BloomMapWhiteCheck.png", "./assets/BloomMapWhiteCheck.png")
export const failedRoom = new Image("BloomMapFailedRoom.png", "./assets/BloomMapFailedRoom.png")
export const questionMark = new Image("BloomMapQuestionMark.png", "./assets/BloomMapQuestionMark.png")

// Vanilla Checkmarks
export const greenCheckVanilla = new Image("greenCheckVanilla.png", "./assets/greenCheckVanilla.png")
export const whiteCheckVanilla = new Image("whiteCheckVanilla.png", "./assets/whiteCheckVanilla.png")
export const failedRoomVanilla = new Image("failedRoomVanilla.png", "./assets/failedRoomVanilla.png")
export const questionMarkVanilla = new Image("questionMarkVanillaa.png", "./assets/questionMarkVanillaa.png")

export const BlueMarker = new Image("blueMarker.png", "../BloomCore/assets/blueMarker.png")
export const GreenMarker = new Image("greenMarker.png", "../BloomCore/assets/greenMarker.png")

export const getCheckmarks = () => {
    if (Config.checkmarkStyle == 0) return {
        30: greenCheck,
        34: whiteCheck,
        18: failedRoom,
        119: questionMark
    }
    else return {
        30: greenCheckVanilla,
        34: whiteCheckVanilla,
        18: failedRoomVanilla,
        119: questionMarkVanilla
    }
}

export const mapRGBs = {
    18: new Color(1, 0, 0, 1), // Blood
    85: new Color(65/255, 65/255, 65/255, 1), // Unexplored
    30: new Color(20/255, 133/255, 0/255, 1), // Entrance
    63: new Color(107/255, 58/255, 17/255, 1), // Regular
    82: new Color(224/255, 0/255, 255/255, 1), // Fairy
    62: new Color(216/255, 127/255, 51/255, 1), // Trap
    74: new Color(254/255, 223/255, 0/255, 1), // Yellow
    66: new Color(117/255, 0/255, 133/255, 1), // Puzzle
    119: new Color(0, 0, 0, 1) // Wither door
}


// LcarusPhantom code
let red = 1
let green = 0
let blue = 0
let lastRgb = null
const rgb = () => {
    if (red >= 1) {
        if (blue > 0) blue = blue - 0.05
        else green = green + 0.05
        if (green >= 1) {
            green = 1
            red = red - 0.05
        }
    }
    else if (green >= 1.0) {
        if (red > 0) red = red - 0.05
        else blue = blue + 0.05
        if (blue >= 1) {
            blue = 1
            green = green - 0.05
        }
    }
    else if (blue >= 1) {
        if (green > 0) green = green - 0.05
        else red = red + 0.05
        if (red >= 1) {
            red = 1
            blue = blue - 0.05
        }
    }
}

register("step", () => {
    const d = Date.now()
    if (Config.mapBorder !== 1 || d - lastRgb < 100/lmData.border.rgbSpeed)
    rgb()
    lastRgb = d
})

export const getRgb = () => [red, green, blue]

export const renderMap = (mapData) => {
    Client.getMinecraft().field_71460_t.func_147701_i().func_148250_a(mapData, true)
}

export const roomTypes = {
    63: "Normal",
    30: "Entrance",
    74: "Yellow",
    18: "Blood",
    66: "Puzzle",
    62: "Trap"
}