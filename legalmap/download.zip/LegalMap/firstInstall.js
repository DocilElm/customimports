import { lmData } from "./Utils"

register("step", () => {
    if (!lmData.firstTime) return
    lmData.firstTime = false
    lmData.save()
    ChatLib.chat(`&b&m${ChatLib.getChatBreak(" ")}`);   
    [
        "&a&lThank you for installing &b&lLegalMap&a&l!\n",
        "&bTo open the config GUI, use the &e/lm &bcommand.\n",
        "&eIf you have any feature requests or would like to report",
        "&ea bug, DM &6Unclaimed#6151&e."
    ].map(a => ChatLib.chat(ChatLib.getCenteredText(a)))
    ChatLib.chat(`&b&m${ChatLib.getChatBreak(" ")}`)
}).setFps(5)