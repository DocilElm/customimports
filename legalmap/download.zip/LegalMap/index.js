/// <reference types="../CTAutocomplete" />
/// <reference lib="es2015" />

import Dungeon from "../BloomCore/dungeons/Dungeon"
import { getApiKeyInfo, getHead, getHypixelPlayer, getMojangInfo, getRecentProfile } from "../BloomCore/utils/APIWrappers"
import { bcData, BufferedImage, Color, getDungeonMap, getMapColors, getMapData, getRank, isBetween, renderCenteredString } from "../BloomCore/utils/Utils"
import Promise from "../PromiseV2"
import Config from "./Config"
import { BlueMarker, defaultMapImage, getCheckmarks, getRgb, GreenMarker, lmData, mapRGBs, prefix, renderMap } from "./Utils"
import "./firstInstall"
import "./scoreMilestones"
import "./mimic"

const cachedPlayerHeads = new Map() // ["UnclaimedBloom6": HEAD_IMAGE]

let mapBuffered = new BufferedImage(23, 23, BufferedImage.TYPE_4BYTE_ABGR)
let mapImage = new Image(mapBuffered)
let mapIsEmpty = true

// For some reason, using Graphics here to just draw a rect does not work when clearing the image.
const setPixels = (x1, y1, width, height, color) => {
    if (!color) return
    for (let x = x1; x < x1 + width; x++) for (let y = y1; y < y1 + height; y++) mapBuffered.setRGB(x, y, color.getRGB())
}

const getPlayerHead = (player, blackBorder) => {
    if (!cachedPlayerHeads.has(player)) return getHead(player, blackBorder)

    return new Promise((resolve) => {
        resolve(cachedPlayerHeads.get(player))
    })
}

// Set the map to blank pixels
const clearMap = () => {
    setPixels(0, 0, 23, 23, new Color(0, 0, 0, 0))
}

register("command", () => {
    clearMap()
}).setName("clearmap")

const puzzleNames = {
    "Higher Or Lower": "Blaze"
}

// For the puzzle text color
const puzzleStatusColors = {
    18: 0,
    66: 1,
    34: 2,
    30: 3
}

const checkmarkMap = new Map() // {dungeonIndex: int, checkmarkImage: Image}
let players = {} // {"UnclaimedBloom6":{"head": Image, "uuid": "", "hasSpirit": true, "rank": "&6[MVP&0++&6] ", "visited": ["Trap", "Blaze"]}}
let puzzles = {} // {"Water Board":{"pos": [2, 4], "checkmark": 1}, ...} checkmark: 0=failed, 1=incomplete, 2=white check, 3=green check
let unassignedPuzzles = [] // [[0, 5], [2,4], ...] Coordinates of puzzles on map (0-5)
let trapPos = null // null or [0-128, 0-128]

// Reset variables upon world load
register("worldUnload", () => {
    clearMap()
    playerHeads = {}
    checkmarkMap.clear()
    puzzles = {}
    players = {}
    mapIsEmpty = true
    trapPos = null
    rooms = []
})

const getPuzzleName = (name) => Object.keys(puzzleNames).includes(name) ? puzzleNames[name] : name

register("tick", () => {
    if (!Dungeon.inDungeon || !Config.enabled || !unassignedPuzzles.length) return
    let puz = Dungeon.puzzles.filter(a => a !== "???").filter(a => !Object.keys(puzzles).includes(getPuzzleName(a)))
    if (!puz.length) return
    let puzzleName = puz[0]
    puzzleName = getPuzzleName(puzzleName)
    puzzles[puzzleName] = {}
    puzzles[puzzleName].check = 1
    puzzles[puzzleName].pos = unassignedPuzzles.shift()
})

// Update player icons from hotbar map
register("tick", () => {
    if (!Dungeon.inDungeon || !Dungeon.mapCorner) return
    for (let p of Object.keys(players)) {
        let player = players[p]
        if (!players[p].inRender) {
            let icon = Object.keys(Dungeon.icons).find(key => Dungeon.icons[key].player == p)
            if (!icon) continue
            icon = Dungeon.icons[icon]
            player.iconX = MathLib.map(icon.x-Dungeon.mapCorner[0]*2, 0, 256, 0, 138)
            player.iconY = MathLib.map(icon.y-Dungeon.mapCorner[1]*2, 0, 256, 0, 138)
            player.yaw = icon.rotation
        }
        let x = player.iconX
        let y = player.iconY
        
        let visited = player.visited
        let [rx, ry] = [Math.floor(x/(128/6)), Math.floor(y/(128/6))]

        if (trapPos && trapPos[0] == rx && trapPos[1] == ry && !visited.includes("Trap")) visited.push("Trap")
        let puz = Object.keys(puzzles).find(key => puzzles[key].pos[0] == rx && puzzles[key].pos[1] == ry)
        if (puz && !visited.includes(puz)) visited.push(puz)
    }
})

// Get player heads, spirit, rank etc for all players in the dungeon party
register("tick", () => {
    if (!Dungeon.inDungeon || !Config.enabled) return
    for (let p of Dungeon.party) {
        if (Object.keys(players).includes(p)) continue
        players[p] = {
            "head": null,
            "hadSpirit": false,
            "rank": "",
            "visited": [],
            "iconX": 0,
            "iconY": 0,
            "inRender": false
        }
        let player = p
        getPlayerHead(player, true).then(head => {
            players[player].head = head
            cachedPlayerHeads.set(player, head)
        })
        getMojangInfo(player).then(mi => {
            if (!mi) return
            let uuid = mi.id
            players[player].uuid = uuid
            if (!bcData.apiKey) return
            Promise.all([
                getRecentProfile(uuid, null, bcData.apiKey),
                getHypixelPlayer(uuid, bcData.apiKey)
            ]).then(values => {
                let [sbProfile, pInfo] = values
                let mem = sbProfile['members'][uuid]
                let pets = mem.pets
                let p = players[player]
                p.hasSpirit = pets ? pets.some(a => a.type == "SPIRIT" && a.tier == "LEGENDARY") : false
                let rank = getRank(pInfo)
                p.rank = rank
                p.formatted = `${rank} ${player}`.replace("&7 ", "&7")
                ls = mem.last_save
            }).catch(e => ChatLib.chat(e.toString()))
        }).catch(e => ChatLib.chat(e.toString()))
    }
})

// Update all players in render distance
register("step", () => {
    if (!Dungeon.inDungeon || !Config.enabled) return
    for (let p of Object.keys(players)) {
        let player = World.getPlayerByName(p)
        if (!player) {
            players[p].inRender = false
            continue
        }
        if (player.getPing() == -1 && !Dungeon.runEnded) {
            delete players[p]
            continue
        }
        if (!isBetween(player.getX(), -200, -10) || !isBetween(player.getZ(), -200, -10)) continue
        players[p].inRender = true
        players[p].iconX = MathLib.map(player.getX(), -200, -10, 0, 128)
        players[p].iconY = MathLib.map(player.getZ(), -200, -10, 0, 128)
        players[p].yaw = player.getYaw() + 180
    }
}).setFps(60)

let mapLine1 = "&7Secrets: &b?    &7Crypts: &c0    &7Mimic: &c✘"
let mapLine2 = "&7Min Secrets: &b?    &7Deaths: &a0    &"

// Scan the hotmar map, build the map image, make the info text for under the map
Dungeon.onMapData((mapData) => {
    if (!Dungeon.inDungeon || !Config.enabled) return

    const colors = mapData.field_76198_e
    if (!colors || colors[0] == 119) return
    if (!Dungeon.mapCorner) return

    clearMap()
    const checkmarkImages = getCheckmarks()
    const tempCheckmarkMap = new Map()
    // Find important points on the map and build a new one
    let xx = -1
    for (let x = Dungeon.mapCorner[0]+(Dungeon.mapRoomSize/2); x < 118; x+=Dungeon.mapGapSize/2) {
        let yy = -1
        xx++
        for (let y = Dungeon.mapCorner[1]+(Dungeon.mapRoomSize/2)+1; y < 118; y+=Dungeon.mapGapSize/2) {
            yy++
            let i = x + y*128
            if (colors[i] == 0) continue
            let center = colors[i-1] // Pixel where the checkmarks spawn
            let roomColor = colors[i+5 + 128*4] // Pixel in the borrom right-ish corner of the room which tells the room color.
            // Main room
            if (!(xx%2) && !(yy%2)) {
                let rmx = xx/2
                let rmy = yy/2
                let roomIndex = rmx * 6 + rmy
                setPixels(xx*2, yy*2, 3, 3, mapRGBs[roomColor])
                // Checkmarks and stuff
                if (roomColor == 18 && Dungeon.watcherCleared && Config.whiteCheckBlood) {
                    tempCheckmarkMap.set(roomIndex, checkmarkImages[34]) // White checkmark
                }
                if (center in checkmarkImages && (roomColor !== center)) {
                    tempCheckmarkMap.set(roomIndex, checkmarkImages[center])
                    if (roomColor == 66) {
                        let p = Object.keys(puzzles).find(key => puzzles[key].pos[0] == rmx && puzzles[key].pos[1] == rmy)
                        if (p) puzzles[p].check = puzzleStatusColors[center]
                    } 
                }
                // Puzzles
                if (roomColor == 66 && !Object.keys(puzzles).some(a => puzzles[a].pos[0] == rmx && puzzles[a].pos[1] == rmy) && !unassignedPuzzles.some(a => a[0] == rmx && a[1] == rmy)) {
                    unassignedPuzzles.push([rmx, rmy])
                }
                // Trap
                if (roomColor == 62) trapPos = [rmx, rmy]
                continue
            }
            // Center of 2x2
            if (xx%2 && yy%2) {
                setPixels(xx*2+1, yy*2+1, 1, 1, mapRGBs[center])
                continue
            }
            
            // Place where no doors or rooms can spawn
            if ((!(xx%2) && !(yy%2)) || (xx%2 && yy%2)) continue

            let horiz = [colors[i-128-4], colors[i-128+4]]
            let vert = [colors[i-128*5], colors[i+128*3]]
            // Door
            if (horiz.every(a => !a) || vert.every(a => !a)) {
                if (center == 119) setPixels(xx*2+1, yy*2+1, 1, 1, Config.witherDoorColor)
                else if (center == 63) setPixels(xx*2+1, yy*2+1, 1, 1, new Color(92/255, 52/255, 14/255, 1))
                else setPixels(xx*2+1, yy*2+1, 1, 1, mapRGBs[center])
                continue
            }
            // Join for a larger room
            if (horiz.every(a => !!a) && vert.every(a => !!a)) {
                setPixels(xx*2, yy*2, 3, 3, mapRGBs[center])
                continue
            }
        }
    }
    mapImage = new Image(mapBuffered)
    mapIsEmpty = false

    // Update the checkmark map now. Clearing it at the start of the function makes the checkmarks flicker.
    checkmarkMap.forEach((img, ind) => {
        if (!tempCheckmarkMap.has(ind)) checkmarkMap.delete(ind)
    })
    tempCheckmarkMap.forEach((img, ind) => {
        checkmarkMap.set(ind, img)
    })
})

register("tick", () => {
    if ((!Dungeon.inDungeon || !Config.enabled) && !Config.mapMoveGui.isOpen()) return
    let dSecrets = "&7Secrets: " + (!Dungeon.secretsFound ? "&b?" : `&b${Dungeon.secretsFound}&8-&e${Dungeon.secretsRemaining}&8-&c${Dungeon.totalSecrets}`)
    let dCrypts = "&7Crypts: " + (Dungeon.crypts >= 5 ? `&a${Dungeon.crypts}` : Dungeon.crypts > 0 ? `&e${Dungeon.crypts}` : `&c0`)
    let dMimic = [6, 7].includes(Dungeon.floorNumber) ? ("&7Mimic: " + (Dungeon.mimicKilled ? "&a✔" : "&c✘")) : ""

    let minSecrets = "&7Min Secrets: " + (!Dungeon.secretsFound ? "&b?" : Dungeon.minSecrets > Dungeon.secretsFound ? `&e${Dungeon.minSecrets}` : `&a${Dungeon.minSecrets}`)
    let dDeaths = "&7Deaths: " + (Dungeon.deathPenalty < 0 ? `&c${Dungeon.deathPenalty}` : "&a0")
    let dScore = "&7Score: " + (Dungeon.score >= 300 ? `&a${Dungeon.score}` : Dungeon.score >= 270 ? `&e${Dungeon.score}` : `&c${Dungeon.score}`) + (Dungeon.isPaul ? " &b★" : "")

    mapLine1 = `${dSecrets}    ${dCrypts}    ${dMimic}`.trim()
    mapLine2 = `${minSecrets}    ${dDeaths}    ${dScore}`.trim()
})

const renderPlayers = () => {
    let keys = Object.keys(players)
    // Move the player to the end of the array so they get rendered above everyone else
    if (keys.includes(Player.getName())) {
        const ind = keys.indexOf(Player.getName())
        keys = keys.concat(keys.splice(ind, 1))
    }
    for (let p of keys) {
        if (Dungeon.deadPlayers.has(p) && p !== Player.getName()) continue
        let size = [7, 10]
        let head = p == Player.getName() ? GreenMarker : BlueMarker
        if (Config.playerHeads && players[p].head) {
            size = [10, 10]
            head = players[p].head
        }
        let x = players[p].iconX
        let y = players[p].iconY
        if (!x && !y) continue
        let yaw = players[p].yaw || 0

        Renderer.retainTransforms(true)
        Renderer.translate(lmData.map.x, lmData.map.y)
        Renderer.scale(lmData.map.scale, lmData.map.scale)
        Renderer.translate(x+5, y+5)
        // Renderer.drawRect(Renderer.RED, 0, 0, 1, 1)
        let dontRenderOwn = !Config.showOwnName && p == Player.getName() 
        // Render the player name
        if (Config.spiritLeapNames && ["Spirit Leap", "Infinileap"].includes(Player.getHeldItem()?.getName()?.removeFormatting()) && !dontRenderOwn) {
            let name = players[p].formatted && Config.showPlayerRanks ? players[p].formatted : p
            let width = Renderer.getStringWidth(name)
            let scale = lmData.map.headScale/1.75
            Renderer.translate(0, 7)
            Renderer.scale(scale, scale)
            Renderer.drawRect(Renderer.color(0, 0, 0, 150), -width/2-2, -2, width+4, 11)
            Renderer.drawStringWithShadow(name, -width/2, 0)
            Renderer.scale(1.75/lmData.map.headScale, 1.75/lmData.map.headScale)
            
            Renderer.translate(0, -7)
        }
        Renderer.scale(lmData.map.headScale, lmData.map.headScale)
        Renderer.rotate(yaw)
        Renderer.translate(-size[0]/2, -size[1]/2)
        Renderer.drawImage(head, 0, 0, size[0], size[1])
        
        Renderer.retainTransforms(false)
    }
}
let ll = 128/23
const getRoomPosition = (x, y) => [ll*1.5 + (ll*4*x), ll*1.5 + (ll*4*y)]

// Checkmark status of the puzzle
const puzzleTextColors = {
    0: new Color(161/255, 0, 0, 1),
    1: Color.WHITE,
    2: Color.YELLOW,
    3: Color.GREEN
}

const renderPuzzleNames = () => {
    for (let puz of Object.keys(puzzles)) {
        Renderer.translate(lmData.map.x, lmData.map.y)
        Renderer.scale(lmData.map.scale, lmData.map.scale)
        let [rx, ry] = puzzles[puz].pos
        let [x, y] = getRoomPosition(rx, ry)
        let puzzleName = puz
        let color = null
        if (Config.changePuzzleColor) color = puzzleTextColors[puzzles[puz].check]
        renderCenteredString(puzzleName, x+5, y+4, 0.7, true, color)
    }
}

const renderMoveGuiStuff = () => {
    renderCenteredString([
        "Scroll to change the map scale.",
        "Shift + Scroll to change player head scale.",
        "Control + Scroll to change checkmark scale."
    ], Renderer.screen.getWidth()/2, Renderer.screen.getHeight()/3, 1, false)
    if (Dungeon.inDungeon && Config.enabled) return

    let [headX, headY] = [(lmData.map.x+60)*lmData.map.scale, (lmData.map.y+80)*lmData.map.scale]
    let [headW, headH] = [10*lmData.map.headScale, 10*lmData.map.headScale]
    Renderer.drawRect(Renderer.WHITE, headX-(headW/2), headY-(headH/2), headW, headH)

    let checks = getCheckmarks()
    // Add fake checkmarks
    checkmarkMap.set(0, checks[34])
    checkmarkMap.set(12, checks[30])
    checkmarkMap.set(13, checks[18])
    checkmarkMap.set(16, checks[18])
}

register("command", () => Dungeon.bossEntry = Date.now()).setName("/boss")

const renderDungeonInfo = () => {
    // Under Map
    if (Config.dungeonInfo == 0) {
        if ((!Config.hideInBoss && !Config.seperateInBoss) || !Dungeon.bossEntry) renderUnderMapInfo()
    }
    // Seperate
    if (Config.dungeonInfo == 1 || Config.editDungeonInfoGui.isOpen() || (Config.seperateInBoss && Config.dungeonInfo == 0)) {
        renderSeperateInfo()
    }
}

const renderUnderMapInfo = () => {
    Renderer.retainTransforms(true)
    Renderer.translate(lmData.map.x, lmData.map.y)
    Renderer.scale(lmData.map.scale, lmData.map.scale)
    Renderer.translate(138/2, 135)
    Renderer.scale(0.6, 0.6)
    let w1 = Renderer.getStringWidth(mapLine1)
    let w2 = Renderer.getStringWidth(mapLine2)
    Renderer.drawStringWithShadow(mapLine1, -w1/2, 0)
    Renderer.drawStringWithShadow(mapLine2, -w2/2, 10)
    Renderer.retainTransforms(false)
}

const renderSeperateInfo = () => {
    let lines = mapLine1.split("    ").concat(mapLine2.split("    "))
    let width = lines.map(a => Renderer.getStringWidth(a)).sort((a, b) => b-a)[0] + 4
    let height = 7*lines.length + (lines.length-1)*2 + 4
    let c = Config.dungeonInfoBackgroundColor
    let [r, g, b, a] = [c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()]
    Renderer.retainTransforms(true)
    Renderer.translate(lmData.dungeonInfo.x, lmData.dungeonInfo.y)
    Renderer.scale(lmData.dungeonInfo.scale, lmData.dungeonInfo.scale)
    Renderer.drawRect(Renderer.color(r, g, b, a), 0, 0, width, height)
    for (let i = 0; i < lines.length; i++) {
        Renderer.drawStringWithShadow(lines[i], 2, 7*i + i*2 + 2)
    }
    Renderer.retainTransforms(false)
}

const renderCheckmarks = () => {
    // Render the checkmarks
    for (let entry of checkmarkMap.entries()) {
        let [roomIndex, checkmarkImage] = entry
        let rx = Math.floor(roomIndex / 6)
        let ry = roomIndex % 6
        let [x, y] = getRoomPosition(rx, ry)
        if (Config.changePuzzleColor && Object.keys(puzzles).some(a => puzzles[a].pos[0] == rx && puzzles[a].pos[1] == ry)) continue
        let [w, h] = [12*lmData.map.checkmarkScale, 12*lmData.map.checkmarkScale]
        Renderer.retainTransforms(true)
        Renderer.translate(lmData.map.x, lmData.map.y)
        Renderer.scale(lmData.map.scale, lmData.map.scale)
        Renderer.translate(x + (128/23)-1, y + (128/23)-1)
        Renderer.drawImage(checkmarkImage, -w/2, -h/2, w, h)
        Renderer.retainTransforms(false)
    }
}

const renderDungeonInfoEditGui = () => {
    renderCenteredString("Scroll to change the scale", Renderer.screen.getWidth()/2, Renderer.screen.getHeight()/3, 1, false)
}

const renderBorderEditGui = () => {
    let txt = ["Scroll to change the scale"]
    if (Config.mapBorder == 1) {
        txt.push("Control + Scroll to change RGB speed")
        txt.push(`RGB Speed: ${lmData.border.rgbSpeed}`)
    }
    renderCenteredString(txt, Renderer.screen.getWidth()/2, Renderer.screen.getHeight()/3, 1, false)
}

const defaultMapSize = [138, 138] // Entire map including space around map

const renderMapBorder = () => {
    let [w, h] = defaultMapSize
    h += Config.dungeonInfo == 0 ? 10 : 0
    Renderer.retainTransforms(true)
    Renderer.translate(lmData.map.x, lmData.map.y)
    Renderer.scale(lmData.map.scale,lmData.map.scale)
    let drawMode = Config.mapBorder == 3 ? 1 : 7
    let color = Config.borderColor.hashCode()
    if (Config.mapBorder == 1) {
        const [r, g, b] = getRgb()
        color = Renderer.color(r*255, g*255, b*255, 255)
    }
    Renderer.drawLine(color, 0, 0, 0, h, lmData.border.scale, drawMode)
    Renderer.drawLine(color, 0, 0, w, 0, lmData.border.scale, drawMode)
    Renderer.drawLine(color, w, 0, w, h, lmData.border.scale, drawMode)
    Renderer.drawLine(color, 0, h, w, h, lmData.border.scale, drawMode)
    Renderer.retainTransforms(false)
}

const renderMap = () => {
    let map = mapIsEmpty ? defaultMapImage : mapImage
    let [w, h] = defaultMapSize
    h += Config.dungeonInfo == 0 ? 10 : 0
    Renderer.retainTransforms(true)
    Renderer.translate(lmData.map.x, lmData.map.y)
    Renderer.scale(lmData.map.scale, lmData.map.scale)
    Renderer.drawRect(Config.backgroundColor.hashCode(), 0, 0, w, h)
    Renderer.translate(5, 5)
    Renderer.drawImage(map, 0, 0, 128, 128)
    Renderer.retainTransforms(false)
}

// Main Rendering
register("renderOverlay", () => {
    if ((!Dungeon.inDungeon || !Config.enabled || !mapBuffered || !Dungeon.mapCorner) && !Config.mapMoveGui.isOpen() && !Config.editDungeonInfoGui.isOpen()) return
    if (mapIsEmpty && !Config.mapMoveGui.isOpen() && !Config.editDungeonInfoGui.isOpen()) return // Stops it from rendering the default map for a split second at the start of the run
    
    if (!Config.hideInBoss || !Dungeon.bossEntry) {
        renderMap()
        if (Config.mapBorder !== 0) renderMapBorder()
        renderCheckmarks()
        if (Config.showPuzzles) renderPuzzleNames()
        renderPlayers()
    }
    if (Config.dungeonInfo !== 2) renderDungeonInfo()

    // Edit guis
    if (Config.editDungeonInfoGui.isOpen()) renderDungeonInfoEditGui()
    if (Config.mapMoveGui.isOpen()) renderMoveGuiStuff()
    if (Config.borderScaleGui.isOpen()) renderBorderEditGui()
})

// Hotbar map rendering and debug
register("renderOverlay", () => {
    if (!Dungeon.inDungeon || !lmData.debugMap || !Dungeon.mapData) return
    let mapData = Dungeon.mapData
    let colors = mapData.field_76198_e
    Renderer.retainTransforms(true)
    Renderer.translate(400, 30)
    Renderer.scale(2, 2)
    renderMap(mapData)

    Renderer.drawRect(Renderer.RED, 0, 0, 1, 1)
    Renderer.drawRect(Renderer.RED, 127, 0, 1, 1)
    Renderer.drawRect(Renderer.RED, 0, 127, 1, 1)
    Renderer.drawRect(Renderer.RED, 127, 127, 1, 1)
    
    if (!Dungeon.mapCorner) return

    for (let x = Dungeon.mapCorner[0]; x < 128; x+=Dungeon.mapGapSize) {
        for (let y = Dungeon.mapCorner[1]; y < 128; y+=Dungeon.mapGapSize) {
            Renderer.drawRect(Renderer.YELLOW, x, y, 1, 1)
        }
    }
    if (Dungeon.mapLeft) Renderer.drawRect(Renderer.GOLD, Dungeon.mapLeft[0], Dungeon.mapLeft[1], 1, 1)
    if (Dungeon.mapTop) Renderer.drawRect(Renderer.LIGHT_PURPLE, Dungeon.mapTop[0], Dungeon.mapTop[1], 1, 1)
    Renderer.drawRect(Renderer.AQUA, Dungeon.mapCorner[0], Dungeon.mapCorner[1], 1, 1)

    let xx = -1
    for (let x = Dungeon.mapCorner[0]+(Dungeon.mapRoomSize/2); x < 118; x+=Dungeon.mapGapSize/2) {
        let yy = -1
        xx++
        for (let y = Dungeon.mapCorner[1]+(Dungeon.mapRoomSize/2)+1; y < 118; y+=Dungeon.mapGapSize/2) {
            yy++
            let i = x + y*128
            if (colors[i] == 0) continue

            // Center of room
            if (!(xx%2) && !(yy%2)) {
                Renderer.drawRect(Renderer.RED, x-1, y, 1, 1) // Checkmark color
                Renderer.drawRect(Renderer.BLUE, x+5, y+4, 1, 1) // Main room color
            }
            // Center of 2x2
            if (xx%2 && yy%2) {
                Renderer.drawRect(Renderer.WHITE, x, y, 1, 1)
            }
            // Doors or separator for large room
            if ((!(xx%2) && !(yy%2)) || (xx%2 && yy%2)) continue
            Renderer.drawRect(Renderer.YELLOW, x, y-1, 1, 1) // Center of door
            Renderer.drawRect(Renderer.AQUA, x+4, y-1, 1, 1) // Dungeon.mapLeft side
            Renderer.drawRect(Renderer.AQUA, x-4, y-1, 1, 1) // Right side
            Renderer.drawRect(Renderer.GREEN, x, y+3, 1, 1) // Up
            Renderer.drawRect(Renderer.GREEN, x, y-5, 1, 1) // Down
        }
    }
    let y = Dungeon.mapTop[1]
    for (let x = Dungeon.mapTop[0]; x < 128; x++) {
        let color = colors[x + y*128]
        if (color == 0) break
        if (x%2) Renderer.drawRect(Renderer.GREEN, x, y, 1, 1)
        else Renderer.drawRect(Renderer.AQUA, x, y, 1, 1)
        
    }
    Renderer.retainTransforms(false)
})

// Map edit GUI
register("scrolled", (mx, my, dir) => {
    if (!Config.mapMoveGui.isOpen()) return
    if (Client.isShiftDown()) {
        if (dir == 1) lmData.map.headScale += 0.05
        else lmData.map.headScale -= 0.05
    }
    else if (Client.isControlDown()) {
        if (dir == 1) lmData.map.checkmarkScale += 0.05
        else lmData.map.checkmarkScale -= 0.05
    }
    else {
        if (dir == 1) lmData.map.scale += 0.01
        else lmData.map.scale -= 0.01
    }
    lmData.save()
})

register("scrolled", (mx, my, dir) => {
    if (!Config.editDungeonInfoGui.isOpen()) return
    if (dir == 1) lmData.dungeonInfo.scale += 0.05
    else lmData.dungeonInfo.scale -= 0.05
    lmData.save()
})

// Border edit gui scroll
register("scrolled", (mx, my, dir) => {
    if (!Config.borderScaleGui.isOpen()) return
    if (Client.isControlDown()) {
        if (dir == 1) lmData.border.rgbSpeed += 0.5
        else lmData.border.rgbSpeed -= 0.5
    }
    else {
        if (dir == 1) lmData.border.scale += 0.1
        else lmData.border.scale -= 0.1
    }
    if (lmData.border.rgbSpeed < 0) lmData.border.rgbSpeed = 0
    if (lmData.border.scale < 0) lmData.border.scale = 0
    lmData.save()
})

// Dungeon info and map move
register("dragged", (mx, my, x, y, btn) => {
    if (Config.mapMoveGui.isOpen()) {
        lmData.map.x = x
        lmData.map.y = y
        lmData.save()
    }
    if (Config.editDungeonInfoGui.isOpen()) {
        lmData.dungeonInfo.x = x
        lmData.dungeonInfo.y = y
        lmData.save()
    }
})

const lmTabCompletions = ["setkey", "rooms", "debug"]
register("command", (...args) => {
    if (!args || !args[0]) return Config.openGUI()
    if (args[0] == "debug") {
        lmData.debugMap = !lmData.debugMap
        lmData.save()
    }
    if (args[0] == "setkey") {
        if (!args[1]) return ChatLib.chat(`${prefix} &c/lm setkey <api key>`)
        ChatLib.command(`bcore setkey ${args[1]}`, true)
        return
    }
    if (args[0] == "rooms") {
        if (!Object.keys(players).length) return
        ChatLib.chat(`${prefix} &aPlayers visited Rooms:`)
        for (let p of Object.keys(players)) {
            if (!players[p].visited.length) continue
            new Message(`${players[p].formatted || p} &a- &d${players[p].visited.join("&a, &d").replace("Trap", "&6Trap")}`).chat()
        }
    }
}).setTabCompletions(lmTabCompletions).setName("legalmap").setAliases(["lm"])
