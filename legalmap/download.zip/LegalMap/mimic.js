import Dungeon from "../BloomCore/dungeons/Dungeon"
import Config from "./Config"

// Mimic Stuff
// Detect mimic messages in party chat
register("chat", (p, message, e) => {
    let customMessages = Config.extraMimicMessages.split(",").map(a => a.trim())
    if (customMessages.some(a => a == message.toLowerCase())) Dungeon.mimicKilled = true
}).setCriteria("Party > ${p}: ${message}")


let hasAnnouncedMimic = false
register("tick", () => {
    if (!Dungeon.inDungeon || !Dungeon.mimicKilled || !Config.announceMimic || hasAnnouncedMimic) return
    hasAnnouncedMimic = true
    ChatLib.command(`pc ${Config.announceMimicMessage}`)
})
register("worldLoad", () => hasAnnouncedMimic = false)