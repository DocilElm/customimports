import Dungeon from "../BloomCore/dungeons/Dungeon"
import { prefix } from "./Utils"
import Config from "./Config"

let announced270 = false
let announced300 = false
register("worldLoad", () => {
    announced270 = false
    announced300 = false
})

register("tick", () => {
    if (!announced270 && Dungeon.score >= 270) {
        if (Config.scoreMilestones) ChatLib.chat(`${prefix} &a270 Score Reached!`)
        if (Config.announce270) ChatLib.command(`pc ${Config.announce270Message}`)
        announced270 = true
    }
    if (!announced300 && Dungeon.score >= 300) {
        if (Config.scoreMilestones) ChatLib.chat(`${prefix} &a300 Score Reached!`)
        if (Config.announce300) ChatLib.command(`pc ${Config.announce300Message}`)
        announced300 = true
    }
})