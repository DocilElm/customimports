import PogObject from "PogData"
import { DraggableGui } from "../Atomx/draggable/DraggableGui"
import { onTick } from "../ServerTick"

const data = new PogObject("MaskTimers", {
    pos: { x: 0, y: 0, scale: 1 },
    firstInstall: true
})

const editGui = new DraggableGui(data, data.pos).setCommand("masklocation")
const bonzoProcRegex = /^Your( ⚚)? Bonzo\'s Mask saved your life!$/
const spiritProcRegex = /^Second Wind Activated! Your Spirit Mask saved your life!$/

let bonzoProc = null
let spiritProc = null

editGui.onRender(() => {
    Renderer.retainTransforms(true)
    Renderer.translate(editGui.getX(), editGui.getY())
    Renderer.scale(editGui.getScale())
    Renderer.drawStringWithShadow("&9Bonzo's Mask&f: &aReady!", 0, 0)
    Renderer.drawStringWithShadow("&6Spirit Mask&f: &aReady!", 0, 10)
    Renderer.retainTransforms(false)
    Renderer.finishDraw()
})

const thing = register("step", () => {
    if (!World.isLoaded()) return
    if (!data.firstInstall) return thing.unregister()

    ChatLib.chat("&f[&aMaskTimers&f] &aUse command &6/masklocation &ato move the display")
    data.firstInstall = false
    data.save()

    thing.unregister()
}).setFps(1)

// Funny chat packet stuff
register("packetReceived", (packet) => {
    // Check if the packet is for the actionbar
    if (packet.func_148916_d()) return

    const chatComponent = packet.func_148915_c()
    const formatted = chatComponent?.func_150254_d()
    const unformatted = formatted?.removeFormatting()

    if (!unformatted) return

    if (bonzoProcRegex.test(unformatted)) {
        // I'm way too lazy to make a proper way to get this
        // without having to go through the entire lore each timme
        // so here's this now
        Player.armor.getHelmet().getLore().forEach(it => {
            const lore = it?.removeFormatting()
            if (!lore || !lore.includes("Cooldown:")) return

            // Cooldown: §a180s
            const time = parseFloat(lore.match(/^Cooldown: (\d+)s$/)?.[1])

            bonzoProc = time * 20
        })

        return
    }
    if (!spiritProcRegex.test(unformatted)) return

    spiritProc = 600
}).setFilteredClass(net.minecraft.network.play.server.S02PacketChat)

onTick(() => {
    if (bonzoProc <= 0) bonzoProc = null
    if (bonzoProc != null) bonzoProc--

    if (spiritProc <= 0) spiritProc = null
    if (spiritProc == null) return

    spiritProc--
})

register("renderOverlay", () => {
    if (!World.isLoaded() || editGui.isOpen()) return

    const bonzoTime = ((bonzoProc | 0) * 0.05).toFixed(2)
    const spiritTime = ((spiritProc | 0) * 0.05).toFixed(2)

    const bonzoFormat = bonzoProc > 0 ? `&c${bonzoTime}s` : "&aReady!"
    const spiritFormat = spiritProc > 0 ? `&c${spiritTime}s` : "&aReady!"

    Renderer.retainTransforms(true)
    Renderer.translate(editGui.getX(), editGui.getY())
    Renderer.scale(editGui.getScale())
    Renderer.drawStringWithShadow(`&9Bonzo's Mask&f: ${bonzoFormat}`, 0, 0)
    Renderer.drawStringWithShadow(`&6Spirit Mask&f: ${spiritFormat}`, 0, 10)
    Renderer.retainTransforms(false)
    Renderer.finishDraw()
})

register("worldUnload", () => {
    bonzoProc = null
    spiritProc = null
})