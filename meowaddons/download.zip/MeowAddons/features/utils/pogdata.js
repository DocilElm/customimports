import PogObject from "../../../PogData";

export const pogData = new PogObject("MeowAddons", {
    goldorsection: 0,
    CarryX: 0,
    CarryY: 0,
    bloodCampPB: 9999,
});
