
import { Constants } from "../Logic/Constants";
import { Button } from "./Button";

function getAbsolutePosition(multiplier) {
    return multiplier * (Constants.tileSize + Constants.padding) + Constants.padding;
}

class Board {

    navbarHeight = Constants.tileSize + Constants.padding * 2;

    constructor() {
        this.background = new Rectangle(Constants.backgroundColor, 0, 0, 0, 0);
        this.navbar = new Rectangle(Constants.backgroundColor, 0, 0, 0, this.navbarHeight);
        this.tile = new Rectangle(Constants.hiddenColor, 0, 0, Constants.tileSize, Constants.tileSize);

        this.timeSpent = new Text("0s");
        this.bombsRemaining = new Text("xx");

        this.cancel = new Button(
            Constants.bombColor, "x", "§c",
            () => this.navbar.getX() + this.navbar.getWidth() - (Constants.tileSize + Constants.padding),
            () => this.navbar.getY() + Constants.padding, 
            Constants.tileSize, 
            Constants.tileSize
        )
            .onClick(() => {
                Constants.selectGame.open();
            });
    }

    draw(boardData) {
        Constants.drawBackground();

        this.background
            .setX((Renderer.screen.getWidth() - (boardData.dimension * (Constants.tileSize + Constants.padding))) / 2)
            .setY((Renderer.screen.getHeight() - (boardData.dimension * (Constants.tileSize + Constants.padding))) / 2)
            .setWidth(getAbsolutePosition(boardData.dimension))
            .setHeight(getAbsolutePosition(boardData.dimension))
            .draw();

        boardData.tiles.forEach((tile, index) => {
            this.drawTile(tile,
                getAbsolutePosition(index % boardData.dimension) + this.background.getX(),
                getAbsolutePosition(Math.floor(index / boardData.dimension)) + this.background.getY()
            );
        });

        // Render components that are only suppose to be renderered
        // during an active game
        if (Constants.gameGui.isOpen()) {
            this.drawActiveGame(boardData);
        }
    }

    drawActiveGame(boardData) {
        this.navbar
            .setX(this.background.getX())
            .setY(this.background.getY() - (this.navbarHeight + Constants.padding))
            .setWidth(getAbsolutePosition(boardData.dimension))
            .draw();

        this.timeSpent
            .setString(`§6${(boardData.startTime) ? parseInt((Date.now() - boardData.startTime) / 1000) : "0"}s`)
            .setX(this.navbar.getX() + (this.navbar.getWidth() - this.timeSpent.getWidth()) / 2)
            .setY(this.navbar.getY() + (this.navbar.getHeight() - Constants.textHeight) / 2)
            .draw();

        this.bombsRemaining
            .setString(`§c${boardData.bombs - boardData.flagged}`)
            .setX(this.navbar.getX() + (Constants.tileSize + Constants.padding))
            .setY(this.navbar.getY() + (this.navbar.getHeight() - Constants.textHeight) / 2)
            .draw();

        this.cancel.draw();
    }

    drawTile(tile, x, y) {
        this.tile
            .setColor(
                (tile.found)
                    ? (tile.isBomb)
                        // If it is a bomb, render it as such
                        ? Constants.bombColor
                        // If it's found and isn't a bomb, just set the normal color
                        : Constants.foundColor
                    : (tile.flagged)
                        // Rendering it in a different color if it's flagged
                        ? Constants.flaggedColor
                        // If the tile isn't flagged or found
                        : Constants.hiddenColor
            )
            .setX(x)
            .setY(y)
            .draw();

        // Draw neighbouring bombs if the tile is found, or if it's the bomb
        if (tile.found) {
            Renderer.drawString(
                Constants.tileText[tile.neighbouringBombs],
                x + 6, y + 5
            )
        }
    }
}

export default new Board(); 