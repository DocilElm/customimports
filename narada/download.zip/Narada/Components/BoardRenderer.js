
import { Constants } from "../Logic/Constants";
import ThemeEngine from "../Logic/ThemeEngine";

const mine = Image.fromFile(ChatTriggers.DEFAULT_MODULES_FOLDER + "/Narada/Components/assets/mine.png");
const flag = Image.fromFile(ChatTriggers.DEFAULT_MODULES_FOLDER + "/Narada/Components/assets/flag.png");
const dud = Image.fromFile(ChatTriggers.DEFAULT_MODULES_FOLDER + "/Narada/Components/assets/dud.png");

class BoardRenderer {

    getAbsolutePosition = (multiplier) => multiplier * (Constants.tileSize + Constants.padding) + Constants.padding;

    getX = (dimension) => (Renderer.screen.getWidth() - (dimension * (Constants.tileSize + Constants.padding))) / 2;
    getY = (dimension) => (Renderer.screen.getHeight() - (dimension * (Constants.tileSize + Constants.padding))) / 2;

    draw(board) {
        Renderer.drawRect(
            ThemeEngine.getCurrentTheme().windowColor,
            this.getX(board.dimension), this.getY(board.dimension),
            this.getAbsolutePosition(board.dimension),
            this.getAbsolutePosition(board.dimension)
        );
        // Draw all the tiles


        board.tiles.forEach((tile, index) => this.drawTile(tile, index, board.dimension, board.death))
    }

    drawTile(tile, index, dimension, deathIndex) {
        const tileX = this.getAbsolutePosition(index % dimension) + this.getX(dimension);
        const tileY = this.getAbsolutePosition(Math.floor(index / dimension)) + this.getY(dimension);

        Renderer.drawRect(
            (tile.found) ? ThemeEngine.getTileTheme().found : ThemeEngine.getTileTheme().hidden,
            tileX, tileY,
            Constants.tileSize, Constants.tileSize
        );

        // Highlight the hovered tile
        if (Constants.isWithin(
            Client.getMouseX(), Client.getMouseY(),
            tileX, tileY,
            Constants.tileSize, Constants.tileSize)
        ) {
            Renderer.drawRect(
                Renderer.color(170, 170, 170, 80),
                tileX, tileY,
                Constants.tileSize, Constants.tileSize
            )
        }

        // Draw the bomb image
        if (tile.bomb && tile.found) {
            // Highlight the mine you died to
            if (deathIndex === index)
                Renderer.drawRect(ThemeEngine.getTileTheme().death, tileX, tileY, Constants.tileSize, Constants.tileSize);

            mine.draw(
                tileX + 2.5, tileY + 2.5,
                mine.getTextureWidth(),
                mine.getTextureHeight()
            );
        }

        // Draw the flag if deathIndex is not defined (aka you didn't)
        // die to a mine
        // If you did die, reveal wrong flags as duds
        if (tile.flagged) {
            if (deathIndex !== -1 && !tile.bomb)
                dud.draw(tileX + 5.5, tileY + 4, dud.getTextureWidth(), dud.getTextureHeight());
            else
                flag.draw(tileX + 5.5, tileY + 4, flag.getTextureWidth(), flag.getTextureHeight());
        }

        // Draw neighbouring bombs text if the tile is found
        if (tile.found) {
            Renderer.drawStringWithShadow(
                Constants.tileText[tile.neighbouringBombs],
                tileX + 6, tileY + 5
            )
        }
    }
}

export default new BoardRenderer(); 