import { Constants } from "../Logic/Constants";
import ThemeEngine from "../Logic/ThemeEngine";

export const ALIGNMENT = {
    WIDTH_CENTER: "width_center",
    HEIGHT_CENTER: "height_center"
}

export class Button {

    outline = 1;

    constructor(themeName, text = "", x = 0, y = 0, width = 0, height = 0) {
        this.background = new Rectangle(Renderer.BLACK, 0, 0, width, height);
        this.innerBody = new Rectangle(Renderer.BLACK, 0, 0, 0, 0);

        this.text = new Text(text);

        this.setThemeName(themeName)

        this.setX(x);
        this.setY(y);

        this.setText(text);
    }

    // -- Setters --
    setX(x) {
        if (x === ALIGNMENT.WIDTH_CENTER)
            this.x = this._findCenterWidth;
        else
            this.x = x;
        return this;
    }
    _findCenterWidth = () => (Renderer.screen.getWidth() - this.background.getWidth()) / 2;


    setY(y) {
        if (y === ALIGNMENT.HEIGHT_CENTER)
            this.y = this._findCenterHeight;
        else
            this.y = y;
        return this;
    }
    _findCenterHeight = () => (Renderer.screen.getHeight() - this.background.getHeight()) / 2;

    //    setWidth() {}
    //    setHeight() {}

    // Text manipulation
    setText(text) {
        this.string = text;
        return this;
    }
    // -------------

    // Profiles
    setThemeName(string) {
        this.theme = string
    }
    // --------

    // -- Getters --
    //    getX() {}
    //    getY() {}

    getWidth = () => this.background.getWidth();
    getHeight = () => this.background.getHeight();
    // -------------


    // -- Renderering --
    draw() {
        this.background
            .setColor(ThemeEngine.getButtonTheme(this.theme).accentColor)
            .setX(this.x())
            .setY(this.y())
            .draw();

        if (!this.isHovered()) {
            this.innerBody
                .setColor(ThemeEngine.getButtonTheme(this.theme).color)
                .setX(this.x() + this.outline)
                .setY(this.y() + this.outline)
                .setWidth(this.getWidth() - this.outline * 2)
                .setHeight(this.getHeight() - this.outline * 2)
                .draw();
        }

        this.text
            .setString((this.isHovered() ?
                ThemeEngine.getButtonTheme(this.theme).hoverCode :
                ThemeEngine.getButtonTheme(this.theme).colorCode
            ) + this.string)
            // I do not know why adding 0.5 works
            .setX(this.x() + 0.5 + Math.floor((this.getWidth() - this.text.getWidth()) / 2))
            .setY(this.y() + Math.floor((this.getHeight() - Constants.textHeight) / 2))
            .draw();

        return this;
    }
    // -----------------

    // -- Register button presses --
    isClicked(mouseX, mouseY) {
        if (this.isHovered(mouseX, mouseY)) {
            this.click?.();
            return true;
        }
        return false;
    }

    isHovered = (mouseX = Client.getMouseX(), mouseY = Client.getMouseY()) => Constants.isWithin(mouseX, mouseY, this.background.getX(), this.background.getY(), this.background.getWidth(), this.background.getHeight());

    onClick(callback) {
        this.click = callback;
        return this;
    }
    // ------------------------------
}