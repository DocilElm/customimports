import { Constants } from "../Logic/Constants";
import { ALIGNMENT, Button } from "./Button";

class MainScreen {

    buttonHeight = 20;
    buttonWidth = 200;

    constructor() {
        this.buttons = [
            this.play = new Button(Renderer.GRAY, "Play", "§7",  ALIGNMENT.WIDTH_CENTER, () => (Renderer.screen.getHeight() - Constants.tileSize) / 2 - this.buttonHeight, this.buttonWidth, this.buttonHeight)
                .onClick(() => Constants.selectGame.open()),
            this.quit = new Button(Renderer.RED, "Quit", "§c", ALIGNMENT.WIDTH_CENTER, () => (Renderer.screen.getHeight() + Constants.tileSize) / 2, this.buttonWidth, this.buttonHeight)
                .onClick(() => Client.currentGui.close())
        ]
        

        Constants.homeScreen.registerDraw(this.draw.bind(this));
        Constants.homeScreen.registerClicked((mouseX, mouseY) => this.buttons.some(button => button.isClicked(mouseX, mouseY)));
    }

    draw() {
        Constants.drawBackground();
    
        this.buttons.forEach(button => button.draw());
    }
}

new MainScreen();