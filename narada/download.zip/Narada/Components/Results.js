import { Constants } from "../Logic/Constants";
import Board from "./Board";
import { Button } from "./Button";

class Results {

    State = {
        LOSS: 0,
        WIN: 1
    }

    constructor() {
        this.background = new Rectangle(Constants.backgroundColor, 0, 0, 200, Constants.tileSize * 5);
//        this.boardBackground = new Rectangle(Renderer.color(25, 25, 25), 0, 0, 255, 225);

        this.text = [
            [new Text(""), Constants.tileSize / 2],
            [new Text(""), Constants.tileSize + Constants.padding], 
            [new Text(""), Constants.tileSize + Constants.padding * 2 + Constants.textHeight],
            [new Text(""), (Constants.tileSize + Constants.padding) + (Constants.textHeight + Constants.padding)  * 2],
        ];

        this.buttons = [
            this.retry = new Button(
                Renderer.GREEN, "Retry", "§f", 
                () => this.background.getX() + Constants.tileSize, 
                () => this.background.getY() + Constants.tileSize * 3.5,
                66, 20
            ),
            this.cancel = new Button(
                Constants.bombColor, "Cancel", "§f", 
                () => this.background.getX() + Constants.tileSize + this.background.getWidth() / 2, 
                () => this.background.getY() + Constants.tileSize * 3.5, 
                66, 20
            )
                .onClick(() => {
                    Constants.selectGame.open();
                }),
        ];

        // Intialize internal fields to store x and y position for dragging
        this._x = NaN;
        this._y = NaN;

        // Register some helper variables to keep track of dragging
        this.deltaClicked = Infinity;
        this.offsetX = 0;
        this.offsetY = 0;

        Constants.resultsGui.registerDraw(this.draw.bind(this));
        Constants.resultsGui.registerClicked((mouseX, mouseY) => this.buttons.some(button => button.isClicked(mouseX, mouseY)));
        Constants.resultsGui.registerMouseDragged((mouseX, mouseY, button, delta) => {
            // Check if the button is Left Mouse and if the point is within the box of Results
            if (button !== 0 || !Constants.isWithin(mouseX, mouseY, this.x,this.y, this.background.getWidth(), this.background.getHeight())) return;

            
            // triggers when a new release has happened
            if (this.deltaClicked > delta) {
                this.offsetX = mouseX - this.x;
                this.offsetY = mouseY - this.y;
                print(this.offsetX)
            }
            // Keep adding so when a new click happens it'll be less than this
            this.deltaClicked = delta;

            // Check if the results box will go off the screen if so make it that it perfectly won't
            if (this.offsetX > mouseX) mouseX = this.offsetX;
            if (this.offsetY > mouseY) mouseY = this.offsetY; 
            if (mouseX - this.offsetX + this.background.getWidth() > Renderer.screen.getWidth())
                mouseX = Renderer.screen.getWidth() + this.offsetX - this.background.getWidth();
            if (mouseY - this.offsetY + this.background.getHeight() > Renderer.screen.getHeight())
                mouseY = Renderer.screen.getHeight() + this.offsetY - this.background.getHeight(); 

            this._x = mouseX - this.offsetX;
            this._y = mouseY - this.offsetY;
        })
    }

    open(boardData, state) {
        Constants.resultsGui.open();
        // Cannot import BoardData class so getting the constructor from the passed reference
        this.retry.onClick(() => new boardData.constructor(boardData.dimension, boardData.bombs));
        // Reset internal fields to store x and y position so that the results window is centered
        this._x = NaN;
        this._y = NaN;

        this.boardData = boardData;

        // Set the results to the correct type
        switch (state) {
            case this.State.WIN:
                [
                    "§aYou won!",
                    `§7Time: §6${parseFloat(((Date.now() - boardData.startTime) / 1000).toFixed(1))} ${(0 < parseFloat(((Date.now() - boardData.startTime) / 1000).toFixed(2)) < 1) ? "second" : "seconds" }`,
                    `§7Flagged §a${boardData.correctlyFlagged}/${boardData.bombs} §7bombs correctly`,
                    "",
                ].forEach((string, index) => this.text[index]?.[0].setString(string));
                this.retry.setText("Play again");
                break;
            case this.State.LOSS:
                [
                    "§cYou lost!",
                    `§7Time: §6${parseFloat(((Date.now() - boardData.startTime) / 1000).toFixed(1))} seconds`,
                    `§7Flagged §c${boardData.correctlyFlagged}/${boardData.bombs} §7bombs correctly`,
                    `§9${boardData.flagged - boardData.correctlyFlagged} §7${(boardData.flagged - boardData.correctlyFlagged === 1) ? "flag" : "flags"} placed wrong`,
                ].forEach((string, index) => this.text[index]?.[0].setString(string));
                this.retry.setText("Retry");
                break;
        }

        let textWidth = this.text.map(([text, _]) => text.getWidth()).reduce((a, b) => (a > b) ? a : b);
        if (textWidth + Constants.tileSize * 2 > this.background.getWidth()) {
            this.background.setWidth(textWidth)
        }
    }

    draw() {
        // -- Draw the boards ending position --
        Board.draw(this.boardData, 0);
        // -------------------------------------

        this.background
            .setX(this.x)
            .setY(this.y)
            .draw();

        this.text.forEach(([text, verticalOffset], index) => {
            text
                .setX(this.background.getX() + ((index) ? Constants.tileSize : (this.background.getWidth() - text.getWidth()) / 2))
                .setY(this.background.getY() + verticalOffset)
                .draw();
        })

        this.buttons.forEach(button => button.draw());
    }

    get x() {
        return isNaN(this._x) ? this._findX() : this._x;
    }
    get y() {
        return isNaN(this._y) ? this._findY() : this._y;
    }

    _findX = () => (Renderer.screen.getWidth() - this.background.getWidth()) / 2;
    _findY = () => (Renderer.screen.getHeight() - this.background.getHeight()) / 2;

}

export default new Results();