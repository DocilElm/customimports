import { BoardData } from "../Logic/BoardData";
import { Constants } from "../Logic/Constants";
import { Button, ALIGNMENT } from "./Button";

class SelectGameScreen {

    buttonHeight = 20;
    buttonWidth = 200;

    constructor() {
        this.buttons = [
            this.easy = new Button(Renderer.GREEN, "Easy §8(9x9)", "§a", ALIGNMENT.WIDTH_CENTER, () => (Renderer.screen.getHeight() - Constants.tileSize) / 2 - this.buttonHeight * 2 - Constants.tileSize, this.buttonWidth, this.buttonHeight).onClick(() => this.startGame(0)),
            this.intermediate = new Button(Renderer.YELLOW, "Intermediate §8(16x16)", "§e", ALIGNMENT.WIDTH_CENTER, () => (Renderer.screen.getHeight() - Constants.tileSize) / 2 - this.buttonHeight, this.buttonWidth, this.buttonHeight).onClick(() => this.startGame(1)),
            this.expert = new Button(Renderer.RED, "Expert §8(21x21)", "§c", ALIGNMENT.WIDTH_CENTER, () => (Renderer.screen.getHeight() + Constants.tileSize) / 2, this.buttonWidth, this.buttonHeight).onClick(() => this.startGame(2)),
            this.cancel = new Button(Renderer.GRAY, "Go back", "§7", ALIGNMENT.WIDTH_CENTER, () => (Renderer.screen.getHeight() + Constants.tileSize) / 2 + this.buttonHeight + Constants.tileSize, this.buttonWidth, this.buttonHeight)
                .onClick(() => Constants.homeScreen.open())
        ];

        Constants.selectGame.registerDraw(this.draw.bind(this));
        Constants.selectGame.registerClicked((mouseX, mouseY) => this.buttons.some(button => button.isClicked(mouseX, mouseY)));
    }

    draw() {
        Constants.drawBackground();

        this.buttons.forEach(button => button.draw());
    }

    startGame(difficultyLevel) {
        Constants.gameGui.open();
        switch (difficultyLevel) {
            case 0:
                new BoardData(9, 10);
                break;
            case 1:
                new BoardData(16, 40);
                break;
            case 2:
                new BoardData(21, 99);
                break;
        }
    }
}

new SelectGameScreen();