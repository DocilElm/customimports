import { Constants } from "../Logic/Constants";
import { Options } from "../Logic/Options";
import ThemeEngine from "../Logic/ThemeEngine";

export class Slider {

    width = 40;
    height = 4;
    indicatorWidth = 6;
    indicatorHeight = 10;

    constructor(optionsKey, minValue, maxValue, x, y) {
        this.bar = new Rectangle(Renderer.BLACK, 0, 0, this.width, this.height);
        this.filledBar = new Rectangle(Renderer.BLACK, 0, 0, 0, this.height);
        this.indicator = new Rectangle(Renderer.BLACK, 0, 0, this.indicatorWidth, this.indicatorHeight);

        // We store the options key to access the option
        // and the min and max value it can be
        this.optionsKey = optionsKey;
        this.minValue = minValue;
        this.maxValue = maxValue;

        // Use functions to determine position so we don't need to reset every draw call
        this.getX = x;
        this.getY = y;
    }

    // Use the config option to get the shifted X value
    getShiftX = () => MathLib.map(Options[this.optionsKey], this.minValue, this.maxValue, 0, this.width);

    draw() {
        // If dragging has been approved change position
        if (this.dragging) {
            // Set the config option to the new position
            Options[this.optionsKey] = MathLib.map(MathLib.clamp(Client.getMouseX() - this.getX(), 0, 40), 0, this.width, this.minValue, this.maxValue);
        };

        this.bar
            .setColor(ThemeEngine.getCurrentTheme().slider.color)
            .setX(this.getX())
            .setY(this.getY())
            .draw();

        this.filledBar
            .setColor(ThemeEngine.getCurrentTheme().slider.fillColor)
            .setX(this.getX())
            .setY(this.getY())
            // Fill up the bar by how far over the indicator is
            .setWidth(this.getShiftX())
            .draw();

        this.indicator
            .setColor(ThemeEngine.getCurrentTheme().slider.indicatorColor)
            .setX(this.getX() + this.getShiftX() - this.indicatorWidth / 2)
            .setY(this.getY() - (this.indicatorHeight - this.height) / 2)
            .draw();
    }

    // Release the mouse to stop dragging
    mouseReleased() {
        this.dragging = false;
        this.offsetX = 0;
    }

    // Check clicks to see if we can drag
    isClicked(mouseX = Client.getMouseX(), mouseY = Client.getMouseY(), button) {
        if (
            !Constants.isWithin(
                mouseX, mouseY, 
                this.indicator.getX(), this.indicator.getY(), 
                this.indicatorWidth, this.indicatorHeight
            ) || button !== 0
        ) return false;
        // Enable dragging
        this.dragging = !this.dragging;
        return true;
    }
}