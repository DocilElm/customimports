export class Theme {
    constructor(
        backgroundColorArray,
        backgroundColor,
        
        tileHiddenColor,
        tileFoundColor,
        deathTileColor,

        sliderColor,

        buttonThemes,
    ) {
        // General
        this.backgroundColorArray = backgroundColorArray; // Array so we can actually change the opacity of the color with a setting
        this.backgroundColor = backgroundColor;
        
        // Tiles
        this.tileHiddenColor = tileHiddenColor;
        this.tileFoundColor = tileFoundColor;
        this.deathTileColor = deathTileColor;

        // Config
        this.sliderColor = sliderColor;

        // Buttons
        this.buttonThemes = buttonThemes;
    }
}

export class ButtonTheme {
    constructor(
        accentColor,
        colorCode,
        hoverColorCode,
        backgroundColor
    ) {
        this.accentColor = accentColor;
        this.colorCode = colorCode;
        this.hoverColorCode = hoverColorCode;
        this.backgroundColor = backgroundColor;
    }
}