import { Constants } from "../Logic/Constants";

export class Tile {
    constructor() {
        this.bomb = false;
        this.found = false;
        this.flagged = false;

        this.neighbours = [];
        this.neighbouringBombs = 0;
        this.neighbouringFlags = 0;
    }
}