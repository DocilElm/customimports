import { Constants } from "../Logic/Constants";
import { Options } from "../Logic/Options";
import ThemeEngine from "../Logic/ThemeEngine";

export class Toggle {

    padding = 1;
    width = 20;
    height = 10;

    constructor(string, x, y) {
        this.body = new Rectangle(
            Renderer.BLACK, 
            0, 0, 
            this.width, this.height
        );
        this.innerbody = new Rectangle(
            Renderer.BLACK, 
            0, 0, 
            this.width / 2 - this.padding * 2, 
            this.height - this.padding * 2
        );

        // Set up the function for x and y
        this.getX = x;
        this.getY = y;

        // Internal method to determine the innerbody's x
        this._innerX = () => Options[this.optionsKey] ? this.getX() + this.padding : this.getX() + this.width / 2 + this.padding;
        this._innerY = () => this.getY() + this.padding; 

        this.optionsKey = string;

    }

    draw() {
        this.body
            .setColor(ThemeEngine.getButtonTheme(Options[this.optionsKey] ? "again" : "close").accentColor)
            .setX(this.getX())
            .setY(this.getY())
            .draw();

        this.innerbody
            // Set the color to allow for light mode
            .setColor(ThemeEngine.getCurrentTheme().windowColor)
            .setX(this._innerX())
            .setY(this._innerY())
            .draw();
    }


    isClicked(mouseX = Client.getMouseX(), mouseY = Client.getMouseY()) {
        if (
            !Constants.isWithin(
                mouseX, mouseY, 
                this.body.getX(), this.body.getY(), 
                this.body.getWidth(), this.body.getHeight()
            )
        ) return false;
        // Switch the related option
        Options[this.optionsKey] = !Options[this.optionsKey];
        // Trigger any extra logic that needs to happen
        this.clickCallback();
        return true;
    }

    // Set the callback for extra logic on toggle
    onClick(callback ) {
        this.clickCallback = callback;
        return this;
    } 
}
