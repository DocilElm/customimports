import { Tile } from "../Components/Tile";

export class Board {
    constructor(dimension, bombs) {
        this.dimension = dimension;
        this.bombs = bombs;

        // The number of flags places, regardless if they are actual bombs
        this.flagged = 0;
        this.tiles = [];

        this.death = -1;

        // Setup a matrix of tiles
        for (let tileIndex = 0; tileIndex < dimension ** 2; tileIndex++) {
            this.tiles.push(new Tile());
        }
    }
}