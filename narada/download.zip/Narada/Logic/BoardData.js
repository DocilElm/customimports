import Board from "../Components/Board";
import Results from "../Components/Results";
import { Tile } from "../Components/Tile";
import { Constants } from "./Constants";

// Define it here to allow it to do internal recursion without some weird stuff
// #bind(this) must be called to set the correct object to this
function recursiveZeroSearch(tile) {
    if (tile.found) return;
    tile.found = true;
    if (tile.neighbouringBombs === 0) tile.neighbours.forEach(recursiveZeroSearch);
}

export class BoardData {
    constructor(dimension, bombs) {
        Constants.gameGui.open();

        this.dimension = dimension;
        this.bombs = bombs;

        this.flagged = 0;
        this.correctlyFlagged = 0;

        this.tiles = [];
        // Load in the tiles
        for (let tileIndex = 0; tileIndex < (this.dimension * this.dimension); tileIndex++) {
            // Add all the Bomb tiles at the start of the array
            this.tiles.push(new Tile());
        }

        // Temporary property to see if the bombs have yet been generated
        this.firstClick = true;

        // Register this board data to the renderer
        Constants.gameGui.registerDraw(() => Board.draw(this));
        // Register clicks while the game is active to the board
        Constants.gameGui.registerClicked((mouseX, mouseY, button) => {
            // Attempt to click the cancel button
            Board.cancel.isClicked(mouseX, mouseY);

            // Change the mouse position to have the corner of the board be at (0, 0)
            mouseX -= Board.background.getX() + Constants.padding;
            mouseY -= Board.background.getY() + Constants.padding;

            // Check if the click happened within the board
            if (
                mouseX > -Constants.padding && mouseX < Board.background.getWidth()
                &&
                mouseY > -Constants.padding && mouseY < Board.background.getHeight()
                &&
                // Check if the click didn't happen on a border of a tile
                (
                    mouseX % (Constants.tileSize + Constants.padding) < Constants.tileSize &&
                    mouseY % (Constants.tileSize + Constants.padding) < Constants.tileSize
                )
            ) {
                if (button === 0) {
                    this.leftClick((Math.floor(mouseY / (Constants.tileSize + Constants.padding)) * this.dimension + Math.floor(mouseX / (Constants.tileSize + Constants.padding))));
                }

                if (button === 1) {
                    this.rightClick((Math.floor(mouseY / (Constants.tileSize + Constants.padding)) * this.dimension + Math.floor(mouseX / (Constants.tileSize + Constants.padding))));
                }
            }
        });
    }

    leftClick(tileIndex) {
        if (this.firstClick) {
            // We no longer need this so let it get cleared up
            delete this.firstClick;

            this.startTime = Date.now();
            this.generateBombs(tileIndex);

            // Clear this up, we want to be able to parse the object and
            // this function holds no new information and will never be called again
            delete this.generateBombs;
        }

        const clickedTile = this.tiles[tileIndex];
        
        // If the tile is found, check if the neigbouring flags are equal to neighbouring bombs
        // as to unfind all unfound tiles
        if (clickedTile.found) {
            if (clickedTile.neighbouringBombs !== clickedTile.neighbouringFlags || clickedTile.neighbouringBombs === 0) return;
            clickedTile.neighbours.forEach((tile) => {
                if (tile.flagged || tile.found) return;
                this.leftClick(this.tiles.indexOf(tile));
            });

            // Return since the rest is all for unfound tiles
            return;
        };

        // Don't allowed flagged tiles to get clicked
        if (clickedTile.flagged) return;

        // If the tile has no nearby bombs, do what minesweeper does and reveal all
        // connected "0 bomb" tiles
        if (clickedTile.neighbouringBombs === 0 && !clickedTile.isBomb) {
            clickedTile.neighbours.forEach(recursiveZeroSearch);
        }

        // "Find" the tile
        clickedTile.found = true;

        // If the found tile is a bomb, well then end the game
        if (clickedTile.isBomb) {
            // Unfind all bombs
            this.tiles.filter(tile => tile.isBomb).forEach(tile => tile.found = true);

            this.close(Results.State.LOSS);
        }
    }

    rightClick(tileIndex) {
        // Bombs need to be generated before you can start flagging
        if (this.firstClick) return;

        const clickedTile = this.tiles[tileIndex];
        
        // No point to check the rest since once the tile is "found"
        // you can't flag it
        if (clickedTile.found) return;

        // There cannot be more flags than bombs
        // Check to see if you're trying to flag or unflag the item since
        // unflagging is still alowed
        if (this.flagged === this.bombs && !clickedTile.flagged) return;

        // Flag or unflag the tile
        clickedTile.flagged = !clickedTile.flagged;

        // Now update neighbouring flags
        clickedTile.neighbours.forEach((tile) => tile.neighbouringFlags += (clickedTile.flagged) ? 1 : -1)

        // Update the global number of flags placed
        this.flagged += (clickedTile.flagged) ? 1 : -1;
        
        // Check if the flag is actually on a bomb, this info remains internal
        this.correctlyFlagged = this.tiles.filter(tile => tile.isBomb && tile.flagged).length;

        // Check if there is a win condition
        if (this.correctlyFlagged === this.bombs) {
            // Unfind all the non-bombs
            this.tiles.filter(tile => !tile.isBomb && !tile.found).forEach(tile => tile.found = true);

            this.close(Results.State.WIN);
        } 
    }

    generateBombs(firstClickIndex) {
        const bombArray = [];
        for (let tileIndex = 0; tileIndex < this.tiles.length; tileIndex++) {
            // Add all the Bomb tiles at the start of the array
            bombArray.push(tileIndex < this.bombs);
        }

        // Shuffle the bombs
        for (let currentIndex = this.tiles.length - 1; currentIndex > 0; currentIndex--) {
            // Choose a random index
            let randomIndex = Math.floor(Math.random() * (currentIndex + 1));

            // Cache the element you'll replace first
            let currentElement = bombArray[currentIndex];
            // Set the element you cached to the one you want to swap it with
            bombArray[currentIndex] = bombArray[randomIndex];
            // Put the cached item back into the array
            bombArray[randomIndex] = currentElement;
        }

        // Reshuffle untill the first clicked tile isn't a bomb
        while (bombArray[firstClickIndex]) {
            // Choose a random index
            let randomIndex = Math.floor(Math.random() * this.tiles.length);

            // Cache the element you'll replace first
            let firstClickElement = bombArray[firstClickIndex];
            // Set the element you cached to the one you want to swap it with
            bombArray[firstClickIndex] = bombArray[randomIndex];
            // Put the cached item back into the array
            bombArray[randomIndex] = firstClickElement;
        }

        // Merge the bomb array and tiles
        this.tiles.forEach((tile, index) => tile.isBomb = bombArray[index]);

        // Assign the number of neighbouring bombs
        for (let index = 0; index < this.tiles.length; index++) {
            // Transform index position into a position on the board
            let x = index % this.dimension;
            let y = Math.floor(index / this.dimension);

            

            Constants.offsets.forEach(([offsetX, offsetY]) => {
                let neighbouringX = x + offsetX;
                let neighbouringY = y + offsetY;
    
                // Check if the X and Y are actually within the boards range
                if (!(neighbouringX >= 0 && neighbouringX < this.dimension && neighbouringY >= 0 && neighbouringY < this.dimension)) return;
    
                const neigbouringTile = this.tiles[((neighbouringY * this.dimension) + neighbouringX)];

                // Add the neighbouring tile to neighbours of the original
                this.tiles[index].neighbours.push(neigbouringTile);
                
                // Add to the neigbouring bombs if the neigbour is a bomb
                // and the tile isn't a bomb
                if (neigbouringTile.isBomb && !this.tiles[index].isBomb)
                    this.tiles[index].neighbouringBombs += 1;
            });
        }
    }

    close(state) {
        // Remove the abilit to click on the board and smaller object in memory
        delete this.leftClick;
        delete this.rightClick;

        //Remove the neigbours and neighbouringFlags from tiles since it isn't necessary to store that
        this.tiles.forEach(tile => delete tile.neighbours && delete tile.neighbouringFlags);

        Results.open(this, state);
    }
}