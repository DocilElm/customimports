import { Options } from "./Options";

export class Constants {
    static gameGui = new Gui();
    static resultsGui = new Gui();
    static homeScreen = new Gui();
    static selectGame = new Gui();

    static tileSize = 18;
    static padding = 2;
    // The mod thinks it's 10 internally but for nice fromatting, 7 works best
    static textHeight = 7;

    static tileText = ["", "§b1", "§a2", "§e3", "§64", "§c5", "§46", "§77", "§88"];
    static offsets = [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1]];

    /**
     * 
     * @param {number} x the X coordinate of the point to check 
     * @param {number} y the Y coordinate of the point to check
     * @param {number} a the X coordinate of the utmost top-left point
     * @param {number} b the Y coordinate of the utmost top-left point
     * @param {number} c the X coordinate of the other point
     * @param {number} d the Y coordinate of teh other point
     * @param {*} e isRectangle, if true, assume (c, d) to be relative to (a, b)
     * @returns 
     */
    static isWithin = (x, y, a, b, c, d, e = true) => a < x && x < (e ? a + c: c) && b < y && y < (e ? b + d : d);
}

export function getTimeString(startTime, endTime = Date.now(), precision = 0) {
    return `§6${((endTime - startTime) / 1000) ? ((endTime - startTime) / 1000 > 999) ? "999" : parseFloat(((endTime - startTime) / 1000).toFixed(precision)) : "0"}s`;
}