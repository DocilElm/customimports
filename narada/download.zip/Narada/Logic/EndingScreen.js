import Results from "../Components/Results";
import { Constants } from "./Constants";

class EndingScreen {
    open(boardData) {

        Constants.gui.registerDraw(() => Results.draw({}))
        Constants.gui.registerClicked(() => {
            
        });
    }

    close() {}

    draw() {}

    click() {}
}

export default new EndingScreen();