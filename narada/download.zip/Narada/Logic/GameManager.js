import { Screens } from "../Screens/Screens";
import { Constants } from "./Constants";

// Define it here to allow it to do internal recursion without some weird stuff
// #bind(this) must be called to set the correct object to this
function recursiveZeroSearch(tile) {
    if (tile.found) return;
    // Unflag it if you had flagged it
    tile.flagged = false;
    tile.found = true;
    if (tile.neighbouringBombs === 0) tile.neighbours.forEach(recursiveZeroSearch);
}

class GameManager {

    getCurrentBoard = () => this.board;

    start(board) {
        this.board = board;

        // Temporary value to see if the bombs need to be generated
        this.firstClick = true;
    }

    leftClick(tileIndex) {
        if (this.firstClick) {
            // We no longer need this so let it get cleared up
            delete this.firstClick;

            // The game has starts when you first click a square
            this.board.startTime = Date.now();
            // We only generate bombs after the first click to ensure it
            // doesn't generate a bomb in the 3x3 around the clicked tile
            this.generateBombs(tileIndex);
        }

        const clickedTile = this.board.tiles[tileIndex];

        // If the tile is found, check if the neigbouring flags are equal to neighbouring bombs
        // as to unfind all unfound tiles
        if (clickedTile.found) {
            if (
                clickedTile.neighbouringBombs !== clickedTile.neighbouringFlags ||
                clickedTile.neighbouringBombs === 0
            ) return;

            clickedTile.neighbours.forEach(tile => {
                if (tile.flagged || tile.found) return;
                // Get the index of the neighbour, then simulate a left click on it
                this.leftClick(this.board.tiles.indexOf(tile));
            });

            // Return since the rest is all for unfound tiles
            return;
        };

        // Don't allowed flagged tiles to get clicked
        if (clickedTile.flagged) return;

        // If the tile has no nearby bombs, do what minesweeper does and reveal all
        // connected "0 bomb" tiles
        if (clickedTile.neighbouringBombs === 0 && !clickedTile.bomb) {
            clickedTile.neighbours.forEach(recursiveZeroSearch);
        }

        // "Find" the tile
        clickedTile.found = true;

        // Delete the flag property since it's useless now
        delete clickedTile.flagged;

        // If the found tile is a bomb, well then end the game
        if (clickedTile.bomb) {
            // Unfind all bombs
            this.board.tiles.filter(tile => tile.bomb && !tile.flagged).forEach(tile => tile.found = true);
            // mark the tile you died to
            this.board.death = tileIndex;

            this.stop("LOSS");
            return;
        }

        if (this.board.tiles.filter(tile => !tile.found).length === this.board.bombs) {
            // Flag all remaining tiles
            this.board.tiles.filter(tile => !tile.found).forEach(tile => tile.flagged = true);

            this.stop("WIN");
        }
    }

    rightClick(tileIndex) {
        // Bombs need to be generated before you can start flagging
        if (this.firstClick) return;

        const clickedTile = this.board.tiles[tileIndex];

        // No point to check the rest since once the tile is "found"
        // you can't flag it
        if (clickedTile.found) return;

        // There cannot be more flags than bombs
        // Check to see if you're trying to flag or unflag the item since
        // unflagging is still alowed
        if (
            this.board.tiles.filter(tile => tile.flagged).length === this.bombs &&
            !clickedTile.flagged // This implies that if the tile IS flagged, we return
        ) return;

        // Flag or unflag the tile
        clickedTile.flagged = !clickedTile.flagged;

        // Now update neighbouring flags
        clickedTile.neighbours.forEach((tile) => tile.neighbouringFlags += (clickedTile.flagged) ? 1 : -1)

        // Check if there is a win condition
        if (this.board.tiles.filter(tile => tile.bomb && tile.flagged).length === this.board.bombs) {
            // Unfind all the non-bombs
            this.board.tiles.filter(tile => !tile.bomb && !tile.found).forEach(tile => tile.found = true);

            this.stop("WIN");
        }
    }

    generateBombs(firstClickIndex) {
        const bombArray = [];
        // We want the 3x3 around the first clicked tile to not be a bomb so substract 9
        // from the size
        for (let tileIndex = 0; tileIndex < this.board.tiles.length - 9; tileIndex++) {
            bombArray.push(tileIndex < this.board.bombs);
        }

        // Shuffle the bombs
        for (let currentIndex = bombArray.length - 1; currentIndex > 0; currentIndex--) {
            // Choose a random index
            let randomIndex = Math.floor(Math.random() * (currentIndex + 1));

            // Cache the element you'll replace first
            let currentElement = bombArray[currentIndex];
            // Set the element you cached to the one you want to swap it with
            bombArray[currentIndex] = bombArray[randomIndex];
            // Put the cached item back into the array
            bombArray[randomIndex] = currentElement;
        }

        // Array of indexes that can not have a bomb on them
        const coordinateArray = Constants.offsets.map(([x, y]) =>
            this.board.dimension * (y + Math.floor(firstClickIndex / this.board.dimension)) +
            (x + (firstClickIndex % this.board.dimension))
        );

        // Merge the bomb array and tiles but skip tiles that aren't allowed bombs
        this.board.tiles.forEach((tile, index) => {
            if (coordinateArray.includes(index) || index === firstClickIndex) return;
            tile.bomb = bombArray.shift();
        });

        // Update neighbouring bombs on all tiles and add
        // the neighbouring tiles to the neighbouring array
        for (let index = 0; index < this.board.tiles.length; index++) {
            // Transform index position into a position on the board
            let x = index % this.board.dimension;
            let y = Math.floor(index / this.board.dimension);

            Constants.offsets.forEach(([offsetX, offsetY]) => {
                const neighbouringX = x + offsetX;
                const neighbouringY = y + offsetY;

                // Check if the X and Y are actually within the boards range
                if (
                    !Constants.isWithin(
                        neighbouringX, neighbouringY,
                        -1, -1,
                        this.board.dimension, this.board.dimension,
                        false // Because (a, b) is negatif
                    )
                ) return;

                // Convert the neighbouring X and Y into an index position
                const neighbouringTile = this.board.tiles[
                    (neighbouringY * this.board.dimension) + neighbouringX
                ];

                // Add the neighbouring tile to neighbours of the original
                this.board.tiles[index].neighbours.push(neighbouringTile);

                // Add to the neigbouring bombs if the neigbour is a bomb
                // and the tile isn't a bomb
                if (neighbouringTile.bomb && !this.board.tiles[index].bomb)
                    this.board.tiles[index].neighbouringBombs += 1;
            })
        };
    }

    stop(state) {
        Screens.Overview.open(state, this.board);
        // Cleanup Board for saving
        this.board.tiles.forEach(tile => delete tile.neighbours && delete tile.neighbouringFlags);

        // Clear up so the renderer doesn't get confused when this is opened
        // again and draws the previous board by accident
        delete this.board;

    }
}

export default new GameManager();