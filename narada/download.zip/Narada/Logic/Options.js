export const Options = {
    "backgroundOpacity": 255,
    "darkMode": true,
}