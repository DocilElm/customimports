class PersistenceManager {
    constructor() {
        
    }

    save(boardData) {
        print(JSON.parse(boardData));
    }
}

export default new PersistenceManager();