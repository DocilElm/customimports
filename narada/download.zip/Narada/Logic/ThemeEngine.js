import { Options } from "./Options";

class ThemeEngine {
    constructor(currentTheme) {
        this.themes = JSON.parse(FileLib.read("Narada", "/Components/assets/themes.json"));
        this.setCurrentTheme(currentTheme);
    }

    getCurrentTheme() {
        return this.themes[this.currentTheme]
    }

    getTileTheme() {
        return this.themes[this.currentTheme].tiles;
    }

    getButtonTheme(button) {
        return this.themes[this.currentTheme].buttons[button];
    }

    setCurrentTheme(theme) {
        this.currentTheme = theme
    }
}

export default new ThemeEngine(Options.darkMode ? "dark" : "light");