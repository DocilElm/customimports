import { Options } from "../Logic/Options";
import ThemeEngine from "../Logic/ThemeEngine";

export class BasicScreen {
    constructor(gui) {
        this.gui = gui;
    }

    // Default button dimension
    buttonWidth = 200;
    buttonHeight = 20;

    open() { }
    
    draw() { }

    click() { }

    drawBackground() {
        // Get the rgb values from the array
        [r, g, b] = ThemeEngine.getCurrentTheme().backgroundColor;

        // Allow customization
        Renderer.drawRect(Renderer.color(r, g, b, Options.backgroundOpacity), 0, 0, Renderer.screen.getWidth(), Renderer.screen.getHeight());
    }
}