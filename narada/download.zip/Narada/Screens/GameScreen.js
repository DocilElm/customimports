import BoardRenderer from "../Components/BoardRenderer";
import { Button } from "../Components/Button";
import { Constants, getTimeString } from "../Logic/Constants";
import GameManager from "../Logic/GameManager";
import ThemeEngine from "../Logic/ThemeEngine";
import { BasicScreen } from "./BasicScreen";
import { Screens } from "./Screens";

class GameScreen extends BasicScreen {

    constructor() {
        super(Screens.Game);
        this.gui.registerDraw(this.draw.bind(this));
        this.gui.registerClicked(this.click.bind(this));
        Screens.Game = this;

        // Define the navbar so we have a relative position to work from
        this.navbar = new Rectangle(Renderer.BLACK, 0, 0, 0, Constants.tileSize + Constants.padding * 2);

        // Get a button to return the SelectGame screen
        this.close = new Button(
            "close", "x",
            () => this.navbar.getX() + this.navbar.getWidth() - (Constants.tileSize + Constants.padding),
            () => this.navbar.getY() + Constants.padding,
            Constants.tileSize, Constants.tileSize
        )
            .onClick(() => {
                Screens.SelectGame.open();
            });

    }

    open(board) {
        this.gui.open();
        GameManager.start(board);
    }

    draw() {
        this.drawBackground();

        // Grab the current active board
        const board = GameManager.getCurrentBoard();
        // In the case that the board hasn't been laoded yet, return
        if (!board) return;

        // Draw the board
        BoardRenderer.draw(board);

        // Draw the navigation bar
        this.navbar
            .setColor(ThemeEngine.getCurrentTheme().windowColor)
            .setX(BoardRenderer.getX(board.dimension))
            .setY(BoardRenderer.getY(board.dimension) - (this.navbar.getHeight() + Constants.padding))
            .setWidth(BoardRenderer.getAbsolutePosition(board.dimension))
            .draw();

        Renderer.drawStringWithShadow(
            getTimeString(board.startTime),
            this.navbar.getX() + this.navbar.getWidth() / 2,
            this.navbar.getY() + (this.navbar.getHeight() - Constants.textHeight) / 2
        );

        Renderer.drawStringWithShadow(
            `§c${board.bombs - board.tiles.filter(tile => tile.flagged).length}`,
            this.navbar.getX() + (Constants.tileSize + Constants.padding),
            this.navbar.getY() + (this.navbar.getHeight() - Constants.textHeight) / 2
        );

        this.close.draw();
    }

    click(mouseX, mouseY, button) {
        // Check if the board exists
        const board = GameManager.getCurrentBoard();
        if (!board) return;

        // Check if the close button is the one that needs to be clicked
        // if it is, then it isn't a tile so return
        if (this.close.isClicked(mouseX, mouseY)) return;

        // Change the mouse position to have the corner of the board be at (0, 0)
        mouseX -= BoardRenderer.getX(board.dimension) + Constants.padding;
        mouseY -= BoardRenderer.getY(board.dimension) + Constants.padding;

        // Check if the click happened in the board and not on the padding
        if (
            Constants.isWithin(
                mouseX, mouseY, 
                -Constants.padding, -Constants.padding,
                BoardRenderer.getAbsolutePosition(board.dimension), 
                BoardRenderer.getAbsolutePosition(board.dimension),
                false // Because the (a, b) coords are negative
            ) && 
            // Check if the click didn't happen on a border of a tile
            (
                mouseX % (Constants.tileSize + Constants.padding) < Constants.tileSize &&
                mouseY % (Constants.tileSize + Constants.padding) < Constants.tileSize
            )
        ) {
            // Get the tile index from the mouse position
            const tileIndex = 
            Math.floor(mouseY / (Constants.tileSize + Constants.padding)) * board.dimension + 
            Math.floor(mouseX / (Constants.tileSize + Constants.padding));
            if (button === 0) GameManager.leftClick(tileIndex);
            if (button === 1) GameManager.rightClick(tileIndex);
        }
    }
}

new GameScreen();