import { ALIGNMENT, Button } from "../Components/Button";
import { Constants } from "../Logic/Constants";
import { BasicScreen } from "./BasicScreen";
import { Screens } from "./Screens";

class MainScreen extends BasicScreen {
    constructor() {
        super(Screens.Main);
        this.gui.registerDraw(this.draw.bind(this));
        this.gui.registerClicked(this.click.bind(this));
        Screens.Main = this;

        this.buttons = [
            this.play = new Button(
                "play", "Play", ALIGNMENT.WIDTH_CENTER, 
                () => (Renderer.screen.getHeight() - this.buttonHeight) / 2 - this.buttonHeight - Constants.tileSize,
                this.buttonWidth, this.buttonHeight
            ),
            this.options = new Button(
                "options", "Options", ALIGNMENT.WIDTH_CENTER,
                () => (Renderer.screen.getHeight() - this.buttonHeight) / 2,
                this.buttonWidth, this.buttonHeight
            ),
            this.quit = new Button(
                "quit", "Quit", ALIGNMENT.WIDTH_CENTER,
                () => (Renderer.screen.getHeight() + this.buttonHeight) / 2 + Constants.tileSize,
                this.buttonWidth, this.buttonHeight
            ),
        ];

        this.play.onClick(() => Screens.SelectGame.open());
        this.options.onClick(() => Screens.Options.open());
        this.quit.onClick(() => Client.currentGui.close());
    }

    draw() {
        this.drawBackground();
        this.buttons.forEach(button => button.draw());
    }

    click(mouseX, mouseY) {
        this.buttons.some(button => button.isClicked(mouseX, mouseY));
    }

    open() { 
        this.gui.open();
    }
}

new MainScreen();