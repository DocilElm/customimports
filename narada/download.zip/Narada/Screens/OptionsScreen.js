import { Button } from "../Components/Button";
import { Slider } from "../Components/Slider";
import { Toggle } from "../Components/Toggle";
import { Constants } from "../Logic/Constants";
import { Options } from "../Logic/Options";
import ThemeEngine from "../Logic/ThemeEngine";
import { BasicScreen } from "./BasicScreen";
import { Screens } from "./Screens";

const bodyWidth = 200;
const bodyHeight = 100;

class OptionsScreen extends BasicScreen{

    constructor() {
        super(Screens.Options);
        this.gui.registerDraw(this.draw.bind(this));
        this.gui.registerClicked(this.click.bind(this));
        Screens.Options = this;

        // Define a body to use as relative position on "presables"
        this.body = new Rectangle(Renderer.BLACK, 0, 0, bodyWidth, bodyHeight);

        this.pressables = [
            // The button to close config menu
            this.close = new Button(
                "close", "x",
                () => this.body.getX() + this.body.getWidth() - Constants.tileSize - Constants.padding,
                () => this.body.getY() + Constants.padding,
                Constants.tileSize, Constants.tileSize
            ),
            // CONFIG
            // Toggle darkmode
            this.darkMode = new Toggle(
                "darkMode", 
                () => this.body.getX() + bodyWidth - this.darkMode.width - Constants.tileSize - Constants.padding * 2, 
                () => this.body.getY() + Constants.tileSize + Constants.padding * 3
            ),
            // Slider to change opacity
            this.backgroundOpacity = new Slider(
                "backgroundOpacity", 0, 255,
                () => this.body.getX() + bodyWidth - this.backgroundOpacity.width - Constants.tileSize - Constants.padding * 2,
                () => this.body.getY() + Constants.tileSize * 2 + Constants.padding * 5
            ),
        ];

        this.close.onClick(() => Screens.Main.open());
        // What to do when the darkmode toggle is clicked
        this.darkMode.onClick(( ) => ThemeEngine.setCurrentTheme(Options.darkMode ? "dark":"light"));
        // For the slider to work
        this.gui.registerMouseReleased(() => this.backgroundOpacity.mouseReleased());
    }

    draw() {
        super.drawBackground();

        this.body
            // Set color to allow for light mode
            .setColor(ThemeEngine.getCurrentTheme().windowColor)
            .setX((Renderer.screen.getWidth() - bodyWidth) / 2)
            .setY((Renderer.screen.getHeight() - bodyHeight) / 2)
            .draw();

        this.pressables.forEach(pressable => pressable.draw());

        // Draw the config description
        // Positions are meh, but it doesn't matter right now
        Renderer.drawString(
            (Options.darkMode ? "§f" : "§0") + "Toggle dark mode",
            this.body.getX() + Constants.tileSize + Constants.padding * 2,
            this.darkMode.getY() + 1
        )

        Renderer.drawString(
            (Options.darkMode ? "§f" : "§0") + "Background opacity",
            this.body.getX() + Constants.tileSize + Constants.padding * 2,
            this.backgroundOpacity.getY() - 1
        )
    }

    // Click function
    click(mouseX, mouseY, button) {
        this.pressables.forEach(pressable => pressable.isClicked(mouseX, mouseY, button));
    }

    // Open the options screen
    open() {
        this.gui.open();
    }
}

new OptionsScreen();