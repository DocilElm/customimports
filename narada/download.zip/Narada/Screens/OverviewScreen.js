import BoardRenderer from "../Components/BoardRenderer";
import { Button } from "../Components/Button";
import { Constants, getTimeString } from "../Logic/Constants";
import ThemeEngine from "../Logic/ThemeEngine";
import { BasicScreen } from "./BasicScreen";
import { Screens } from "./Screens";

const buttonWidth = 180;
const buttonHeight = 20;
const navbarHeight = Constants.tileSize + Constants.padding * 2;
const bodyWidth = 200;
const bodyHeight = 130;

class OverviewScreen extends BasicScreen {

    constructor() {
        super(Screens.Overview);
        this.gui.registerDraw(this.draw.bind(this));
        this.gui.registerClicked(this.click.bind(this));
        this.gui.registerClosed(this.close.bind(this));
        // When the mouse is released, stop dragging
        this.gui.registerMouseReleased(() => { if (this.dragging) this.dragging = false });
        Screens.Overview = this;

        // Components will be relative so make this the anchor point
        this.body = new Rectangle(Renderer.BLACK, 0, 0, bodyWidth, bodyHeight);
        this.navbar = new Rectangle(Renderer.BLACK, 0, 0, bodyWidth, navbarHeight);

        this.buttons = [
            this.cancel = new Button(
                "close", "x",
                () => this.navbar.getX() + this.navbar.getWidth() - (Constants.tileSize + Constants.padding),
                () => this.navbar.getY() + Constants.padding,
                Constants.tileSize, Constants.tileSize
            ),
            this.again = new Button(
                "again", "",
                () => this.body.getX() + (bodyWidth - buttonWidth) / 2,
                () => this.body.getY() + bodyHeight - buttonHeight * 3,
                buttonWidth, buttonHeight
            ),
            this.options = new Button(
                "options", "Options",
                () => this.body.getX() + (bodyWidth - buttonWidth) / 2,
                () => this.body.getY() + bodyHeight - buttonHeight * 1.5,
                buttonWidth, buttonHeight
            )
        ];

        this.cancel.onClick(() => Screens.SelectGame.open());
        this.again.onClick(() => Screens.Game.open(new this.board.constructor(this.board.dimension, this.board.bombs)))
        this.options.onClick(() => Screens.Options.open());
    }

    open(state, board) {
        this.gui.open();
        this.board = board;
        this.state = state;

        // Set the boards endtime
        this.board.endTime = Date.now();

        // Change the text based on your win or loss
        if (state === "LOSS") {
            this.overviewString = "§cYou lost!";
            this.again.setText("Retry")
        }
        if (state === "WIN") {
            this.overviewString = "§aYou won!";
            this.again.setText("Play again")
        }

        this.timeString = "§7Time: §6" + getTimeString(this.board.startTime, this.board.endTime, 3);
        this.bombString = `§7Bombs: §9${this.board.tiles.filter(tile => tile.bomb && tile.flagged).length} / ${this.board.bombs}`;
    }

    draw(mouseX, mouseY) {
        // Draw the board and background screen
        this.drawBackground();

        // If dragging has been approved and mouse is down, change position
        if (this.dragging) this.setPosition(mouseX, mouseY);

        // Draw our "Containers"
        this.body
            .setColor(ThemeEngine.getCurrentTheme().windowColor)
            .setX(this.getX())
            .setY(this.getY())
            .draw();
        this.navbar
            .setColor(ThemeEngine.getCurrentTheme().windowColor)
            .setX(this.getX())
            .setY(this.getY())
            .draw();

        Renderer.drawStringWithShadow(
            this.overviewString,
            this.getX() + (bodyWidth - Renderer.getStringWidth(this.overviewString)) / 2,
            this.getY() + (navbarHeight - Constants.textHeight) / 2
        );
        Renderer.drawStringWithShadow(
            this.timeString,
            this.getX() + (bodyWidth - Renderer.getStringWidth(this.timeString)) / 2,
            this.getY() + navbarHeight + Constants.padding * 4 + Constants.textHeight
        );
        Renderer.drawStringWithShadow(
            this.bombString,
            this.getX() + (bodyWidth - Renderer.getStringWidth(this.bombString)) / 2,
            this.getY() + navbarHeight + Constants.padding * 6 + Constants.textHeight * 2
        );

        this.buttons.forEach(button => button.draw());
    }

    drawBackground() {
        super.drawBackground();
        BoardRenderer.draw(this.board);
    }

    click(mouseX, mouseY, button) {
        // Prevent dragging when clicking a button
        if (this.buttons.some(button => button.isClicked(mouseX, mouseY))) return;

        // Check if the window is hovered
        if (button !== 0 || !Constants.isWithin(mouseX, mouseY, this.getX(), this.getY(), bodyWidth, bodyHeight)) return;
        // Enable dragging
        this.dragging = !this.dragging;
        // Set offset
        this.offsetX = mouseX - this.getX();
        this.offsetY = mouseY - this.getY();
    }

    // Getters and setters to make dragging possible
    getX() {
        return (this.x) ? this.x : (Renderer.screen.getWidth() - bodyWidth) / 2;
    }
    getY() {
        return (this.y) ? this.y : (Renderer.screen.getHeight() - bodyHeight) / 2;
    }

    setPosition(mouseX, mouseY) {
        this.x = mouseX - this.offsetX;
        this.y = mouseY - this.offsetY;
    }

    close() {
        // These won't be needed again so they can go
        delete this.board;
        delete this.state;

        // Delete the strings for looks
        delete this.timeString;
        delete this.bombString;
        delete this.overviewString;

        // Delete these so that the window is recentered the next time it's opened
        delete this.x;
        delete this.y;

        // Set the dragging to false to prevent weird issues
        delete this.dragging;
        // Offsets don't need to be cleared because they will be changed before they are used
    }
}

new OverviewScreen();