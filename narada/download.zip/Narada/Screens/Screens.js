import { Button } from "../Components/Button";
import { Constants } from "../Logic/Constants";

export class Screens {
    static Main = new Gui();
    static Game = new Gui();
    static Overview = new Gui();
    static SelectGame = new Gui();
    static Options = new Gui();
}