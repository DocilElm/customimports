import { Button, ALIGNMENT } from "../Components/Button";
import { Board } from "../Logic/Board";
import { Constants } from "../Logic/Constants";
import { BasicScreen } from "./BasicScreen";
import { Screens } from "./Screens";

class SelectGame extends BasicScreen {
    constructor() {
        super(Screens.SelectGame);
        this.gui.registerDraw(this.draw.bind(this));
        this.gui.registerClicked(this.click.bind(this));
        Screens.SelectGame = this;

        this.buttons = [
            this.easy = new Button(
                "easy", "Easy §8(9x9)", ALIGNMENT.WIDTH_CENTER, 
                () => (Renderer.screen.getHeight() - Constants.tileSize) / 2 - this.buttonHeight * 2 - Constants.tileSize, 
                this.buttonWidth, this.buttonHeight
            ),
            this.intermediate = new Button(
                "intermediate", "Intermediate §8(16x16)", ALIGNMENT.WIDTH_CENTER, 
                () => (Renderer.screen.getHeight() - Constants.tileSize) / 2 - this.buttonHeight, 
                this.buttonWidth, this.buttonHeight
            ),
            this.expert = new Button(
                "expert", "Expert §8(21x21)", ALIGNMENT.WIDTH_CENTER, 
                () => (Renderer.screen.getHeight() + Constants.tileSize) / 2, this.buttonWidth, this.buttonHeight
            ),
            this.back = new Button(
                "return", "Go back", ALIGNMENT.WIDTH_CENTER, 
                () => (Renderer.screen.getHeight() + Constants.tileSize) / 2 + this.buttonHeight + Constants.tileSize, 
                this.buttonWidth, this.buttonHeight
            ),
        ];

        this.easy.onClick(() => Screens.Game.open(new Board(9, 10)));
        this.intermediate.onClick(() => Screens.Game.open(new Board(16, 40)));
        this.expert.onClick(() => Screens.Game.open(new Board(21, 99)));

        this.back.onClick(() => Screens.Main.open()); 
    }

    draw() {
        this.drawBackground();
        this.buttons.forEach(button => button.draw());
    }

    click(mouseX, mouseY) {
        this.buttons.some(button => button.isClicked(mouseX, mouseY));
    }

    open() {
        this.gui.open();
    }
}

new SelectGame();