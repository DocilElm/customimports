import "./Screens/OptionsScreen";
import "./Screens/MainScreen";
import "./Screens/SelectGameScreen";
import "./Screens/GameScreen";
import "./Screens/OverviewScreen";

import { Screens } from "./Screens/Screens";

register("command", () => {
    Screens.Main.open();
})
    .setName("mine")
    .setAliases([
        "minesweeper", 
        "narada", 
        "romulanminingship", 
        "boomboomfield"
    ]);