import settings from './config';
export default settings;