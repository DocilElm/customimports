let global = {
    returnPacket: {
        "secretCount": {}
    },
}
export default global;