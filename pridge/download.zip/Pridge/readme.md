# Pridge
Pridge is a ChatTriggers Module made to format the Shrimple/Prawn Academy Skyblock Guilds chats.

---
# License
This project includes components licensed under the [STuF Software License](https://github.com/stuffyerface/STuF/blob/main/LICENSE.md).