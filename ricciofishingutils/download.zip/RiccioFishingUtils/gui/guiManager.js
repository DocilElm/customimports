import { GuiManager } from "../../SimpleOverlays"
import ElementTypes from "./ElementTypes"

export default new GuiManager("RiccioFishingUtils", "/data/gui.json", "rfumove", ElementTypes, undefined, "moverfu")