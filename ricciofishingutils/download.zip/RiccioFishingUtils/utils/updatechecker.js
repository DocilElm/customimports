const version = JSON.parse(FileLib.read("RiccioFishingUtils", "metadata.json")).version

function processVersion(version) {
    let prerelease
    let versionParts = version.split('.').map((value) => {
        const releaseNumber = /pre(\d{1,3})/.exec(value)
        if(releaseNumber) {
            prerelease = releaseNumber[1]
        }
        const verNumber = /\d+/.exec(value)
        return Number(verNumber ? verNumber[0] : 0)
    });
    //Add a the release number if its a prerelease or a 1000 if its not so normal releases have priority over prereleases
    //Will only work until there are 999 prereleases, should be fine
    versionParts.push(prerelease ? prerelease : 1000)
    return versionParts
}

function compareVersions(version1, version2) {
    const v1Parts = processVersion(version1)
    const v2Parts = processVersion(version2)

    const maxLength = Math.max(v1Parts.length, v2Parts.length);
    for (let i = 0; i < maxLength; i++) {
        let v1 = v1Parts[i] || 0; // Default to 0 if part is missing
        let v2 = v2Parts[i] || 0; // Same
        if (v1 < v2) return true;
        if (v1 > v2) return false;
    }
    return false;
}

function checkIfUpdate(announceUpToDate = false) {
    //Verify if ctjs is in version 2.2.1 or later
    if(!compareVersions(com.chattriggers.ctjs.Reference.MODVERSION, "2.2.1")) {
        releases = JSON.parse(FileLib.getUrlContent("https://api.github.com/repos/ricciow/RiccioFishingUtils/releases"))
        const latestRelease = releases?.find(({ tag_name }) => compareVersions(version, tag_name?.substring(1)));
        if (latestRelease) {
            const latestVersion = latestRelease.tag_name.substring(1);
            const downloadLink = latestRelease.html_url;
            ChatLib.chat(
                new TextComponent(`&5[&b&lRFU&5] &9&lNew RFU Release: &fv${latestVersion} &a&l[Download]`)
                .setClick("open_url", downloadLink)
            )
        }
        else if(announceUpToDate) {
            ChatLib.chat("&5[&b&lRFU&5] &9You're on the latest version!")
        }
    }
    else {
        ChatLib.chat(
            new TextComponent(`&5[&b&lRFU&5] &cUnable to check if there's a new version since your chattriggers is outdated. &a&l[CT website]`)
            .setClick("open_url", "https://www.chattriggers.com")
        )
    }
}

const latestwarn = register('worldLoad', () => {
    checkIfUpdate()
    latestwarn.unregister()
})

register("command", () => checkIfUpdate(true)).setName("rfucheckupdate")