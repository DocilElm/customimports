import RenderLib from "../../../RenderLib"
import FeaturesBase from "../../FeatureBase"

const blockCoords = JSON.parse(FileLib.read("Rift", "data/UpsideDown.json"))

export default new class UpsideDown extends FeaturesBase {
    constructor(){
        super()

        this.configName = "UpsideDownSetting"
        this.requiredWorld = "Mirrorverse"

        this.addEvent(this.configName, register("renderWorld", () => {
            if(!World.isLoaded()) return

            blockCoords.forEach((block, index) => {
                RenderLib.drawEspBox(block[0]+.5, block[1]+1, block[2]+.5, 1, 1, 1, 1, 1, 1, false)
                Tessellator.drawString(index+1, block[0]+.5, block[1]+1.5, block[2]+.5, Renderer.WHITE, false, .05, false)
            })
        }), [], this.requiredWorld)
    }
}