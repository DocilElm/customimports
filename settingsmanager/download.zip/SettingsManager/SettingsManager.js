module.exports = {
    Setting: require("./Settings.js"), 
    SettingsObject: require("./SettingsObject.js")
}