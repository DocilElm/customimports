export const Color = Java.type("java.awt.Color");

export const invisibleColor = new Color(0,0,0,0)